#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
[[ -f ".env" ]] && { set -o allexport; source .env; set +o allexport; }
echo "🖥️  Streamlit frontend → backend at ${MCP_HOST:-localhost}:${MCP_PORT:-8000}"
PYTHONPATH="$ROOT" streamlit run frontend/streamlit_app.py \
    --server.port=8501 --server.address=0.0.0.0 \
    --browser.gatherUsageStats=false
