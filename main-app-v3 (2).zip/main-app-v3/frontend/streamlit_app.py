"""
frontend/streamlit_app.py
═══════════════════════════════════════════════════════════════════════════════
Streamlit frontend for the Incident Analysis App.

Pages
─────
  Login  — static credential form
  Chat   — conversational interface with sidebar quick-actions

State is held entirely in st.session_state.
Backend is called via the FastMCP client SDK over HTTP.
"""

from __future__ import annotations

import asyncio
import json
import os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Any, Dict, List, Optional

import streamlit as st

# ── Page config — must be first Streamlit call ────────────────────────────────
st.set_page_config(
    page_title="Incident Analysis App",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Backend URL ────────────────────────────────────────────────────────────────
_HOST       = os.getenv("MCP_HOST", "localhost")
_PORT       = os.getenv("MCP_PORT", "8000")
BACKEND_URL = f"http://{_HOST}:{_PORT}"

# ── MCP client ────────────────────────────────────────────────────────────────
try:
    from fastmcp import Client as _MCPClient
    _MCP_OK = True
except ImportError:
    _MCP_OK = False
    st.error("fastmcp not installed. Run: pip install fastmcp", icon="🚨")


# ─────────────────────────────────────────────────────────────────────────────
# Async / sync bridge
# ─────────────────────────────────────────────────────────────────────────────

def _sync(coro) -> Any:
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            with ThreadPoolExecutor(1) as pool:
                return pool.submit(asyncio.run, coro).result()
        return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


async def _call(tool: str, **kw) -> Dict[str, Any]:
    if not _MCP_OK:
        raise RuntimeError("fastmcp not installed.")
    async with _MCPClient(BACKEND_URL) as c:
        items = await c.call_tool(tool, kw)
        return json.loads(items[0].text) if items and hasattr(items[0], "text") else {}


def _mcp(tool: str, **kw) -> Optional[Dict[str, Any]]:
    try:
        return _sync(_call(tool, **kw))
    except Exception as exc:
        st.error(f"Backend error ({tool}): {exc}", icon="🚨")
        return None


# ─────────────────────────────────────────────────────────────────────────────
# CSS
# ─────────────────────────────────────────────────────────────────────────────

st.markdown("""
<style>
:root {
    --blue:  #1E40AF;
    --blue2: #1D4ED8;
    --navy:  #1E3A8A;
    --green: #16A34A;
    --slate: #64748B;
}
[data-testid="stSidebar"] { background: #0F172A !important; }
[data-testid="stSidebar"] * { color: #CBD5E1 !important; }
[data-testid="stSidebar"] .stButton > button {
    background: var(--blue); color: white !important;
    border: none; border-radius: 6px; width: 100%;
    font-size: 0.81rem; margin-bottom: 2px;
}
[data-testid="stSidebar"] .stButton > button:hover { background: var(--blue2) !important; }

.hdr {
    background: linear-gradient(135deg, var(--blue) 0%, var(--navy) 100%);
    padding: 18px 24px; border-radius: 12px; margin-bottom: 20px; color: white;
}
.hdr h1 { margin:0; font-size:1.5rem; font-weight:700; }
.hdr p  { margin:4px 0 0; opacity:.8; font-size:.87rem; }

.u { background:#EFF6FF; border-left:4px solid var(--blue);
     padding:10px 14px; border-radius:0 8px 8px 0; margin:10px 0; }
.a { background:#F0FDF4; border-left:4px solid var(--green);
     padding:10px 14px; border-radius:0 8px 8px 0; margin:10px 0; }
.meta { font-size:.72rem; color:var(--slate); margin-top:4px; }
.badge { display:inline-block; background:#DBEAFE; color:var(--blue);
         font-size:.68rem; font-weight:600; padding:2px 8px;
         border-radius:12px; margin-right:4px; }
.dot { display:inline-block; width:8px; height:8px; border-radius:50%;
       background:#22C55E; margin-right:5px; vertical-align:middle; }
.empty { text-align:center; color:#94A3B8; padding:60px 20px; }
.empty span { font-size:2.8rem; }
.empty h3 { color:var(--slate); margin:12px 0 6px; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# Session state init
# ─────────────────────────────────────────────────────────────────────────────

for _k, _v in {
    "logged_in": False, "username": "", "session_id": None,
    "messages": [], "thinking": False, "_pq": None,
}.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v


# ─────────────────────────────────────────────────────────────────────────────
# Quick actions
# ─────────────────────────────────────────────────────────────────────────────

_QA: List[tuple[str, str]] = [
    ("🔴 Vital-12 anomalies",       "Are there any active anomalies in Vital-12?"),
    ("📄 Search PIR library",        "Search the PIR library for recent database outage root causes"),
    ("📝 TSOP incident lookup",      "Look up TSOP incident INC0000000000001"),
    ("🔗 TSOP conen lookup",         "Look up TSOP conen C0000001"),
    ("⚡ Power health — AMST",       "Check power health for site AMST"),
    ("📡 RAN node status",           "What is the status of RAN node ENB001?"),
    ("🏠 Service status by address", "Check service status for 10 Downing Street, London"),
    ("🔍 Auto-RAG Confluence",       "Search Confluence for BGP routing issues"),
]

_SYS: List[tuple[str, str]] = [
    ("Vital-12",         "anomaly detection"),
    ("RAN Chat",         "IMO RAN — single node/site"),
    ("Confluence PIR",   "Problem Management"),
    ("Confluence WS",    "workspace search"),
    ("Confluence RAG",   "auto-RAG (early testing)"),
    ("SSP",              "service status by address"),
    ("TSOP Search",      "incident / conen"),
    ("TSOP Power",       "power health check"),
]


# ─────────────────────────────────────────────────────────────────────────────
# Submit helper
# ─────────────────────────────────────────────────────────────────────────────

def _submit(q: str):
    if not q.strip():
        return
    st.session_state.messages.append({
        "role": "user", "content": q.strip(),
        "timestamp": datetime.now().strftime("%H:%M:%S"), "meta": {},
    })
    st.session_state.thinking = True
    st.session_state._pq      = q.strip()
    st.rerun()


# ─────────────────────────────────────────────────────────────────────────────
# Login page
# ─────────────────────────────────────────────────────────────────────────────

def _login():
    _, col, _ = st.columns([1, 1.3, 1])
    with col:
        st.markdown("""
        <div style="text-align:center;padding-top:60px">
            <div style="font-size:3rem">🔍</div>
            <h2 style="color:#1E40AF;margin:10px 0 4px">Incident Analysis App</h2>
            <p style="color:#64748B;margin-bottom:28px">
                AI-powered triage across all integrated systems
            </p>
        </div>""", unsafe_allow_html=True)

        with st.form("login"):
            user = st.text_input("Username", placeholder="Enter username")
            pwd  = st.text_input("Password", type="password", placeholder="Enter password")
            ok   = st.form_submit_button("Sign In →", use_container_width=True, type="primary")

        if ok:
            if not user or not pwd:
                st.warning("Please enter both fields.")
                return
            with st.spinner("Authenticating…"):
                data = _mcp("login", username=user, password=pwd)
            if data and data.get("session_id"):
                st.session_state.update(
                    logged_in=True, username=data["username"],
                    session_id=data["session_id"],
                )
                st.rerun()
            else:
                st.error("Invalid credentials.")


# ─────────────────────────────────────────────────────────────────────────────
# Sidebar
# ─────────────────────────────────────────────────────────────────────────────

def _sidebar():
    with st.sidebar:
        st.markdown(f"### 🔍 Incident Analysis\n**{st.session_state.username}**")
        st.caption(f"Session `{st.session_state.session_id[:8]}…`")
        st.divider()

        st.markdown("#### ⚡ Quick Actions")
        for label, query in _QA:
            if st.button(label, key=f"qa_{label}", use_container_width=True):
                _submit(query)

        st.divider()
        st.markdown("#### 🔌 Integrated Systems")
        for name, sub in _SYS:
            st.markdown(
                f'<span class="dot"></span><small><b>{name}</b> — {sub}</small>',
                unsafe_allow_html=True,
            )

        st.divider()
        c1, c2 = st.columns(2)
        with c1:
            if st.button("🗑️ Clear", use_container_width=True):
                _mcp("clear_history", session_id=st.session_state.session_id)
                st.session_state.messages = []
                st.rerun()
        with c2:
            if st.button("🚪 Logout", use_container_width=True):
                _mcp("logout", session_id=st.session_state.session_id)
                for k in list(st.session_state.keys()):
                    del st.session_state[k]
                st.rerun()


# ─────────────────────────────────────────────────────────────────────────────
# Message renderer
# ─────────────────────────────────────────────────────────────────────────────

def _msg(m: dict):
    ts      = m.get("timestamp", "")
    meta    = m.get("meta", {})
    content = m["content"]

    if m["role"] == "user":
        st.markdown(
            f'<div class="u"><strong>👤 You</strong><br/>{content}'
            f'<div class="meta">{ts}</div></div>',
            unsafe_allow_html=True,
        )
    else:
        agents = meta.get("agents_used", [])
        badges = "".join(f'<span class="badge">{a}</span>' for a in agents)
        hdr    = f"<strong>🤖 Incident Analyst</strong>"
        if badges:
            hdr += f"<br/><div style='margin:4px 0 2px'>{badges}</div>"
        st.markdown(f'<div class="a">{hdr}</div>', unsafe_allow_html=True)
        st.markdown(content)
        if tid := meta.get("trace_id"):
            st.caption(f"🔍 Trace `{tid[:16]}…` • {ts}")


# ─────────────────────────────────────────────────────────────────────────────
# Chat view
# ─────────────────────────────────────────────────────────────────────────────

def _chat():
    st.markdown("""
    <div class="hdr">
        <h1>🔍 Incident Analysis App</h1>
        <p>Ask about incidents, anomalies, root causes, or patterns across all integrated systems</p>
    </div>""", unsafe_allow_html=True)

    # Process pending query
    if st.session_state.thinking and st.session_state._pq:
        q = st.session_state._pq
        with st.spinner("🔄 Routing query across integrated systems…"):
            data = _mcp("chat", session_id=st.session_state.session_id, query=q)
        ts = datetime.now().strftime("%H:%M:%S")
        st.session_state.messages.append({
            "role":    "assistant",
            "content": data.get("answer", "No answer returned.") if data
                       else "⚠️ Backend did not respond.",
            "timestamp": ts,
            "meta": {
                "agents_used": data.get("agents_used", []) if data else [],
                "trace_id":    data.get("trace_id") if data else None,
            },
        })
        st.session_state.thinking = False
        st.session_state._pq      = None
        st.rerun()

    # History
    if not st.session_state.messages:
        st.markdown("""
        <div class="empty">
            <span>💬</span>
            <h3>Start a conversation</h3>
            <p>Ask about incidents, anomalies, root causes, or any integrated system.<br>
               Use the <b>Quick Actions</b> in the sidebar to get started quickly.</p>
        </div>""", unsafe_allow_html=True)
    else:
        for m in st.session_state.messages:
            _msg(m)

    # Input
    st.markdown("---")
    with st.form("chat_form", clear_on_submit=True):
        ci, cb = st.columns([5, 1])
        with ci:
            txt = st.text_area(
                "Query", height=80, label_visibility="collapsed",
                placeholder=(
                    "e.g. 'What were the root causes of the last 3 database outages?' "
                    "or 'Check Vital-12 and TSOP for INC0000000001234'"
                ),
            )
        with cb:
            st.markdown("<br/>", unsafe_allow_html=True)
            sent = st.form_submit_button(
                "Send 🚀", use_container_width=True, type="primary",
                disabled=st.session_state.thinking,
            )

    if sent and txt.strip():
        _submit(txt.strip())

    total = len(st.session_state.messages)
    if total:
        turns = total // 2
        st.caption(f"💬 {turns} turn{'s' if turns != 1 else ''} this session")


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def main():
    if not st.session_state.logged_in:
        _login()
    else:
        _sidebar()
        _chat()


if __name__ == "__main__":
    main()
