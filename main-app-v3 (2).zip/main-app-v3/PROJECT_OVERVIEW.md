# Project Overview

## Design principle

Everything that runs the backend lives in **`app/server.py`** — one file,
eight sections, easy to read from top to bottom. The scaffold directories
(`api/`, `graph/`, `services/`, `tests/`, `tools/`) exist for future growth:
split any section out when it outgrows a single file.

## Section map — `app/server.py`

| Section | Contents |
|---------|----------|
| 1 — Imports & config | Logging setup, settings singleton |
| 2 — HTTP factory | `_http()` shared client, RAN semaphore |
| 3 — Tools | 8 `BaseTool` subclasses + `_all_tools()` |
| 4 — Graph | `AgentState`, `_build_graph()`, `_get_graph()` |
| 5 — SessionService | `_Session`, `_SessionService`, `_sessions` singleton |
| 6 — GraphService | `_run_graph()` — Langfuse-traced graph execution |
| 7 — FastMCP server | `login`, `chat`, `get_history`, `clear_history`, `logout`, `health` |
| 8 — Entry point | `mcp.run(...)` |

## Supporting files

| File | Purpose |
|------|---------|
| `app/config/settings.py` | Pydantic-settings typed config |
| `app/core/models.py` | Shared Pydantic v2 models |
| `app/utils/__init__.py` | BM25Retriever + hybrid_rerank |
| `frontend/streamlit_app.py` | Full Streamlit chat UI |

## Concurrency design

| System | Mechanism |
|--------|-----------|
| RAN Chat | `asyncio.Semaphore(ran_chat_max_concurrent)` |
| All other tools | Parallel via LangGraph `ToolNode` |
| Session store | `threading.Lock` |

## Extending

To add a 9th system:
1. Add `Tool9Tool(BaseTool)` in Section 3 of `server.py`.
2. Register it in `_all_tools()`.
3. Add env vars to `.env.example` and `settings.py`.
4. The Head Agent discovers it automatically via `bind_tools()`.

To split out a section into its own module:
1. Create the file in the appropriate scaffold directory.
2. Import it at the top of `server.py`.
3. The scaffold dirs already exist — no structural changes needed.
