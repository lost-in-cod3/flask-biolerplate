# 🔍 Incident Analysis App

AI-powered incident triage. A single conversational interface routes queries
across eight integrated systems, correlates findings, and returns a synthesised
Markdown answer — in seconds.

## Architecture

```
Streamlit UI ──MCP HTTP──▶ FastMCP backend (app/server.py)
                                   │
                            LangGraph graph
                         head_agent (GPT-4o)
                                   │
              ┌────────────────────┼────────────────────┐
           Vital-12   RAN Chat   Confluence   SSP   TSOP×2
                                   │
                          synthesise (GPT-4o-mini)
                                   │
                            Markdown answer
```

## File map

```
app/
  server.py          ← everything: tools, graph, services, FastMCP
  config/settings.py ← typed env config
  core/models.py     ← shared Pydantic models
  utils/__init__.py  ← BM25Retriever + hybrid_rerank
  __init__.py
  api/  graph/  services/  tests/  tools/   ← scaffold (grow as needed)
frontend/
  streamlit_app.py   ← full Streamlit UI
```

## Quickstart

```bash
cp .env.example .env          # fill in credentials
pip install -r requirements.txt
./run_backend.sh              # → http://localhost:8000
./run_frontend.sh             # → http://localhost:8501
```

Docker:

```bash
docker-compose up --build
```

## Integrated systems

| # | System | Tool | Input |
|---|--------|------|-------|
| 1 | Vital-12 Anomalies | `vital12_anomaly_check` | Natural language |
| 2 | IMO RAN Chat | `ran_chat_query` | Single node/site |
| 3 | Confluence PIR | `confluence_pir_search` | Natural language |
| 4 | Confluence Workspace | `confluence_workspace_search` | Space key + query |
| 5 | Confluence Auto-RAG | `confluence_auto_rag` | Natural language |
| 6 | SSP | `ssp_address_search` | Street address |
| 7 | TSOP Search | `tsop_search` | INCxxxxxxxxxxxx / Cxxxxxxx |
| 8 | TSOP Power Health | `tsop_power_health` | 4-letter site code |
