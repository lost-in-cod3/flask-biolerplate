"""The Incident Analysis App."""

__version__ = "1.0.0"
__author__  = "Incident Analysis Team"
