"""
app/utils/bm25.py
─────────────────────────────────────────────────────────────────────────────
BM25Retriever — lexical retrieval over a fixed corpus of LangChain Documents.

Wraps rank_bm25's BM25Okapi with a simple interface that matches the pattern
of LangChain retrievers: retrieve() returns (Document, score) pairs,
retrieve_docs() returns Documents only.

Usage
─────
    from app.utils.bm25 import BM25Retriever

    retriever = BM25Retriever(documents)
    docs      = retriever.retrieve_docs("database outage", k=5)
"""

from __future__ import annotations

import logging
from typing import List, Tuple

from langchain_core.documents import Document

logger = logging.getLogger(__name__)

# ── rank_bm25 availability guard ──────────────────────────────────────────────
try:
    from rank_bm25 import BM25Okapi
    _AVAILABLE = True
except ImportError:
    _AVAILABLE = False
    logger.warning(
        "rank_bm25 not installed — BM25 retrieval disabled. "
        "Install with:  pip install rank-bm25"
    )


def _tokenise(text: str) -> List[str]:
    """Lowercase whitespace tokeniser — sufficient for incident text."""
    return text.lower().split()


class BM25Retriever:
    """
    Lexical BM25 retriever over a fixed corpus of LangChain Documents.

    Parameters
    ──────────
    documents : List[Document]
        Corpus to index. Re-instantiate when the corpus changes.

    Raises
    ──────
    ImportError  — if rank_bm25 is not installed.
    ValueError   — if documents list is empty.
    """

    def __init__(self, documents: List[Document]) -> None:
        if not _AVAILABLE:
            raise ImportError(
                "rank_bm25 is required for BM25 retrieval. "
                "Install with:  pip install rank-bm25"
            )
        if not documents:
            raise ValueError("BM25Retriever requires at least one document.")

        self._docs = documents
        self._bm25 = BM25Okapi([_tokenise(d.page_content) for d in documents])
        logger.debug("BM25Retriever: indexed %d documents.", len(documents))

    def retrieve(self, query: str, k: int = 5) -> List[Tuple[Document, float]]:
        """
        Return top-k (Document, score) tuples sorted descending by score.
        Documents with a zero score are excluded.
        """
        scores = self._bm25.get_scores(_tokenise(query))
        ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)
        return [(self._docs[i], float(s)) for i, s in ranked[:k] if s > 0]

    def retrieve_docs(self, query: str, k: int = 5) -> List[Document]:
        """Return top-k Documents (without scores)."""
        return [doc for doc, _ in self.retrieve(query, k=k)]
