"""
app/utils/rerank.py
─────────────────────────────────────────────────────────────────────────────
hybrid_rerank — reciprocal-rank fusion of semantic and BM25 result lists.

Documents appearing in both lists receive a combined score boost.
Returns a deduplicated list sorted by fused score descending — no ML
model required.

Usage
─────
    from app.utils.rerank import hybrid_rerank

    final_docs = hybrid_rerank(semantic_docs, bm25_docs)
"""

from __future__ import annotations

from typing import List, Tuple

from langchain_core.documents import Document


def hybrid_rerank(
    semantic_docs:   List[Document],
    bm25_docs:       List[Document],
    semantic_weight: float = 0.7,
    bm25_weight:     float = 0.3,
) -> List[Document]:
    """
    Reciprocal-rank fusion of semantic and BM25 result lists.

    Parameters
    ──────────
    semantic_docs    : Ranked results from vector/semantic search (best first).
    bm25_docs        : Ranked results from BM25 retrieval (best first).
    semantic_weight  : Contribution weight for semantic rank (default 0.7).
    bm25_weight      : Contribution weight for BM25 rank (default 0.3).

    Returns
    ───────
    Deduplicated list of Documents sorted by fused score descending.
    """
    seen:   set[str]                     = set()
    merged: List[Tuple[Document, float]] = []

    def _key(doc: Document) -> str:
        return doc.page_content[:120]

    # Seed with semantic results
    for rank, doc in enumerate(semantic_docs):
        k = _key(doc)
        if k not in seen:
            seen.add(k)
            merged.append((doc, semantic_weight / (rank + 1)))

    # Merge BM25 — boost existing entries, append new ones
    for rank, doc in enumerate(bm25_docs):
        k     = _key(doc)
        delta = bm25_weight / (rank + 1)
        if k in seen:
            for i, (d, s) in enumerate(merged):
                if _key(d) == k:
                    merged[i] = (d, s + delta)
                    break
        else:
            seen.add(k)
            merged.append((doc, delta))

    merged.sort(key=lambda x: x[1], reverse=True)
    return [doc for doc, _ in merged]
