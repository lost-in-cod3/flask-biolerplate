"""
app/tools/confluence.py
─────────────────────────────────────────────────────────────────────────────
Three Confluence tools sharing a common CQL search helper:

  ConfluencePIRTool        — PIR Library in the Problem Management workspace
  ConfluenceWorkspaceTool  — any user-specified Confluence workspace/space key
  ConfluenceAutoRAGTool    — auto-RAG search across a designated space (early testing)
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Type

import httpx
from langchain.tools import BaseTool
from pydantic import BaseModel, Field

from app.config.settings import get_settings

logger   = logging.getLogger(__name__)
settings = get_settings()


# ─────────────────────────────────────────────────────────────────────────────
# Shared CQL search helper
# ─────────────────────────────────────────────────────────────────────────────

async def _cql_search(query: str, space_key: str, limit: int, label: str) -> str:
    """Execute a CQL content search against the Confluence REST API."""
    t0     = time.monotonic()
    auth   = (settings.confluence_username, settings.confluence_api_token)
    params = {
        "cql":    f'space="{space_key}" AND text ~ "{query}" ORDER BY lastModified DESC',
        "limit":  limit,
        "expand": "excerpt,space",
    }
    try:
        async with httpx.AsyncClient(
            base_url=settings.confluence_url, auth=auth, timeout=30
        ) as c:
            r = await c.get("/rest/api/content/search", params=params)
            r.raise_for_status()
            results: list[dict] = r.json().get("results", [])
    except Exception as exc:
        logger.warning("[Confluence %s] %s", label, exc)
        return f"[Confluence {label} ERROR] {exc}"

    ms = round((time.monotonic() - t0) * 1000, 1)
    if not results:
        return f"Confluence {label}: no results for '{query}' ({ms}ms)"

    lines = [f"Confluence {label} — top {len(results)} results ({ms}ms):"]
    for res in results:
        title   = res.get("title", "Untitled")
        excerpt = res.get("excerpt", "")[:200].replace("\n", " ")
        url     = settings.confluence_url + res.get("_links", {}).get("webui", "")
        lines.append(f"  • {title}\n    {excerpt}\n    {url}")
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Tool 1 of 3 — PIR Library
# ─────────────────────────────────────────────────────────────────────────────

class _PIRInput(BaseModel):
    query: str = Field(description="Search terms for PIR (Post Incident Review) documents.")
    limit: int = Field(default=5, description="Max results (1–10).")


class ConfluencePIRTool(BaseTool):
    name:        str             = "confluence_pir_search"
    description: str             = (
        "Search the Confluence PIR (Post Incident Review) library in the "
        "Problem Management workspace. Use for questions about previous incident "
        "reviews, root causes from past incidents, or PIR documents."
    )
    args_schema: Type[BaseModel] = _PIRInput

    def _run(self, query: str, limit: int = 5) -> str:
        return asyncio.get_event_loop().run_until_complete(self._arun(query, limit))

    async def _arun(self, query: str, limit: int = 5) -> str:
        return await _cql_search(
            query, settings.confluence_pir_space_key, limit, "PIR Library"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Tool 2 of 3 — Workspace-specific search
# ─────────────────────────────────────────────────────────────────────────────

class _WorkspaceInput(BaseModel):
    query:     str = Field(description="Search terms.")
    workspace: str = Field(description="Confluence space key named by the user (e.g. NETOPS).")
    limit:     int = Field(default=5, description="Max results (1–10).")


class ConfluenceWorkspaceTool(BaseTool):
    name:        str             = "confluence_workspace_search"
    description: str             = (
        "Search Confluence within a specific workspace/space key provided by the user. "
        "Use when the user explicitly names a Confluence space or workspace."
    )
    args_schema: Type[BaseModel] = _WorkspaceInput

    def _run(self, query: str, workspace: str, limit: int = 5) -> str:
        return asyncio.get_event_loop().run_until_complete(
            self._arun(query, workspace, limit)
        )

    async def _arun(self, query: str, workspace: str, limit: int = 5) -> str:
        return await _cql_search(
            query, workspace.upper(), limit, f"Workspace:{workspace}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Tool 3 of 3 — Auto-RAG
# ─────────────────────────────────────────────────────────────────────────────

class _AutoRAGInput(BaseModel):
    query: str = Field(description="Natural-language question for Auto-RAG Confluence search.")


class ConfluenceAutoRAGTool(BaseTool):
    name:        str             = "confluence_auto_rag"
    description: str             = (
        "Auto-RAG (retrieval-augmented) Confluence search — early testing. "
        "Use when no specific space is known or other Confluence tools are insufficient."
    )
    args_schema: Type[BaseModel] = _AutoRAGInput

    def _run(self, query: str) -> str:
        return asyncio.get_event_loop().run_until_complete(self._arun(query))

    async def _arun(self, query: str) -> str:
        return await _cql_search(
            query, settings.confluence_auto_rag_space_key, 5, "Auto-RAG"
        )
