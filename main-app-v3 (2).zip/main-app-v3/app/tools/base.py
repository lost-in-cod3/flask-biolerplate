"""
app/tools/base.py
─────────────────────────────────────────────────────────────────────────────
Shared infrastructure used by every tool module:

  _http()    — returns a configured httpx.AsyncClient for an internal system
  _ran_sem   — asyncio.Semaphore that enforces the RAN Chat concurrency limit
"""

from __future__ import annotations

import asyncio

import httpx

from app.config.settings import get_settings

settings = get_settings()

# ── Semaphore — limits in-flight RAN Chat calls to the production-safe maximum
_ran_sem = asyncio.Semaphore(settings.ran_chat_max_concurrent)


def _http(base_url: str, api_key: str, timeout: float = 30.0) -> httpx.AsyncClient:
    """Return a configured async HTTP client for internal-system API calls."""
    return httpx.AsyncClient(
        base_url=base_url,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type":  "application/json",
        },
        timeout=timeout,
    )
