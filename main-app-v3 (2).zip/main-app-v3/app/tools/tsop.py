"""
app/tools/tsop.py
─────────────────────────────────────────────────────────────────────────────
Two TSOP tools:

  TSOPSearchTool       — fetch an incident (INCxxxxxxxxxxxx) or conen (Cxxxxxxx)
  TSOPPowerHealthTool  — check power health for a 4-letter site code

Both validate the input format before making any HTTP call and return a
descriptive error string on validation or HTTP failure.
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import Type

import httpx
from langchain.tools import BaseTool
from pydantic import BaseModel, Field

from app.config.settings import get_settings
from app.tools.base import _http

logger   = logging.getLogger(__name__)
settings = get_settings()

# ── Reference-format validation patterns ──────────────────────────────────────
_INC_RE   = re.compile(r"^INC\d{13}$",  re.IGNORECASE)
_CONEN_RE = re.compile(r"^C\d{7}$",     re.IGNORECASE)
_SITE_RE  = re.compile(r"^[A-Z]{4}$")


# ─────────────────────────────────────────────────────────────────────────────
# TSOPSearchTool — incident / conen lookup
# ─────────────────────────────────────────────────────────────────────────────

class _SearchInput(BaseModel):
    reference: str = Field(description=(
        "TSOP reference: INCxxxxxxxxxxxx (INC + 13 digits) "
        "or Cxxxxxxx (C + 7 digits)."
    ))


class TSOPSearchTool(BaseTool):
    name:        str             = "tsop_search"
    description: str             = (
        "Search TSOP for an incident (INCxxxxxxxxxxxx) or conen (Cxxxxxxx). "
        "Returns status, root cause, and related items."
    )
    args_schema: Type[BaseModel] = _SearchInput

    def _run(self, reference: str) -> str:
        return asyncio.get_event_loop().run_until_complete(self._arun(reference))

    async def _arun(self, reference: str) -> str:
        ref = reference.strip().upper()

        if _INC_RE.match(ref):
            endpoint, kind = f"/incidents/{ref}", "Incident"
        elif _CONEN_RE.match(ref):
            endpoint, kind = f"/conens/{ref}", "Conen"
        else:
            return (
                f"[TSOP ERROR] Invalid reference '{reference}'. "
                "Expected INCxxxxxxxxxxxx (INC + 13 digits) or Cxxxxxxx (C + 7 digits)."
            )

        t0 = time.monotonic()
        try:
            async with _http(settings.tsop_base_url, settings.tsop_api_key) as c:
                r = await c.get(endpoint)
                r.raise_for_status()
                data = r.json()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                return f"[TSOP] {kind} '{ref}' not found."
            return f"[TSOP ERROR] {exc}"
        except Exception as exc:
            logger.warning("[TSOP] %s", exc)
            return f"[TSOP ERROR] {exc}"

        ms    = round((time.monotonic() - t0) * 1000, 1)
        lines = [f"TSOP {kind} — {ref} ({ms}ms):"]
        for key in ("title", "status", "priority", "root_cause",
                    "description", "created_at", "resolved_at"):
            if val := data.get(key):
                lines.append(f"  {key.replace('_', ' ').title()}: {val}")
        if related := data.get("related", []):
            lines.append(f"  Related: {', '.join(related[:5])}")
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# TSOPPowerHealthTool — power health by 4-letter site code
# ─────────────────────────────────────────────────────────────────────────────

class _PowerInput(BaseModel):
    site_code: str = Field(description="4-letter TSOP site code (e.g. AMST).")


class TSOPPowerHealthTool(BaseTool):
    name:        str             = "tsop_power_health"
    description: str             = (
        "Check TSOP power health for a site using its 4-letter site code. "
        "Use when the user asks about power health, power status, or gives a 4-letter code."
    )
    args_schema: Type[BaseModel] = _PowerInput

    def _run(self, site_code: str) -> str:
        return asyncio.get_event_loop().run_until_complete(self._arun(site_code))

    async def _arun(self, site_code: str) -> str:
        code = site_code.strip().upper()
        if not _SITE_RE.match(code):
            return (
                f"[TSOP Power Health ERROR] Site code must be exactly 4 letters. "
                f"Got: '{site_code}'"
            )

        t0 = time.monotonic()
        try:
            async with _http(settings.tsop_base_url, settings.tsop_api_key) as c:
                r = await c.get(f"/power-health/{code}")
                r.raise_for_status()
                data = r.json()
        except Exception as exc:
            logger.warning("[TSOP Power Health] %s", exc)
            return f"[TSOP Power Health ERROR] {exc}"

        ms         = round((time.monotonic() - t0) * 1000, 1)
        status     = data.get("status", "unknown").upper()
        components = data.get("components", [])
        alerts     = data.get("alerts", [])

        lines = [f"TSOP Power Health — {code} ({ms}ms):  Overall: {status}"]
        if components:
            lines.append("  Components: " + "  ".join(
                f"{c.get('name', '?')}:{c.get('status', '?')}" for c in components[:8]
            ))
        if alerts:
            lines.extend([f"  ⚠ {a}" for a in alerts[:5]])
        else:
            lines.append("  No active alerts.")
        return "\n".join(lines)
