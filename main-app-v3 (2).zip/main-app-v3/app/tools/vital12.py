"""
app/tools/vital12.py
─────────────────────────────────────────────────────────────────────────────
Vital12Tool — queries the Vital-12 anomaly detection system.

Accepts a natural-language description of what to check (node, site, or
time window) and returns a formatted list of detected anomalies.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Type

from langchain.tools import BaseTool
from pydantic import BaseModel, Field

from app.config.settings import get_settings
from app.core.models import AnomalyResult
from app.tools.base import _http

logger   = logging.getLogger(__name__)
settings = get_settings()


class _Input(BaseModel):
    query: str = Field(description=(
        "Natural-language description of what to check — node, site, "
        "or time-window for anomaly detection."
    ))


class Vital12Tool(BaseTool):
    name:        str             = "vital12_anomaly_check"
    description: str             = (
        "Check Vital-12 for network anomalies. Use when the user asks about "
        "anomalies, unusual behaviour, or Vital-12. "
        "Input: natural-language description of what to check."
    )
    args_schema: Type[BaseModel] = _Input

    def _run(self, query: str) -> str:
        return asyncio.get_event_loop().run_until_complete(self._arun(query))

    async def _arun(self, query: str) -> str:
        t0 = time.monotonic()
        try:
            async with _http(settings.vital12_base_url, settings.vital12_api_key) as c:
                r = await c.post("/anomalies/search", json={"query": query})
                r.raise_for_status()
                items: list[dict] = r.json().get("results", [])
        except Exception as exc:
            logger.warning("[Vital-12] %s", exc)
            return f"[Vital-12 ERROR] {exc}"

        ms = round((time.monotonic() - t0) * 1000, 1)
        if not items:
            return f"Vital-12: no anomalies found for '{query}' ({ms}ms)"

        lines = [f"Vital-12 anomalies ({ms}ms):"]
        for raw in items[:10]:
            a   = AnomalyResult(**raw)
            ref = f" → related: {a.related_incident}" if a.related_incident else ""
            lines.append(f"  • [{a.severity.upper()}] {a.anomaly_id}: {a.description}{ref}")
        return "\n".join(lines)
