"""
app/tools/ssp.py
─────────────────────────────────────────────────────────────────────────────
SSPTool — looks up service status and active incidents by street address
via the Service Status Platform (SSP).
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Type

from langchain.tools import BaseTool
from pydantic import BaseModel, Field

from app.config.settings import get_settings
from app.tools.base import _http

logger   = logging.getLogger(__name__)
settings = get_settings()


class _Input(BaseModel):
    street_address: str = Field(description="Full street address to look up in the SSP.")


class SSPTool(BaseTool):
    name:        str             = "ssp_address_search"
    description: str             = (
        "Search the Service Status Platform (SSP) by street address. "
        "Use when the user provides an address to check service status or outages."
    )
    args_schema: Type[BaseModel] = _Input

    def _run(self, street_address: str) -> str:
        return asyncio.get_event_loop().run_until_complete(self._arun(street_address))

    async def _arun(self, street_address: str) -> str:
        t0 = time.monotonic()
        try:
            async with _http(settings.ssp_base_url, settings.ssp_api_key) as c:
                r = await c.get("/status", params={"address": street_address})
                r.raise_for_status()
                data = r.json()
        except Exception as exc:
            logger.warning("[SSP] %s", exc)
            return f"[SSP ERROR] {exc}"

        ms        = round((time.monotonic() - t0) * 1000, 1)
        status    = data.get("status", "unknown").upper()
        services  = data.get("services", [])
        incidents = data.get("active_incidents", [])

        lines = [f"SSP status for '{street_address}' ({ms}ms):  Overall: {status}"]
        if services:
            lines.append("  Services: " + ", ".join(
                f"{s['name']}={s.get('status', '?')}" for s in services
            ))
        lines.append(
            "  Active incidents: " + ("; ".join(incidents[:5]) if incidents else "none")
        )
        return "\n".join(lines)
