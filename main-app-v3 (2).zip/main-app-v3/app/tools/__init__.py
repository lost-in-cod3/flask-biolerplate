"""
app/tools/__init__.py
─────────────────────────────────────────────────────────────────────────────
Re-exports all tool classes and the get_all_tools() registry.

Tool implementations live in their own named modules:
  base.py        — shared HTTP client factory and RAN semaphore
  vital12.py     — Vital12Tool
  ran_chat.py    — RANChatTool
  confluence.py  — ConfluencePIRTool, ConfluenceWorkspaceTool, ConfluenceAutoRAGTool
  ssp.py         — SSPTool
  tsop.py        — TSOPSearchTool, TSOPPowerHealthTool
"""

from langchain.tools import BaseTool

from app.tools.confluence import (
    ConfluenceAutoRAGTool,
    ConfluencePIRTool,
    ConfluenceWorkspaceTool,
)
from app.tools.ran_chat import RANChatTool
from app.tools.ssp import SSPTool
from app.tools.tsop import TSOPPowerHealthTool, TSOPSearchTool
from app.tools.vital12 import Vital12Tool


def get_all_tools() -> list[BaseTool]:
    """Instantiate and return all eight tool instances."""
    return [
        Vital12Tool(),
        RANChatTool(),
        ConfluencePIRTool(),
        ConfluenceWorkspaceTool(),
        ConfluenceAutoRAGTool(),
        SSPTool(),
        TSOPSearchTool(),
        TSOPPowerHealthTool(),
    ]


__all__ = [
    "Vital12Tool",
    "RANChatTool",
    "ConfluencePIRTool",
    "ConfluenceWorkspaceTool",
    "ConfluenceAutoRAGTool",
    "SSPTool",
    "TSOPSearchTool",
    "TSOPPowerHealthTool",
    "get_all_tools",
]
