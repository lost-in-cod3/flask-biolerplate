"""
app/tools/ran_chat.py
─────────────────────────────────────────────────────────────────────────────
RANChatTool — queries the IMO RAN Chat for a single node or site.

A production asyncio.Semaphore (from app.tools.base) limits concurrent
in-flight calls to the value of RAN_CHAT_MAX_CONCURRENT.

Important: this tool must be invoked once per target — never batched.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Type

from langchain.tools import BaseTool
from pydantic import BaseModel, Field

from app.config.settings import get_settings
from app.tools.base import _http, _ran_sem

logger   = logging.getLogger(__name__)
settings = get_settings()


class _Input(BaseModel):
    target: str = Field(description="Single RAN node ID or single site name — never batch.")
    query:  str = Field(description="Question or command to send to the RAN Chat.")


class RANChatTool(BaseTool):
    name:        str             = "ran_chat_query"
    description: str             = (
        "Query the IMO RAN Chat for a SINGLE node or SINGLE site. "
        "Invoke once per target — never batch multiple nodes in one call."
    )
    args_schema: Type[BaseModel] = _Input

    def _run(self, target: str, query: str) -> str:
        return asyncio.get_event_loop().run_until_complete(self._arun(target, query))

    async def _arun(self, target: str, query: str) -> str:
        async with _ran_sem:                               # ← production rate-guard
            t0 = time.monotonic()
            try:
                async with _http(settings.ran_chat_base_url, settings.ran_chat_api_key) as c:
                    r = await c.post("/query", json={"target": target, "question": query})
                    r.raise_for_status()
                    data = r.json()
            except Exception as exc:
                logger.warning("[RAN Chat] target=%s  %s", target, exc)
                return f"[RAN Chat ERROR] target={target}: {exc}"

        ms = round((time.monotonic() - t0) * 1000, 1)
        return f"RAN Chat [{target}] ({ms}ms):\n{data.get('answer', 'No answer returned.')}"
