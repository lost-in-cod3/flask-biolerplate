"""
app/config/settings.py
═══════════════════════════════════════════════════════════════════════════════
Central application settings loaded from environment variables / .env file.
Uses pydantic-settings for typed, validated configuration.

Import pattern (namespace package — no __init__.py required):
    from app.config.settings import get_settings, Settings
"""

from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Application ──────────────────────────────────────────────────────────
    app_env:        str = "development"       # development | staging | production
    app_secret_key: str = "change-me-in-production"
    log_level:      str = "INFO"

    # ── Static Auth ──────────────────────────────────────────────────────────
    auth_username: str = "admin"
    auth_password: str = "admin123"

    # ── FastMCP Server ───────────────────────────────────────────────────────
    mcp_host: str = "0.0.0.0"
    mcp_port: int = 8000

    # ── OpenAI ───────────────────────────────────────────────────────────────
    openai_api_key:   str = Field(default="", alias="OPENAI_API_KEY")
    openai_model:     str = "gpt-4o"
    openai_mini_model: str = "gpt-4o-mini"

    # Azure OpenAI (leave blank to use standard OpenAI)
    azure_openai_api_key:    str = ""
    azure_openai_endpoint:   str = ""
    azure_openai_deployment: str = ""
    azure_openai_api_version: str = "2024-02-01"

    # ── Langfuse ─────────────────────────────────────────────────────────────
    langfuse_public_key: str = ""
    langfuse_secret_key: str = ""
    langfuse_host:       str = "https://cloud.langfuse.com"

    # ── Confluence ───────────────────────────────────────────────────────────
    confluence_url:               str = ""
    confluence_username:          str = ""
    confluence_api_token:         str = ""
    confluence_pir_space_key:     str = "PM"   # Problem Management
    confluence_auto_rag_space_key: str = "RAG"

    # ── Vital-12 ─────────────────────────────────────────────────────────────
    vital12_base_url: str = ""
    vital12_api_key:  str = ""

    # ── IMO RAN Chat ─────────────────────────────────────────────────────────
    ran_chat_base_url:       str = ""
    ran_chat_api_key:        str = ""
    ran_chat_max_concurrent: int = 3   # production concurrency limit

    # ── Service Status Platform ───────────────────────────────────────────────
    ssp_base_url: str = ""
    ssp_api_key:  str = ""

    # ── TSOP ─────────────────────────────────────────────────────────────────
    tsop_base_url: str = ""
    tsop_api_key:  str = ""

    # ── Vector Store (optional RAG) ───────────────────────────────────────────
    chroma_persist_dir: str = "./chroma_db"
    embedding_model:    str = "text-embedding-3-small"

    # ── Computed helpers ──────────────────────────────────────────────────────
    @property
    def is_production(self) -> bool:
        return self.app_env.lower() == "production"

    @property
    def use_azure(self) -> bool:
        return bool(self.azure_openai_endpoint)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the cached Settings singleton."""
    return Settings()
