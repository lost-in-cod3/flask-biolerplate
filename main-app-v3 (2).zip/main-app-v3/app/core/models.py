"""
app/core/models.py
═══════════════════════════════════════════════════════════════════════════════
Shared Pydantic v2 domain models used across the entire application.

Import pattern (namespace package — no __init__.py required):
    from app.core.models import AgentType, FinalResponse, ChatMessage
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ─────────────────────────────────────────────────────────────────────────────
# Enumerations
# ─────────────────────────────────────────────────────────────────────────────

class AgentType(str, Enum):
    HEAD       = "head"
    CONFLUENCE = "confluence"
    VITAL12    = "vital12"
    RAN_CHAT   = "ran_chat"
    TSOP       = "tsop"
    SSP        = "ssp"


class SearchType(str, Enum):
    PIR_LIBRARY = "pir_library"
    WORKSPACE   = "workspace"
    AUTO_RAG    = "auto_rag"


# ─────────────────────────────────────────────────────────────────────────────
# Conversation / session
# ─────────────────────────────────────────────────────────────────────────────

class ChatMessage(BaseModel):
    role:      str                                          # user | assistant | system
    content:   str
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class UserQuery(BaseModel):
    session_id: str
    query:      str
    history:    List[ChatMessage]    = Field(default_factory=list)
    metadata:   Dict[str, Any]       = Field(default_factory=dict)


# ─────────────────────────────────────────────────────────────────────────────
# Agent I/O
# ─────────────────────────────────────────────────────────────────────────────

class AgentResponse(BaseModel):
    agent_type: AgentType
    content:    str
    raw_data:   Optional[Dict[str, Any]] = None
    sources:    List[str]                = Field(default_factory=list)
    error:      Optional[str]            = None
    latency_ms: Optional[float]          = None


class FinalResponse(BaseModel):
    session_id:  str
    answer:      str
    agents_used: List[AgentType] = Field(default_factory=list)
    sources:     List[str]       = Field(default_factory=list)
    trace_id:    Optional[str]   = None
    timestamp:   datetime        = Field(default_factory=datetime.utcnow)


# ─────────────────────────────────────────────────────────────────────────────
# Tool-level models
# ─────────────────────────────────────────────────────────────────────────────

class AnomalyResult(BaseModel):
    anomaly_id:       str
    description:      str
    severity:         str
    detected_at:      Optional[datetime] = None
    related_incident: Optional[str]      = None


class ConfluencePage(BaseModel):
    page_id:      str
    title:        str
    url:          str
    excerpt:      str
    space_key:    str
    last_updated: Optional[datetime] = None


class SSPResult(BaseModel):
    address:   str
    status:    str
    services:  List[Dict[str, Any]] = Field(default_factory=list)
    incidents: List[str]            = Field(default_factory=list)


class TSOPResult(BaseModel):
    reference:      str
    reference_type: str                    # "incident" | "conen"
    title:          Optional[str]      = None
    status:         Optional[str]      = None
    root_cause:     Optional[str]      = None
    description:    Optional[str]      = None
    created_at:     Optional[datetime] = None
    resolved_at:    Optional[datetime] = None
    related:        List[str]          = Field(default_factory=list)


class PowerHealthResult(BaseModel):
    site_code:   str
    status:      str
    components:  List[Dict[str, Any]] = Field(default_factory=list)
    alerts:      List[str]            = Field(default_factory=list)
    checked_at:  datetime             = Field(default_factory=datetime.utcnow)
