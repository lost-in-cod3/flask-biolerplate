"""
app/server.py
═══════════════════════════════════════════════════════════════════════════════
The Incident Analysis App — FastMCP backend.

  SECTION 1  ── Imports & configuration
  SECTION 2  ── LangGraph agent graph (AgentState + builder)
  SECTION 3  ── SessionService  (in-memory, thread-safe, TTL-based)
  SECTION 4  ── GraphService    (graph execution + Langfuse tracing)
  SECTION 5  ── FastMCP server  (login / chat / history / health MCP tools)
  SECTION 6  ── Entry point

Tools for all 8 integrated systems live in app/tools/__init__.py.

Run:
    python -m app.server
    ./run_backend.sh
"""

from __future__ import annotations

# =============================================================================
# SECTION 1 — Imports & configuration
# =============================================================================

import logging
import sys
import time
import uuid
from datetime import datetime, timedelta
from threading import Lock
from typing import Annotated, Any, Dict, List, Literal, Optional, Sequence

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from typing_extensions import TypedDict

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from app.config.settings import get_settings
from app.core.models import AgentType, ChatMessage, FinalResponse
from app.tools import get_all_tools

settings = get_settings()

# Logging
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


# =============================================================================
# SECTION 2 — LangGraph agent graph
# =============================================================================

class AgentState(TypedDict):
    """Mutable state threaded through every graph node."""
    messages:       Annotated[Sequence[BaseMessage], add_messages]
    agent_route:    Optional[str]
    agents_invoked: List[str]
    tool_results:   List[Dict[str, Any]]
    final_answer:   Optional[str]
    session_id:     str
    trace_id:       Optional[str]
    user_query:     str


_HEAD_PROMPT = """\
You are the Head Orchestration Agent for the Incident Analysis App.
Analyse the user query and call ALL tools that are relevant — often more than one.

Available tools
───────────────
• vital12_anomaly_check       → anomalies, unusual behaviour, Vital-12
• ran_chat_query              → specific RAN node or site (one invocation per target)
• confluence_pir_search       → PIRs, previous incidents, root causes
• confluence_workspace_search → named Confluence workspace/space
• confluence_auto_rag         → open-ended Confluence search (no space specified)
• ssp_address_search          → street address → service status
• tsop_search                 → INCxxxxxxxxxxxx or Cxxxxxxx reference
• tsop_power_health           → 4-letter site code → power health

Rules
─────
1. Call every relevant tool — prefer more over fewer.
2. RAN Chat: one call per node/site, never batched.
3. Never guess — only relay what tools return.
"""

_SYNTH_PROMPT = """\
You are a senior network operations analyst.
Synthesise the tool results into a clear, actionable Markdown answer.

Guidelines
──────────
• Lead with the most actionable finding.
• Explicitly surface anomalies, root causes, or cross-system patterns.
• Acknowledge tool errors briefly and continue with available data.
• Close every response with a ## Sources section listing systems queried.
"""


def _llm(model: str) -> ChatOpenAI:
    if settings.use_azure:
        from langchain_openai import AzureChatOpenAI
        return AzureChatOpenAI(
            azure_deployment=settings.azure_openai_deployment,
            azure_endpoint=settings.azure_openai_endpoint,
            api_key=settings.azure_openai_api_key,
            api_version=settings.azure_openai_api_version,
            temperature=0.0,
        )
    return ChatOpenAI(
        model=model,
        api_key=settings.openai_api_key,
        temperature=0.0,
    )


def _build_graph() -> Any:
    tools     = get_all_tools()
    tool_node = ToolNode(tools)
    head_llm  = _llm(settings.openai_model).bind_tools(tools)
    synth_llm = _llm(settings.openai_mini_model)

    def head_agent(state: AgentState) -> Dict[str, Any]:
        logger.info("[head_agent] session=%s", state["session_id"])
        resp: AIMessage = head_llm.invoke(
            [SystemMessage(content=_HEAD_PROMPT), *state["messages"]]
        )
        invoked = [tc["name"] for tc in (resp.tool_calls or [])]
        logger.info("[head_agent] tools=%s", invoked)
        return {
            "messages":       [resp],
            "agents_invoked": state.get("agents_invoked", []) + invoked,
            "agent_route":    invoked[0] if invoked else "none",
        }

    def synthesise(state: AgentState) -> Dict[str, Any]:
        logger.info("[synthesise] session=%s", state["session_id"])
        tool_text = "\n\n".join(
            f"=== {m.name} ===\n{m.content}"
            for m in state["messages"]
            if hasattr(m, "name") and m.name
            and not isinstance(m, (HumanMessage, AIMessage))
        )
        if not tool_text:
            for m in reversed(list(state["messages"])):
                if isinstance(m, AIMessage) and m.content:
                    return {"final_answer": str(m.content)}
            return {"final_answer": "Unable to retrieve the requested information."}

        ans: AIMessage = synth_llm.invoke([
            SystemMessage(content=_SYNTH_PROMPT),
            HumanMessage(content=f"User query: {state['user_query']}\n\n{tool_text}"),
        ])
        return {"final_answer": str(ans.content)}

    def _route(state: AgentState) -> Literal["tools", "synthesise"]:
        last = state["messages"][-1]
        return "tools" if isinstance(last, AIMessage) and last.tool_calls else "synthesise"

    g = StateGraph(AgentState)
    g.add_node("head_agent", head_agent)
    g.add_node("tools",      tool_node)
    g.add_node("synthesise", synthesise)
    g.add_edge(START, "head_agent")
    g.add_conditional_edges("head_agent", _route,
                            {"tools": "tools", "synthesise": "synthesise"})
    g.add_edge("tools",      "synthesise")
    g.add_edge("synthesise", END)
    return g.compile()


_graph: Any = None

def _get_graph() -> Any:
    global _graph
    if _graph is None:
        _graph = _build_graph()
    return _graph


# =============================================================================
# SECTION 3 — SessionService
# =============================================================================

class _Session:
    __slots__ = ("session_id", "username", "history", "created_at", "last_active")

    def __init__(self, session_id: str, username: str) -> None:
        self.session_id:  str               = session_id
        self.username:    str               = username
        self.history:     List[ChatMessage] = []
        self.created_at:  datetime          = datetime.utcnow()
        self.last_active: datetime          = datetime.utcnow()

    def add(self, role: str, content: str) -> ChatMessage:
        msg = ChatMessage(role=role, content=content)
        self.history.append(msg)
        self.last_active = datetime.utcnow()
        return msg

    def expired(self, ttl: int) -> bool:
        return datetime.utcnow() - self.last_active > timedelta(minutes=ttl)


class _SessionService:
    """Thread-safe in-memory session store with TTL-based expiry."""

    def __init__(self, ttl_minutes: int = 60) -> None:
        self._store: Dict[str, _Session] = {}
        self._lock  = Lock()
        self._ttl   = ttl_minutes

    def create(self, username: str) -> _Session:
        s = _Session(session_id=str(uuid.uuid4()), username=username)
        with self._lock:
            self._store[s.session_id] = s
        logger.info("Session created  id=%s  user=%s", s.session_id[:8], username)
        return s

    def get(self, sid: str) -> Optional[_Session]:
        with self._lock:
            s = self._store.get(sid)
            if s is None:
                return None
            if s.expired(self._ttl):
                del self._store[sid]
                logger.info("Session expired  id=%s", sid[:8])
                return None
            return s

    def delete(self, sid: str) -> bool:
        with self._lock:
            return self._store.pop(sid, None) is not None

    def purge(self) -> int:
        with self._lock:
            dead = [k for k, s in self._store.items() if s.expired(self._ttl)]
            for k in dead:
                del self._store[k]
        return len(dead)

    def count(self) -> int:
        with self._lock:
            return len(self._store)


_sessions = _SessionService()


# =============================================================================
# SECTION 4 — GraphService (Langfuse-traced graph execution)
# =============================================================================

def _init_langfuse():
    if not (settings.langfuse_public_key and settings.langfuse_secret_key):
        logger.info("Langfuse credentials absent — tracing disabled.")
        return None
    try:
        from langfuse import Langfuse
        lf = Langfuse(
            public_key=settings.langfuse_public_key,
            secret_key=settings.langfuse_secret_key,
            host=settings.langfuse_host,
        )
        logger.info("Langfuse tracing enabled.")
        return lf
    except Exception as exc:
        logger.warning("Langfuse init failed — tracing disabled: %s", exc)
        return None


_langfuse = _init_langfuse()

_AGENT_MAP = {
    "vital12":    AgentType.VITAL12,
    "ran_chat":   AgentType.RAN_CHAT,
    "confluence": AgentType.CONFLUENCE,
    "ssp":        AgentType.SSP,
    "tsop":       AgentType.TSOP,
}


async def _run_graph(query: str, session: _Session) -> FinalResponse:
    """Execute the agent graph for one user query, wrapped in a Langfuse trace."""
    trace_id = str(uuid.uuid4())
    t0       = time.monotonic()

    history = [
        HumanMessage(content=m.content) if m.role == "user"
        else type("_AI", (), {"content": m.content, "type": "ai"})()
        for m in session.history[-10:]
    ]

    callbacks: list = []
    if _langfuse:
        try:
            from langfuse.callback import CallbackHandler as _LF
            callbacks.append(_LF(
                public_key=settings.langfuse_public_key,
                secret_key=settings.langfuse_secret_key,
                host=settings.langfuse_host,
                trace_name="incident_analysis",
                session_id=session.session_id,
                user_id=session.username,
                metadata={"query": query},
                tags=["incident-app", settings.app_env],
            ))
        except Exception as exc:
            logger.warning("Langfuse callback: %s", exc)

    state: AgentState = {
        "messages":       [*history, HumanMessage(content=query)],
        "session_id":     session.session_id,
        "user_query":     query,
        "agents_invoked": [],
        "tool_results":   [],
        "agent_route":    None,
        "final_answer":   None,
        "trace_id":       trace_id,
    }

    try:
        result        = await _get_graph().ainvoke(state, config={"callbacks": callbacks})
        answer        = result.get("final_answer") or "I could not produce an answer."
        agents_called = result.get("agents_invoked", [])
    except Exception as exc:
        logger.error("Graph error: %s", exc, exc_info=True)
        answer        = f"An error occurred while processing your query: {exc}"
        agents_called = []

    if _langfuse:
        try:
            _langfuse.flush()
        except Exception:
            pass

    session.add("user",      query)
    session.add("assistant", answer)

    agent_types: List[AgentType] = []
    for name in agents_called:
        for key, at in _AGENT_MAP.items():
            if key in name and at not in agent_types:
                agent_types.append(at)

    ms = round((time.monotonic() - t0) * 1000)
    logger.info(
        "Query done  session=%s  latency=%dms  agents=%s",
        session.session_id[:8], ms, agents_called,
    )

    return FinalResponse(
        session_id=session.session_id,
        answer=answer,
        agents_used=agent_types,
        trace_id=trace_id,
    )


# =============================================================================
# SECTION 5 — FastMCP server
# =============================================================================

mcp = FastMCP(
    name="incident-analysis-app",
    instructions=(
        "Incident Analysis backend. "
        "Call 'login' to authenticate, then 'chat' to submit queries. "
        "The Head Agent routes each query to all relevant internal systems "
        "and returns a synthesised Markdown-formatted answer."
    ),
)


def _auth(username: str, password: str) -> bool:
    return username == settings.auth_username and password == settings.auth_password


@mcp.tool()
async def login(username: str, password: str) -> dict:
    """
    Authenticate with static credentials.

    Returns
    ───────
    session_id : str — pass to all subsequent calls.
    username   : str
    """
    if not _auth(username, password):
        raise ToolError("Invalid credentials.")
    s = _sessions.create(username)
    return {"session_id": s.session_id, "username": username}


@mcp.tool()
async def chat(session_id: str, query: str) -> dict:
    """
    Submit an incident-related query.

    The Head Agent fans out to all relevant internal systems
    (Vital-12, RAN Chat, Confluence, SSP, TSOP) and returns a
    synthesised Markdown answer.

    Parameters
    ──────────
    session_id : from login()
    query      : natural-language question

    Returns
    ───────
    answer, agents_used, trace_id, session_id
    """
    s = _sessions.get(session_id)
    if not s:
        raise ToolError("Session not found or expired. Please login again.")
    if not query.strip():
        raise ToolError("Query must not be empty.")

    resp = await _run_graph(query=query.strip(), session=s)
    return {
        "answer":      resp.answer,
        "agents_used": [a.value for a in resp.agents_used],
        "trace_id":    resp.trace_id,
        "session_id":  session_id,
    }


@mcp.tool()
async def get_history(session_id: str) -> dict:
    """
    Retrieve conversation history for a session.

    Returns
    ───────
    session_id, history : list[{role, content, timestamp}]
    """
    s = _sessions.get(session_id)
    if not s:
        raise ToolError("Session not found or expired.")
    return {
        "session_id": session_id,
        "history": [
            {"role": m.role, "content": m.content, "timestamp": m.timestamp.isoformat()}
            for m in s.history
        ],
    }


@mcp.tool()
async def clear_history(session_id: str) -> dict:
    """Clear conversation history (fresh context). Returns {session_id, cleared}."""
    s = _sessions.get(session_id)
    if not s:
        raise ToolError("Session not found or expired.")
    s.history.clear()
    logger.info("History cleared  id=%s", session_id[:8])
    return {"session_id": session_id, "cleared": True}


@mcp.tool()
async def logout(session_id: str) -> dict:
    """Invalidate a session. Returns {logged_out: bool}."""
    deleted = _sessions.delete(session_id)
    logger.info("Logout  id=%s  deleted=%s", session_id[:8], deleted)
    return {"logged_out": deleted}


@mcp.tool()
async def health() -> dict:
    """
    Liveness / readiness probe.

    Returns
    ───────
    status, active_sessions, expired_purged, env
    """
    purged = _sessions.purge()
    return {
        "status":          "ok",
        "active_sessions": _sessions.count(),
        "expired_purged":  purged,
        "env":             settings.app_env,
    }


# =============================================================================
# SECTION 6 — Entry point
# =============================================================================

if __name__ == "__main__":
    logger.info(
        "Starting FastMCP server  host=%s  port=%d  env=%s",
        settings.mcp_host, settings.mcp_port, settings.app_env,
    )
    mcp.run(
        transport="streamable-http",
        host=settings.mcp_host,
        port=settings.mcp_port,
    )
