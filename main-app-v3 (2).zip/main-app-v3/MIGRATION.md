# Migration Guide

## From Streamlit-only `main.py`

| Before | After |
|--------|-------|
| `main.py` — all logic | `app/server.py` — sections 1–8 |
| Direct API calls in UI | `BaseTool` subclasses (Section 3) |
| Ad-hoc LLM calls | LangGraph graph (Section 4) |
| `st.session_state` auth | `_SessionService` (Section 5) |
| No tracing | Langfuse via `_run_graph()` (Section 6) |
| No deployment config | Dockerfile + Compose + K8s |

## Steps

### 1. Move API calls into tools (Section 3)

```python
class YourSystemTool(BaseTool):
    name        = "your_system"
    description = "..."
    args_schema = YourInput

    async def _arun(self, param: str) -> str:
        async with _http(settings.your_base_url, settings.your_api_key) as c:
            r = await c.get(f"/endpoint?q={param}")
        return format_result(r.json())
```

Register in `_all_tools()` — Head Agent discovers it automatically.

### 2. Replace LLM calls

```python
# Before
response = openai_client.chat.completions.create(...)

# After
result = await _run_graph(query=query, session=session)
answer = result.answer
```

### 3. New env vars

```ini
LANGFUSE_PUBLIC_KEY=pk-lf-...
LANGFUSE_SECRET_KEY=sk-lf-...
MCP_HOST=0.0.0.0
MCP_PORT=8000
```

### 4. Run both in parallel to validate

```bash
streamlit run main.py --server.port 8500   # old
./run_backend.sh                            # new backend
./run_frontend.sh                           # new frontend (8501)
```
