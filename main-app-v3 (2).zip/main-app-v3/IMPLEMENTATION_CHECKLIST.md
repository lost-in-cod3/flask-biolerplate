# Implementation Checklist

## Phase 1 — Setup
- [ ] `cp .env.example .env` → populate `OPENAI_API_KEY`, `AUTH_USERNAME`, `AUTH_PASSWORD`
- [ ] `python -m venv .venv && source .venv/bin/activate`
- [ ] `pip install -r requirements.txt`
- [ ] `pytest -v` — all pass

## Phase 2 — Backend
- [ ] `./run_backend.sh` starts without errors
- [ ] `health` tool → `{"status": "ok"}`
- [ ] `login` → returns `session_id` ✓ / error on bad creds ✓

## Phase 3 — Tool integration
- [ ] Vital-12 — `VITAL12_BASE_URL` + `VITAL12_API_KEY` set, anomaly query works
- [ ] RAN Chat — `RAN_CHAT_*` set, single-node query works
- [ ] Confluence PIR — `CONFLUENCE_*` set, PIR search works
- [ ] Confluence Workspace — workspace search works
- [ ] Confluence Auto-RAG — open-ended query works
- [ ] SSP — `SSP_*` set, address search works
- [ ] TSOP Search — `INCxxxxxxxxxxxx` and `Cxxxxxxx` both work
- [ ] TSOP Power Health — 4-letter site code works

## Phase 4 — Langfuse
- [ ] `LANGFUSE_*` vars set
- [ ] Trace appears in Langfuse dashboard after a `chat` call
- [ ] Tool spans visible in the trace

## Phase 5 — Frontend
- [ ] `./run_frontend.sh` → http://localhost:8501
- [ ] Login / logout cycle works
- [ ] Query returns Markdown answer with agent badges
- [ ] All Quick Actions in sidebar trigger correctly
- [ ] Clear Chat resets history

## Phase 6 — Docker
- [ ] `docker-compose build` succeeds
- [ ] `docker-compose up` → both containers healthy
- [ ] UI accessible at http://localhost:8501

## Phase 7 — Production hardening
- [ ] Replace static auth with SSO / OAuth
- [ ] Replace in-memory `_SessionService` with Redis
- [ ] HTTPS / TLS at ingress
- [ ] Kubernetes resource limits tuned
- [ ] HPA min/max replicas set for expected load
- [ ] Log aggregation configured
- [ ] Langfuse error-rate alerts enabled
- [ ] API token scopes tightened
