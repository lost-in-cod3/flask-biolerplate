# ⚡ Quickstart

## 1. Install

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## 2. Configure

```bash
cp .env.example .env
# Edit .env — minimum required:
#   OPENAI_API_KEY, AUTH_USERNAME, AUTH_PASSWORD
# Add URLs + keys for each system you want to enable
```

## 3. Run

```bash
./run_backend.sh    # terminal 1
./run_frontend.sh   # terminal 2  →  http://localhost:8501
```

## 4. Docker

```bash
docker-compose up --build
```

## 5. Test

```bash
pytest -v
```

## Example queries

```
Are there any Vital-12 anomalies right now?
Look up TSOP incident INC0000000123456
Check power health for site AMST
Service status for 123 High Street, London
Search the PIR library for database outage root causes
Look up conen C0000042 in TSOP
What does the NETOPS Confluence space say about BGP flapping?
```
