#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
[[ -f ".env" ]] || { echo "❌  .env not found. Run: cp .env.example .env"; exit 1; }
set -o allexport; source .env; set +o allexport
echo "🚀 FastMCP backend → ${MCP_HOST:-0.0.0.0}:${MCP_PORT:-8000}"
PYTHONPATH="$ROOT" python -m app.server
