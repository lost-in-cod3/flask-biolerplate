"""
Centralised settings loaded from the .env file.

Add new environment variables here and they will be automatically
available throughout the application via `get_settings()`.
"""

from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """All application configuration, sourced from the .env file."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Server ──────────────────────────────────────────────────────────────
    mcp_server_name: str = Field(default="FastMCP Server", description="Display name for the MCP server")
    mcp_server_version: str = Field(default="1.0.0", description="Semantic version of the server")
    mcp_host: str = Field(default="0.0.0.0", description="Bind host")
    mcp_port: int = Field(default=8000, ge=1, le=65535, description="Bind port")
    mcp_transport: Literal["sse", "stdio"] = Field(default="sse", description="MCP transport layer")

    # ── Environment ─────────────────────────────────────────────────────────
    env: Literal["development", "staging", "production"] = Field(default="development")
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = Field(default="INFO")

    # ── Security ─────────────────────────────────────────────────────────────
    api_key: str = Field(default="change-me-in-production", description="Bearer token for HTTP transport")

    # ── Optional integrations ────────────────────────────────────────────────
    database_url: str | None = Field(default=None)
    redis_url: str | None = Field(default=None)
    openai_api_key: str | None = Field(default=None)

    # ── Derived helpers ──────────────────────────────────────────────────────
    @property
    def is_production(self) -> bool:
        return self.env == "production"

    @property
    def is_development(self) -> bool:
        return self.env == "development"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return a cached singleton of Settings.

    The cache is intentionally never invalidated during normal operation.
    In tests, call ``get_settings.cache_clear()`` to force a reload.
    """
    return Settings()
