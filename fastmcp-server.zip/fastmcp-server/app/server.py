"""
FastMCP server entry point.

Run in SSE mode (default):
    python -m app.server
    # or
    uvicorn app.server:http_app --host 0.0.0.0 --port 8000

Run in stdio mode (for Claude Desktop / local MCP clients):
    MCP_TRANSPORT=stdio python -m app.server
"""

from __future__ import annotations

import asyncio
import sys

from fastmcp import FastMCP

from app.config import get_settings
from app.core.logging import get_logger, setup_logging
from app.tools import register_all_tools

# ── Bootstrap ────────────────────────────────────────────────────────────────
setup_logging()
logger = get_logger(__name__)
settings = get_settings()

# ── Create FastMCP instance ───────────────────────────────────────────────────
mcp = FastMCP(
    name=settings.mcp_server_name,
    # instructions is shown to LLM clients when they connect
    instructions=(
        f"This is {settings.mcp_server_name} v{settings.mcp_server_version}. "
        "Use the available tools to interact with the server. "
        "Call `health_check` to verify connectivity, `server_info` for metadata, "
        "or explore the math and text utility tools."
    ),
)

# ── Register all tool groups ──────────────────────────────────────────────────
register_all_tools(mcp)

# ── ASGI app (for SSE / HTTP transport) ───────────────────────────────────────
# Expose as ``http_app`` so uvicorn / gunicorn can import it:
#   uvicorn app.server:http_app
http_app = mcp.http_app()


# ── CLI runner ────────────────────────────────────────────────────────────────
async def _run() -> None:
    transport = settings.mcp_transport

    logger.info(
        "Starting %s v%s | transport=%s env=%s",
        settings.mcp_server_name,
        settings.mcp_server_version,
        transport,
        settings.env,
    )

    if transport == "stdio":
        logger.info("Launching stdio transport (suitable for Claude Desktop)")
        await mcp.run_async(transport="stdio")
    else:
        logger.info("Listening on http://%s:%d", settings.mcp_host, settings.mcp_port)
        await mcp.run_async(
            transport="sse",
            host=settings.mcp_host,
            port=settings.mcp_port,
        )


if __name__ == "__main__":
    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        logger.info("Server stopped by user.")
        sys.exit(0)
