# FastMCP Server

A production-ready [FastMCP](https://github.com/jlowin/fastmcp) server with a clean, extensible architecture.

---

## Quick start

```bash
# 1. Clone & enter the project
git clone <your-repo>
cd fastmcp-server

# 2. Copy env template and edit values
cp .env.example .env

# 3. Install dependencies
make dev          # includes test/lint tools
# or: pip install -e ".[dev]"

# 4. Start the server (SSE mode, http://localhost:8000)
make run
```

---

## Project structure

```
fastmcp-server/
├── .env                        # ← all config lives here
├── .env.example
├── pyproject.toml
├── Makefile
│
├── app/
│   ├── server.py               # entry point
│   │
│   ├── config/
│   │   └── settings.py         # pydantic-settings, reads .env
│   │
│   ├── core/
│   │   ├── logging.py          # structured logging setup
│   │   └── exceptions.py       # custom exception hierarchy
│   │
│   ├── tools/
│   │   ├── base.py             # BaseTool ABC
│   │   ├── registry.py         # ← add new tools here
│   │   ├── health.py           # health_check, server_info, ping
│   │   ├── math_tools.py       # add, multiply, factorial
│   │   └── text_tools.py       # word_count, reverse_text, to_title_case
│   │
│   ├── services/
│   │   └── base_service.py     # BaseService ABC
│   │
│   ├── utils/
│   │   ├── response.py         # success / error / paginated helpers
│   │   └── decorators.py       # @handle_tool_errors
│   │
│   ├── api/                    # optional HTTP routes (webhooks, admin)
│   ├── graph/                  # LangGraph / agentic workflow graphs
│   │
│   └── tests/
│       ├── conftest.py
│       ├── test_health.py
│       ├── test_math_tools.py
│       └── test_settings.py
│
├── frontend/                   # frontend app (add your own)
│
└── infrastructure/
    └── template/
        ├── Dockerfile
        └── docker-compose.yml
```

---

## Configuration (`.env`)

| Variable | Default | Description |
|---|---|---|
| `MCP_SERVER_NAME` | `FastMCP Server` | Display name |
| `MCP_SERVER_VERSION` | `1.0.0` | Semantic version |
| `MCP_HOST` | `0.0.0.0` | Bind host |
| `MCP_PORT` | `8000` | Bind port |
| `MCP_TRANSPORT` | `sse` | `sse` or `stdio` |
| `ENV` | `development` | `development` / `staging` / `production` |
| `LOG_LEVEL` | `INFO` | `DEBUG` / `INFO` / `WARNING` / `ERROR` |
| `API_KEY` | — | Bearer token for HTTP transport |
| `DATABASE_URL` | *(optional)* | PostgreSQL DSN |
| `REDIS_URL` | *(optional)* | Redis URL |
| `OPENAI_API_KEY` | *(optional)* | OpenAI key for LLM tools |

---

## Available tools

| Tool | Description |
|---|---|
| `health_check` | Liveness probe – uptime, env, Python version |
| `server_info` | Static metadata (name, version, transport) |
| `ping` | Echo tool – round-trip test |
| `add` | Sum two numbers |
| `multiply` | Multiply two numbers |
| `factorial` | Compute n! (0 ≤ n ≤ 20) |
| `word_count` | Words, chars, lines in a string |
| `reverse_text` | Reverse a string |
| `to_title_case` | Convert to Title Case |

---

## Adding a new tool

```python
# app/tools/my_tool.py
from app.tools.base import BaseTool
from app.utils.decorators import handle_tool_errors
from app.utils.response import success

class MyTools(BaseTool):
    def register(self, mcp):
        @mcp.tool()
        @handle_tool_errors
        async def my_tool(param: str) -> dict:
            """Describe what this tool does."""
            return success(data={"result": param.upper()})
```

Then add `MyTools` to `_TOOL_CLASSES` in `app/tools/registry.py` – that's it.

---

## Developer commands

```bash
make test        # pytest + coverage
make lint        # ruff lint
make format      # ruff auto-fix + format
make typecheck   # mypy
make docker-up   # start with Docker Compose
make help        # list all commands
```

---

## Transports

| Transport | Use case | How to run |
|---|---|---|
| `sse` (default) | Web clients, n8n, remote agents | `make run` |
| `stdio` | Claude Desktop, local MCP clients | `make run-stdio` |
