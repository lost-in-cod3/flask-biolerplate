"""
app/graph – agentic workflow graphs (LangGraph, etc.).

Place your LangGraph ``StateGraph`` definitions here.  Tools can invoke
graph nodes, or the server can expose graph runs as MCP tools themselves.

Typical structure once this grows:
  app/graph/
  ├── __init__.py
  ├── state.py        # TypedDict state schemas
  ├── nodes.py        # individual node functions
  ├── edges.py        # conditional edge functions
  └── builder.py      # compiles the graph and exports ``compiled_graph``
"""
