"""
Base class for application services.

Services encapsulate business logic and external integrations
(databases, APIs, caches, …).  Tools should call services rather
than implementing logic directly – this keeps tools thin and
services independently testable.

Usage example
─────────────
    class WeatherService(BaseService):
        async def get_forecast(self, city: str) -> dict:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{self.settings.weather_api_url}/{city}")
                resp.raise_for_status()
                return resp.json()
"""

from __future__ import annotations

from app.config import Settings, get_settings
from app.core.logging import get_logger


class BaseService:
    """Shared scaffolding for all services."""

    def __init__(self) -> None:
        self.settings: Settings = get_settings()
        self.logger = get_logger(type(self).__module__)

    async def startup(self) -> None:
        """Override to run async setup (open connections, warm caches …)."""

    async def shutdown(self) -> None:
        """Override to run async teardown (close connections …)."""
