"""
Helpers for building consistent tool responses.

Every tool should return one of these helpers so that callers always
receive a predictable envelope shape.
"""

from __future__ import annotations

import datetime
from typing import Any


def success(data: Any, message: str = "OK") -> dict[str, Any]:
    """Return a successful tool response envelope."""
    return {
        "status": "success",
        "message": message,
        "data": data,
        "timestamp": _now(),
    }


def error(message: str, code: str = "ERROR", details: Any = None) -> dict[str, Any]:
    """Return an error tool response envelope."""
    payload: dict[str, Any] = {
        "status": "error",
        "message": message,
        "code": code,
        "timestamp": _now(),
    }
    if details is not None:
        payload["details"] = details
    return payload


def paginated(
    items: list[Any],
    total: int,
    page: int = 1,
    page_size: int = 20,
) -> dict[str, Any]:
    """Return a paginated list response."""
    return success(
        data={
            "items": items,
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": -(-total // page_size),  # ceiling division
        }
    )


def _now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
