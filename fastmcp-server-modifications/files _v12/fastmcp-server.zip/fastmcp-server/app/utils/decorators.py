"""
Reusable decorators for MCP tool functions.

Wrap any async tool function with ``@handle_tool_errors`` to get
automatic logging, timing, and normalised error responses.
"""

from __future__ import annotations

import functools
import time
from collections.abc import Callable
from typing import Any

from app.core.exceptions import MCPServerError
from app.core.logging import get_logger
from app.utils.response import error

logger = get_logger(__name__)


def handle_tool_errors(func: Callable[..., Any]) -> Callable[..., Any]:
    """
    Decorator that wraps an async tool coroutine.

    - Logs entry/exit with elapsed time.
    - Catches ``MCPServerError`` subclasses and returns an ``error()`` envelope.
    - Re-raises unexpected exceptions after logging (so FastMCP can handle them).
    """

    @functools.wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        tool_name = func.__qualname__
        start = time.perf_counter()
        logger.debug("→ %s called with kwargs=%s", tool_name, kwargs)
        try:
            result = await func(*args, **kwargs)
            elapsed = (time.perf_counter() - start) * 1000
            logger.debug("← %s completed in %.1f ms", tool_name, elapsed)
            return result
        except MCPServerError as exc:
            logger.warning("Tool error in %s: %s", tool_name, exc)
            return error(str(exc), code=exc.code)
        except Exception as exc:
            logger.exception("Unexpected error in %s", tool_name)
            raise exc

    return wrapper
