"""
Base class that every tool module should extend.

By inheriting from ``BaseTool``, new tools get:
  - A pre-configured logger.
  - A ``settings`` shortcut.
  - A ``register(mcp)`` hook that subclasses must implement.

Adding a new tool is three steps:
  1. Create ``app/tools/my_tool.py`` with a class that extends ``BaseTool``.
  2. Implement ``register(mcp)`` – call ``mcp.tool()(your_async_fn)`` inside.
  3. Import and instantiate the class in ``app/tools/registry.py``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from app.config import Settings, get_settings
from app.core.logging import get_logger

if TYPE_CHECKING:
    from fastmcp import FastMCP


class BaseTool(ABC):
    """Abstract base class for all MCP tools."""

    def __init__(self) -> None:
        self.settings: Settings = get_settings()
        self.logger = get_logger(type(self).__module__)

    @abstractmethod
    def register(self, mcp: "FastMCP") -> None:
        """Register this tool's functions with the FastMCP instance."""
        ...

    @property
    def tool_group(self) -> str:
        """Override to group related tools under a common prefix."""
        return ""
