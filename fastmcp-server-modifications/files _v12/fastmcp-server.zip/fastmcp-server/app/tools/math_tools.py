"""
Sample mathematical tools – demonstrates how to add new tool groups.

Tools exposed:
  - ``add``       – sum two numbers.
  - ``multiply``  – multiply two numbers.
  - ``factorial`` – compute n! for non-negative integers.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any

from app.core.exceptions import ValidationError
from app.tools.base import BaseTool
from app.utils.decorators import handle_tool_errors
from app.utils.response import success

if TYPE_CHECKING:
    from fastmcp import FastMCP


class MathTools(BaseTool):
    """Registers sample math tools onto the FastMCP instance."""

    def register(self, mcp: "FastMCP") -> None:
        # ── add ──────────────────────────────────────────────────────────────
        @mcp.tool()
        @handle_tool_errors
        async def add(a: float, b: float) -> dict[str, Any]:
            """
            Add two numbers together.

            Args:
                a: First operand.
                b: Second operand.

            Returns:
                The sum of ``a`` and ``b``.
            """
            return success(data={"result": a + b, "operation": f"{a} + {b}"})

        # ── multiply ─────────────────────────────────────────────────────────
        @mcp.tool()
        @handle_tool_errors
        async def multiply(a: float, b: float) -> dict[str, Any]:
            """
            Multiply two numbers.

            Args:
                a: First factor.
                b: Second factor.

            Returns:
                The product of ``a`` and ``b``.
            """
            return success(data={"result": a * b, "operation": f"{a} × {b}"})

        # ── factorial ─────────────────────────────────────────────────────────
        @mcp.tool()
        @handle_tool_errors
        async def factorial(n: int) -> dict[str, Any]:
            """
            Compute the factorial of a non-negative integer.

            Args:
                n: A non-negative integer (0 – 20 to keep the result reasonable).

            Returns:
                ``n!`` as an integer.

            Raises:
                ValidationError: if ``n`` is negative or exceeds 20.
            """
            if n < 0:
                raise ValidationError("n", "must be a non-negative integer")
            if n > 20:
                raise ValidationError("n", "must be ≤ 20 to avoid absurdly large results")
            return success(data={"result": math.factorial(n), "n": n})

        self.logger.info("MathTools registered (add, multiply, factorial)")
