"""
Tool registry – the single place where tools are wired to FastMCP.

To add a new tool group:
  1. Create ``app/tools/my_tool.py`` extending ``BaseTool``.
  2. Import the class below and add it to ``_TOOL_CLASSES``.
  3. Done – the server picks it up automatically on next start.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from app.core.logging import get_logger
from app.tools.base import BaseTool
from app.tools.health import HealthTools
from app.tools.math_tools import MathTools
from app.tools.text_tools import TextTools

if TYPE_CHECKING:
    from fastmcp import FastMCP

logger = get_logger(__name__)

# ── Add new tool classes here ─────────────────────────────────────────────────
_TOOL_CLASSES: list[type[BaseTool]] = [
    HealthTools,
    MathTools,
    TextTools,
]


def register_all_tools(mcp: "FastMCP") -> None:
    """Instantiate every tool class and register it with the FastMCP server."""
    logger.info("Registering %d tool group(s)…", len(_TOOL_CLASSES))
    for cls in _TOOL_CLASSES:
        instance = cls()
        instance.register(mcp)
    logger.info("All tools registered successfully.")
