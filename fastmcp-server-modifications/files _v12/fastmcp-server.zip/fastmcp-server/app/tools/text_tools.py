"""
Sample text-manipulation tools.

Tools exposed:
  - ``word_count``     – count words and characters in a string.
  - ``reverse_text``   – reverse a string.
  - ``to_title_case``  – convert a string to Title Case.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from app.tools.base import BaseTool
from app.utils.decorators import handle_tool_errors
from app.utils.response import success

if TYPE_CHECKING:
    from fastmcp import FastMCP


class TextTools(BaseTool):
    """Registers sample text tools onto the FastMCP instance."""

    def register(self, mcp: "FastMCP") -> None:
        # ── word_count ────────────────────────────────────────────────────────
        @mcp.tool()
        @handle_tool_errors
        async def word_count(text: str) -> dict[str, Any]:
            """
            Count words and characters in the provided text.

            Args:
                text: Input string to analyse.

            Returns:
                Word count, character count (with and without spaces).
            """
            words = text.split()
            return success(
                data={
                    "word_count": len(words),
                    "char_count": len(text),
                    "char_count_no_spaces": len(text.replace(" ", "")),
                    "line_count": text.count("\n") + 1,
                }
            )

        # ── reverse_text ──────────────────────────────────────────────────────
        @mcp.tool()
        @handle_tool_errors
        async def reverse_text(text: str) -> dict[str, Any]:
            """
            Reverse the characters in a string.

            Args:
                text: Input string to reverse.

            Returns:
                The reversed string.
            """
            return success(data={"original": text, "reversed": text[::-1]})

        # ── to_title_case ─────────────────────────────────────────────────────
        @mcp.tool()
        @handle_tool_errors
        async def to_title_case(text: str) -> dict[str, Any]:
            """
            Convert a string to Title Case.

            Args:
                text: Input string to transform.

            Returns:
                The title-cased string.
            """
            return success(data={"original": text, "title_case": text.title()})

        self.logger.info("TextTools registered (word_count, reverse_text, to_title_case)")
