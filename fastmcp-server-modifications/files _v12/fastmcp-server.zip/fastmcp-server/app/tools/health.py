"""
Health & diagnostics tools.

Tools exposed:
  - ``health_check``  – lightweight liveness probe.
  - ``server_info``   – returns server metadata (name, version, env).
  - ``ping``          – echo / round-trip latency test.
"""

from __future__ import annotations

import datetime
import platform
import time
from typing import TYPE_CHECKING, Any

from app.tools.base import BaseTool
from app.utils.decorators import handle_tool_errors
from app.utils.response import success

if TYPE_CHECKING:
    from fastmcp import FastMCP

# Track when the server process started so we can report uptime.
_SERVER_START: float = time.time()


class HealthTools(BaseTool):
    """Registers health / diagnostics tools onto the FastMCP instance."""

    def register(self, mcp: "FastMCP") -> None:
        # ── health_check ────────────────────────────────────────────────────
        @mcp.tool()
        @handle_tool_errors
        async def health_check() -> dict[str, Any]:
            """
            Liveness probe – returns status, uptime, and current UTC timestamp.

            Returns:
                A success envelope with ``status``, ``uptime_seconds``,
                ``timestamp``, and basic runtime information.
            """
            uptime = round(time.time() - _SERVER_START, 2)
            return success(
                data={
                    "status": "healthy",
                    "uptime_seconds": uptime,
                    "python_version": platform.python_version(),
                    "platform": platform.system(),
                    "environment": self.settings.env,
                },
                message="Server is healthy",
            )

        # ── server_info ─────────────────────────────────────────────────────
        @mcp.tool()
        @handle_tool_errors
        async def server_info() -> dict[str, Any]:
            """
            Return static metadata about this MCP server.

            Returns:
                Server name, version, environment, and transport settings.
            """
            return success(
                data={
                    "name": self.settings.mcp_server_name,
                    "version": self.settings.mcp_server_version,
                    "environment": self.settings.env,
                    "transport": self.settings.mcp_transport,
                    "host": self.settings.mcp_host,
                    "port": self.settings.mcp_port,
                }
            )

        # ── ping ─────────────────────────────────────────────────────────────
        @mcp.tool()
        @handle_tool_errors
        async def ping(message: str = "ping") -> dict[str, Any]:
            """
            Echo tool – useful for verifying round-trip latency.

            Args:
                message: Any string to echo back (defaults to "ping").

            Returns:
                The echoed message together with a UTC timestamp.
            """
            return success(
                data={
                    "echo": message,
                    "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                },
                message="pong",
            )

        self.logger.info("HealthTools registered (health_check, server_info, ping)")
