"""
app/api – optional REST/HTTP layer.

This package is intentionally empty to start with.  When the MCP server is
run in ``sse`` transport mode, FastMCP exposes its own HTTP endpoints.
Add custom HTTP routes here if you need endpoints outside the MCP protocol
(e.g. webhooks, OAuth callbacks, admin APIs).

Example (using FastAPI mounted on the same app):
────────────────────────────────────────────────
    from fastapi import APIRouter

    router = APIRouter(prefix="/api/v1")

    @router.get("/status")
    async def status():
        return {"ok": True}
"""
