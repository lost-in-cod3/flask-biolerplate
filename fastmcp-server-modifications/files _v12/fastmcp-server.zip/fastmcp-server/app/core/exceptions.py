"""
Custom exception hierarchy for the MCP server.

Raising these instead of generic exceptions lets callers handle
errors precisely and produce consistent error messages to clients.
"""


class MCPServerError(Exception):
    """Base class for all server-side errors."""

    def __init__(self, message: str, code: str = "INTERNAL_ERROR") -> None:
        super().__init__(message)
        self.code = code


class ToolExecutionError(MCPServerError):
    """Raised when a tool fails during execution."""

    def __init__(self, tool_name: str, reason: str) -> None:
        super().__init__(f"Tool '{tool_name}' failed: {reason}", code="TOOL_EXECUTION_ERROR")
        self.tool_name = tool_name
        self.reason = reason


class ValidationError(MCPServerError):
    """Raised when tool input validation fails."""

    def __init__(self, field: str, reason: str) -> None:
        super().__init__(f"Validation error on '{field}': {reason}", code="VALIDATION_ERROR")
        self.field = field


class ServiceUnavailableError(MCPServerError):
    """Raised when a downstream service is unreachable."""

    def __init__(self, service: str) -> None:
        super().__init__(f"Service '{service}' is unavailable", code="SERVICE_UNAVAILABLE")
        self.service = service


class NotFoundError(MCPServerError):
    """Raised when a requested resource cannot be found."""

    def __init__(self, resource: str, identifier: str) -> None:
        super().__init__(f"{resource} '{identifier}' not found", code="NOT_FOUND")
        self.resource = resource
        self.identifier = identifier
