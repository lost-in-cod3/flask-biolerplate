"""
Logging configuration for the MCP server.

Call ``setup_logging()`` once at startup; after that use the standard
``logging.getLogger(__name__)`` pattern anywhere in the codebase.
"""

import logging
import sys
from typing import Any

from app.config import get_settings


def setup_logging() -> None:
    """Configure root logger based on settings."""
    settings = get_settings()

    fmt = (
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
        if settings.is_development
        else "%(levelname)s %(name)s %(message)s"
    )

    logging.basicConfig(
        level=settings.log_level,
        format=fmt,
        datefmt="%Y-%m-%dT%H:%M:%S",
        stream=sys.stdout,
        force=True,
    )

    # Quieten noisy third-party loggers in production
    if settings.is_production:
        for noisy in ("httpx", "httpcore", "anyio"):
            logging.getLogger(noisy).setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """Convenience wrapper – usage: ``logger = get_logger(__name__)``."""
    return logging.getLogger(name)


class ToolLoggerMixin:
    """Mixin that provides a pre-named logger to any tool class."""

    @property
    def logger(self) -> logging.Logger:
        return get_logger(type(self).__module__)

    def log_tool_call(self, tool_name: str, inputs: dict[str, Any]) -> None:
        self.logger.debug("Tool called | tool=%s inputs=%s", tool_name, inputs)
