"""
Tests for settings / configuration loading.
"""

from __future__ import annotations

import os

import pytest


def test_settings_load_defaults(settings):
    assert settings.mcp_server_name == "Test Server"
    assert settings.mcp_port == 8001
    assert settings.env == "development"


def test_settings_is_development(settings):
    assert settings.is_development is True
    assert settings.is_production is False


def test_settings_reload_picks_up_new_env(reset_settings_cache):
    os.environ["MCP_SERVER_NAME"] = "Reloaded Server"
    from app.config import get_settings

    s = get_settings()
    assert s.mcp_server_name == "Reloaded Server"
    # Cleanup
    os.environ["MCP_SERVER_NAME"] = "Test Server"
