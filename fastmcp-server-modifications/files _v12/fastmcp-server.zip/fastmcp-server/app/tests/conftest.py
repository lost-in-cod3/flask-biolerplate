"""
Shared pytest fixtures for the test suite.
"""

from __future__ import annotations

import os

import pytest

# ── Patch env before importing settings ──────────────────────────────────────
os.environ.setdefault("ENV", "development")
os.environ.setdefault("MCP_SERVER_NAME", "Test Server")
os.environ.setdefault("MCP_PORT", "8001")


@pytest.fixture(autouse=True)
def reset_settings_cache():
    """Clear the lru_cache on get_settings before/after each test."""
    from app.config import get_settings

    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest.fixture
def settings():
    from app.config import get_settings

    return get_settings()
