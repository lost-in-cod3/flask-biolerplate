"""
Tests for the health check tools.
"""

from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_health_check_returns_healthy():
    from app.tools.health import HealthTools
    from fastmcp import FastMCP

    mcp = FastMCP("test")
    HealthTools().register(mcp)

    # Invoke the registered function directly via the internal tool map
    tool_fn = mcp._tool_manager.get_tool("health_check")
    assert tool_fn is not None

    result = await tool_fn.run({})
    # FastMCP returns content list; get text
    text = result[0].text if hasattr(result[0], "text") else str(result)
    assert "healthy" in text


@pytest.mark.asyncio
async def test_ping_echoes_message():
    from app.tools.health import HealthTools
    from fastmcp import FastMCP

    mcp = FastMCP("test")
    HealthTools().register(mcp)

    tool_fn = mcp._tool_manager.get_tool("ping")
    assert tool_fn is not None

    result = await tool_fn.run({"message": "hello"})
    text = result[0].text if hasattr(result[0], "text") else str(result)
    assert "hello" in text
