"""
Tests for the math tools.
"""

from __future__ import annotations

import json

import pytest


async def _run_tool(tool_name: str, inputs: dict):
    from app.tools.math_tools import MathTools
    from fastmcp import FastMCP

    mcp = FastMCP("test")
    MathTools().register(mcp)
    tool_fn = mcp._tool_manager.get_tool(tool_name)
    assert tool_fn is not None, f"Tool '{tool_name}' not found"
    result = await tool_fn.run(inputs)
    text = result[0].text if hasattr(result[0], "text") else str(result)
    return json.loads(text)


@pytest.mark.asyncio
async def test_add():
    resp = await _run_tool("add", {"a": 3, "b": 4})
    assert resp["data"]["result"] == 7


@pytest.mark.asyncio
async def test_multiply():
    resp = await _run_tool("multiply", {"a": 6, "b": 7})
    assert resp["data"]["result"] == 42


@pytest.mark.asyncio
async def test_factorial_zero():
    resp = await _run_tool("factorial", {"n": 0})
    assert resp["data"]["result"] == 1


@pytest.mark.asyncio
async def test_factorial_five():
    resp = await _run_tool("factorial", {"n": 5})
    assert resp["data"]["result"] == 120


@pytest.mark.asyncio
async def test_factorial_negative_returns_error():
    resp = await _run_tool("factorial", {"n": -1})
    assert resp["status"] == "error"


@pytest.mark.asyncio
async def test_factorial_too_large_returns_error():
    resp = await _run_tool("factorial", {"n": 21})
    assert resp["status"] == "error"
