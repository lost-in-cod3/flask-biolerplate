"""
Centralised settings loaded from the .env file.

Add new environment variables here and they will be automatically
available throughout the application via `get_settings()`.
"""

from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """All application configuration, sourced from the .env file."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Server ──────────────────────────────────────────────────────────────
    mcp_server_name: str = Field(default="FastMCP Server", description="Display name for the MCP server")
    mcp_server_version: str = Field(default="1.0.0", description="Semantic version of the server")
    mcp_host: str = Field(default="127.0.0.1", description="Bind host")
    mcp_port: int = Field(default=8000, ge=1, le=65535, description="Bind port")
    mcp_transport: Literal["streamable-http", "sse", "stdio"] = Field(
        default="streamable-http", description="MCP transport layer"
    )

    # ── Environment ─────────────────────────────────────────────────────────
    env: Literal["development", "staging", "production"] = Field(default="development")
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = Field(default="INFO")

    # ── Security ─────────────────────────────────────────────────────────────
    api_key: str = Field(default="change-me-in-production", description="Bearer token for HTTP transport")

    # ── LLM ──────────────────────────────────────────────────────────────────
    anthropic_api_key: str | None = Field(default=None)
    max_message_history: int = Field(default=20, description="Max messages before summarisation kicks in")

    # ── Optional integrations ────────────────────────────────────────────────
    database_url: str | None = Field(default=None)
    redis_url: str | None = Field(default=None)

    # ── Derived helpers ──────────────────────────────────────────────────────
    @property
    def is_production(self) -> bool:
        return self.env == "production"

    @property
    def is_development(self) -> bool:
        return self.env == "development"

    @property
    def mcp_http_url(self) -> str:
        """Base URL for the MCP server HTTP endpoint."""
        return f"http://{self.mcp_host}:{self.mcp_port}"

    @property
    def mcp_endpoint(self) -> str:
        """Full MCP client URL for the configured transport."""
        if self.mcp_transport == "streamable-http":
            return f"{self.mcp_http_url}/mcp"
        if self.mcp_transport == "sse":
            return f"{self.mcp_http_url}/sse"
        return ""  # stdio has no URL


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return a cached singleton of Settings.

    The cache is intentionally never invalidated during normal operation.
    In tests, call ``get_settings.cache_clear()`` to force a reload.
    """
    return Settings()
