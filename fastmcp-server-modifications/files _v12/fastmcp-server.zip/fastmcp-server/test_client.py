"""
test_client.py – standalone script to call every tool and print results.

Run AFTER starting the server:
    python -m app.server          (in terminal 1)
    python test_client.py         (in terminal 2)
"""

import asyncio
import json

# Uses only stdlib + fastmcp (already a required dependency)
from fastmcp import Client


SERVER_URL = "http://127.0.0.1:8000/mcp"   # Streamable HTTP endpoint   


def pretty(label: str, result: object) -> None:
    print(f"\n{'─'*55}")
    print(f"  {label}")
    print(f"{'─'*55}")
    if isinstance(result, list):
        for item in result:
            text = getattr(item, "text", str(item))
            try:
                parsed = json.loads(text)
                print(json.dumps(parsed, indent=2))
            except Exception:
                print(text)
    else:
        print(result)


async def main() -> None:
    print(f"\nConnecting to FastMCP server at {SERVER_URL} …")

    async with Client(SERVER_URL) as client:

        # ── List all tools ────────────────────────────────────────────────
        tools = await client.list_tools()
        print(f"\n✅  {len(tools)} tools registered:")
        for t in tools:
            print(f"    • {t.name:20s} – {t.description or ''}")

        # ── Health tools ──────────────────────────────────────────────────
        pretty("health_check", await client.call_tool("health_check", {}))
        pretty("server_info",  await client.call_tool("server_info",  {}))
        pretty("ping (hello)", await client.call_tool("ping", {"message": "hello from test_client"}))

        # ── Math tools ────────────────────────────────────────────────────
        pretty("add(7, 35)",       await client.call_tool("add",       {"a": 7,  "b": 35}))
        pretty("multiply(6, 7)",   await client.call_tool("multiply",  {"a": 6,  "b": 7}))
        pretty("factorial(6)",     await client.call_tool("factorial", {"n": 6}))
        pretty("factorial(-1) ← expects error",
                                   await client.call_tool("factorial", {"n": -1}))

        # ── Text tools ────────────────────────────────────────────────────
        pretty("word_count",       await client.call_tool("word_count",   {"text": "The quick brown fox"}))
        pretty("reverse_text",     await client.call_tool("reverse_text", {"text": "FastMCP"}))
        pretty("to_title_case",    await client.call_tool("to_title_case",{"text": "hello world from mcp"}))

    print("\n✅  All tools tested successfully.\n")


if __name__ == "__main__":
    asyncio.run(main())
