"""
FastMCP Streamlit Chatbot Frontend
-----------------------------------
HEAD Agent  : LangChain + Azure OpenAI / OpenAI  (matches reference main1.py)
Sub-Agents  : Lighter model for summarisation
MCP Client  : FastMCP Streamable-HTTP transport

Architecture:
  User message
       |
       v
  initialize_llm(head_model)          <- LangChain AzureChatOpenAI / ChatOpenAI
       |  .bind_tools(mcp_tools)
       v
  Agent loop  --> tool_calls detected
       |
       v
  FastMCP Client -> POST /mcp         <- executes tool on MCP server
       |
       v
  ToolMessage fed back -> final answer
       |
       v
  Streamlit chat_message("assistant")

Run:
    # Terminal 1 - MCP server
    cd ..  &&  python -m app.server

    # Terminal 2 - Streamlit UI
    cd frontend  &&  streamlit run app.py
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import uuid
from typing import Any

# ---------------------------------------------------------------------------
# Windows asyncio fix  (must run before any event-loop is created)
# ---------------------------------------------------------------------------
# The default ProactorEventLoop on Windows raises a noisy ConnectionResetError
# ([WinError 10054]) whenever an HTTP connection closes normally.
# Switching to SelectorEventLoop eliminates the error entirely.
# This is safe: SelectorEventLoop supports all features used here.
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

import streamlit as st
from dotenv import load_dotenv
from fastmcp import Client

# LangChain imports
from langchain_core.messages import (
    AIMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.tools import StructuredTool
from langchain_openai import AzureChatOpenAI, ChatOpenAI

# -- Path so app.config is importable when running from frontend/ -------------
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# -- Load .env from project root ----------------------------------------------
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"), override=True)

# -- Logging ------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# Suppress residual WinError 10054 noise that some httpx/httpcore versions
# still emit even after the SelectorEventLoop policy is applied.
# The filter matches every marker that appears in the reported traceback.
class _SuppressConnectionReset(logging.Filter):
    _MARKERS = (
        "ConnectionResetError",
        "WinError 10054",
        "_call_connection_lost",
        "An existing connection was forcibly closed",
    )

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        return not any(m in msg for m in self._MARKERS)


for _noisy in ("asyncio", "httpx", "httpcore", "uvicorn.error"):
    logging.getLogger(_noisy).addFilter(_SuppressConnectionReset())

# ---------------------------------------------------------------------------
# Configuration  (all driven from .env)
# ---------------------------------------------------------------------------
MCP_ENDPOINT = os.environ.get("MCP_ENDPOINT", "http://127.0.0.1:8000/mcp")
MAX_HISTORY  = int(os.environ.get("MAX_MESSAGE_HISTORY", "20"))

# Azure OpenAI
AZURE_ENDPOINT    = os.environ.get("AZURE_OPENAI_ENDPOINT",    "")
AZURE_API_KEY     = os.environ.get("AZURE_OPENAI_API_KEY",     "")
AZURE_API_VERSION = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-01")

# Standard OpenAI (fallback when Azure keys are absent)
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")

# Model list - mirrors reference main1.py exactly
# Map: display-name -> Azure deployment name (or OpenAI model name)
MODEL_DEPLOYMENT_MAP: dict[str, str] = {
    "azure-gpt-4o":      os.environ.get("AZURE_DEPLOYMENT_GPT4O",      "gpt-4o"),
    "azure-gpt-4o-mini": os.environ.get("AZURE_DEPLOYMENT_GPT4O_MINI", "gpt-4o-mini"),
    "azure-gpt-4o-act":  os.environ.get("AZURE_DEPLOYMENT_GPT4O_ACT",  "gpt-4o"),
}
AVAILABLE_MODELS = list(MODEL_DEPLOYMENT_MAP.keys())

# Placeholder values shipped in .env.example – treated as "not configured"
_PLACEHOLDERS = {
    "your-azure-openai-key-here",
    "your-api-key-here",
    "sk-...",
    "change-me-in-production",
    "https://your-resource.openai.azure.com/",
}


def _is_set(value: str) -> bool:
    """Return True only if value is non-empty AND not a known placeholder."""
    return bool(value) and value.strip() not in _PLACEHOLDERS


def _credential_status() -> dict[str, Any]:
    """
    Inspect the current environment and return a structured status dict:
        {
          mode:   'azure' | 'openai' | 'none',
          ready:  bool,
          issues: list[str],   # human-readable problems
          info:   list[str],   # what IS correctly configured
        }
    """
    issues: list[str] = []
    info:   list[str] = []

    azure_endpoint_ok = _is_set(AZURE_ENDPOINT)
    azure_key_ok      = _is_set(AZURE_API_KEY)
    openai_key_ok     = _is_set(OPENAI_API_KEY)

    # Azure path
    if azure_endpoint_ok or azure_key_ok:
        if not azure_endpoint_ok:
            issues.append(
                "`AZURE_OPENAI_ENDPOINT` is missing or still a placeholder.\n"
                "Expected: `https://<your-resource>.openai.azure.com/`"
            )
        else:
            info.append(f"Azure endpoint: `{AZURE_ENDPOINT}`")

        if not azure_key_ok:
            issues.append("`AZURE_OPENAI_API_KEY` is missing or still a placeholder.")
        else:
            info.append("Azure API key: ✅ set")

        if azure_endpoint_ok and azure_key_ok:
            return {"mode": "azure", "ready": True, "issues": [], "info": info}
        return {"mode": "azure", "ready": False, "issues": issues, "info": info}

    # OpenAI path
    if openai_key_ok:
        info.append("OpenAI API key: ✅ set")
        return {"mode": "openai", "ready": True, "issues": [], "info": info}

    # Nothing set
    issues.append(
        "No LLM credentials found in `.env`.\n\n"
        "**Option A – Azure OpenAI:**\n"
        "```\nAZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com/\n"
        "AZURE_OPENAI_API_KEY=<your-key>\n```\n\n"
        "**Option B – Standard OpenAI:**\n"
        "```\nOPENAI_API_KEY=sk-...\n```"
    )
    return {"mode": "none", "ready": False, "issues": issues, "info": []}


# ---------------------------------------------------------------------------
# initialize_llm  (mirrors llm.initialize_llm() from reference file)
# ---------------------------------------------------------------------------

def initialize_llm(model_name: str, temperature: float = 0.0) -> AzureChatOpenAI | ChatOpenAI:
    """
    Return a LangChain chat model for the given display name.

    - Azure credentials present  -> AzureChatOpenAI
    - Otherwise                  -> ChatOpenAI (standard OpenAI)
    """
    deployment = MODEL_DEPLOYMENT_MAP.get(model_name, model_name)

    if AZURE_ENDPOINT and AZURE_API_KEY:
        logger.info("LLM: AzureChatOpenAI | deployment=%s", deployment)
        return AzureChatOpenAI(
            azure_endpoint=AZURE_ENDPOINT,
            azure_deployment=deployment,
            api_key=AZURE_API_KEY,
            api_version=AZURE_API_VERSION,
            temperature=temperature,
            max_tokens=4096,
        )

    logger.info("LLM: ChatOpenAI | model=%s", deployment)
    return ChatOpenAI(
        model=deployment,
        api_key=OPENAI_API_KEY,
        temperature=temperature,
        max_tokens=4096,
    )


# ---------------------------------------------------------------------------
# Async bridge  (FastMCP is async; Streamlit is sync)
# ---------------------------------------------------------------------------
# Uses a dedicated background thread with its own event loop.
# This is the safest pattern on Windows where Streamlit may already hold a
# partially-started ProactorEventLoop in the main thread.

import concurrent.futures as _cf
import threading as _threading

_loop_lock = _threading.Lock()
_bg_loop: asyncio.AbstractEventLoop | None = None
_bg_thread: _threading.Thread | None = None


def _get_bg_loop() -> asyncio.AbstractEventLoop:
    """Return (creating if needed) a long-lived event loop on a background thread."""
    global _bg_loop, _bg_thread
    with _loop_lock:
        if _bg_loop is None or not _bg_loop.is_running():
            _bg_loop = asyncio.new_event_loop()

            def _run(loop: asyncio.AbstractEventLoop) -> None:
                loop.run_forever()

            _bg_thread = _threading.Thread(target=_run, args=(_bg_loop,), daemon=True)
            _bg_thread.start()
    return _bg_loop


def run_async(coro: Any) -> Any:
    """
    Submit an async coroutine to the persistent background event loop and
    block the calling (Streamlit) thread until the result is ready.
    """
    loop = _get_bg_loop()
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return future.result(timeout=60)


# ---------------------------------------------------------------------------
# MCP helpers
# ---------------------------------------------------------------------------

async def _fetch_mcp_tools_raw() -> list[Any]:
    async with Client(MCP_ENDPOINT) as client:
        return await client.list_tools()


async def _call_mcp_tool(tool_name: str, tool_input: dict[str, Any]) -> str:
    async with Client(MCP_ENDPOINT) as client:
        result = await client.call_tool(tool_name, tool_input)
    return "\n".join(
        block.text if hasattr(block, "text") else str(block)
        for block in result
    )


def call_mcp_tool(tool_name: str, tool_input: dict[str, Any]) -> str:
    return run_async(_call_mcp_tool(tool_name, tool_input))


# ---------------------------------------------------------------------------
# Convert MCP tools -> LangChain StructuredTools
# ---------------------------------------------------------------------------

def _build_langchain_tools(raw_tools: list[Any]) -> list[StructuredTool]:
    lc_tools: list[StructuredTool] = []
    for t in raw_tools:
        def _make_fn(name: str):
            def _run(**kwargs: Any) -> str:
                logger.info("MCP tool call: %s(%s)", name, kwargs)
                try:
                    return call_mcp_tool(name, kwargs)
                except Exception as exc:
                    return json.dumps({"error": str(exc)})
            _run.__name__ = name
            return _run

        lc_tools.append(
            StructuredTool.from_function(
                func=_make_fn(t.name),
                name=t.name,
                description=t.description or "",
            )
        )
    return lc_tools


def fetch_tools() -> tuple[list[Any], list[StructuredTool]]:
    """Fetch MCP tools and return (raw_tools, langchain_tools)."""
    raw = run_async(_fetch_mcp_tools_raw())
    return raw, _build_langchain_tools(raw)


# ---------------------------------------------------------------------------
# HEAD Agent loop  (LangChain tool-calling)
# ---------------------------------------------------------------------------

def run_agent(
    chat_history: list[dict[str, Any]],
    lc_tools: list[StructuredTool],
    head_model: str,
    system_prompt: str = "",
) -> tuple[str, list[dict[str, Any]]]:
    """
    LangChain agentic loop:
      1. Bind MCP tools to the LLM.
      2. Invoke -> check tool_calls.
      3. Execute each via MCP, append ToolMessage.
      4. Repeat until final text response.
    """
    llm = initialize_llm(head_model)
    llm_with_tools = llm.bind_tools(lc_tools)

    lc_messages: list[Any] = []
    if system_prompt:
        lc_messages.append(SystemMessage(content=system_prompt))
    for m in chat_history:
        role, content = m.get("role", ""), m.get("content", "")
        if not isinstance(content, str):
            continue
        if role == "user":
            lc_messages.append(HumanMessage(content=content))
        elif role == "assistant":
            lc_messages.append(AIMessage(content=content))

    tool_calls_log: list[dict[str, Any]] = []

    while True:
        response: AIMessage = llm_with_tools.invoke(lc_messages)
        lc_messages.append(response)

        if not response.tool_calls:
            return response.content or "", tool_calls_log

        for tc in response.tool_calls:
            t_name, t_args, t_id = tc["name"], tc["args"], tc["id"]
            logger.info("Tool call: %s(%s)", t_name, t_args)
            try:
                result_text = call_mcp_tool(t_name, t_args)
            except Exception as exc:
                result_text = json.dumps({"error": str(exc)})

            tool_calls_log.append({"tool": t_name, "input": t_args, "output": result_text})
            lc_messages.append(ToolMessage(content=result_text, tool_call_id=t_id))


# ---------------------------------------------------------------------------
# Summarisation  (Sub-Agents LLM - lighter / cheaper model)
# ---------------------------------------------------------------------------

def summarize_old_messages(messages: list[dict[str, Any]], sub_model: str) -> str:
    """Summarise old messages - mirrors summarize_old_messages() from reference."""
    if not messages:
        return ""
    llm = initialize_llm(sub_model)
    transcript = "\n".join(
        f"{m['role'].upper()}: {m['content']}"
        for m in messages
        if isinstance(m.get("content"), str)
    )
    prompt = (
        "Summarise the following conversation in 3-5 sentences, "
        "capturing the key topics and any important facts:\n\n" + transcript
    )
    resp = llm.invoke([HumanMessage(content=prompt)])
    return resp.content if hasattr(resp, "content") else str(resp)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_tool_output(raw: str) -> Any:
    try:
        return json.loads(raw)
    except Exception:
        return raw


def _has_llm_credentials() -> bool:
    """Return True only if real (non-placeholder) credentials are present."""
    return _credential_status()["ready"]


# ---------------------------------------------------------------------------
# Streamlit page config  (must be the first Streamlit call)
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="FastMCP Chat",
    page_icon="\U0001f916",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Session-state initialisation
# ---------------------------------------------------------------------------
if "conversation_id" not in st.session_state:
    st.session_state.conversation_id = str(uuid.uuid4())

if "messages" not in st.session_state:
    st.session_state.messages = [{"role": "assistant", "content": "How can I help you?"}]

if "summary" not in st.session_state:
    st.session_state.summary = ""

# Resolve user name (supports OAuth proxy header - mirrors reference main1.py)
user_name = "local_user"
if st.context.headers:
    headers_dict = st.context.headers.to_dict()
    proxy_user = headers_dict.get("X-Auth-Request-Preferred-Username")
    if proxy_user:
        user_name = proxy_user
st.session_state["user"] = user_name

session_id = st.session_state.conversation_id + user_name

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.markdown("## \U0001f916 FastMCP Chat")
    st.divider()

    # Quick links (matches reference layout exactly)
    st.sidebar.markdown("##### User Guide")
    st.sidebar.markdown("[Open User Guide](https://google.com)", unsafe_allow_html=True)

    st.sidebar.markdown("##### Changelogs")
    st.sidebar.markdown("[View Changelogs](https://google.com)", unsafe_allow_html=True)

    st.sidebar.markdown("##### Issue Register")
    st.sidebar.markdown("[Report an Issue](https://google.com)", unsafe_allow_html=True)

    st.divider()

    # Model Configuration - mirrors reference main1.py exactly
    st.sidebar.markdown("### Model Configuration")
    st.sidebar.info(
        "Please refresh the page before switching models to ensure changes take effect"
    )

    head_model = st.sidebar.selectbox(
        " HEAD Agent LLM",
        AVAILABLE_MODELS,
        index=AVAILABLE_MODELS.index("azure-gpt-4o-act") if "azure-gpt-4o-act" in AVAILABLE_MODELS else 0,
        help="Primary reasoning model - routes user requests to MCP tools.",
    )
    sub_agents_model = st.sidebar.selectbox(
        " Sub-Agents LLM",
        AVAILABLE_MODELS,
        index=AVAILABLE_MODELS.index("azure-gpt-4o-mini") if "azure-gpt-4o-mini" in AVAILABLE_MODELS else 1,
        help="Lighter model used for conversation summarisation.",
    )

    st.session_state["head_model"]       = head_model
    st.session_state["sub_agents_model"] = sub_agents_model

    st.divider()

    # LLM Credentials status
    st.markdown("### 🔑 LLM Credentials")
    _creds = _credential_status()
    if _creds["ready"]:
        st.success(f"✅ Mode: **{_creds['mode'].upper()}**")
        for line in _creds["info"]:
            st.caption(line)
    else:
        st.error("❌ LLM not configured")
        for issue in _creds["issues"]:
            st.warning(issue)
        st.caption("Edit `.env` then restart Streamlit.")

    if st.button("🔗 Test LLM Connection", use_container_width=True, disabled=not _creds["ready"]):
        with st.spinner("Testing connection…"):
            try:
                _test_llm = initialize_llm(AVAILABLE_MODELS[0])
                _test_resp = _test_llm.invoke([HumanMessage(content="Reply with OK")])
                st.success(f"✅ Connected! Response: `{str(_test_resp.content)[:60]}`")
            except Exception as _e:
                _e_str = str(_e)
                if "getaddrinfo" in _e_str or "ConnectError" in _e_str:
                    st.error("❌ DNS/network error — check `AZURE_OPENAI_ENDPOINT` in `.env`")
                elif "401" in _e_str or "AuthenticationError" in _e_str:
                    st.error("❌ Auth failed — check `AZURE_OPENAI_API_KEY` in `.env`")
                elif "404" in _e_str or "DeploymentNotFound" in _e_str:
                    st.error("❌ Deployment not found — check deployment names in `.env`")
                else:
                    st.error(f"❌ {_e_str[:200]}")

    st.divider()

    # Server status
    st.markdown("### 🌐 Server Status")
    st.caption(f"Endpoint: `{MCP_ENDPOINT}`")

    if st.button("\U0001f504 Refresh Tools", use_container_width=True):
        st.session_state.pop("available_tools", None)
        st.session_state.pop("langchain_tools",  None)
        st.rerun()

    if "available_tools" in st.session_state:
        st.success(f"\u2705 {len(st.session_state['available_tools'])} tools loaded")
        with st.expander("View tools"):
            for t in st.session_state["available_tools"]:
                st.markdown(f"**`{t.name}`** - {t.description or ''}")
    else:
        st.warning("\u26a0\ufe0f Tools not yet loaded")

    st.divider()

    # Clear conversation
    if st.button("\U0001f5d1\ufe0f Clear Conversation", use_container_width=True):
        st.session_state.messages        = [{"role": "assistant", "content": "How can I help you?"}]
        st.session_state.summary         = ""
        st.session_state.conversation_id = str(uuid.uuid4())
        st.rerun()

    st.caption(f"\U0001f464 User: `{user_name}`  |  Session: `{session_id[:12]}...`")

# ---------------------------------------------------------------------------
# Main page
# ---------------------------------------------------------------------------
st.title("FastMCP Analysis V1.0")
st.write("Welcome to the interactive chat app!")
st.write(
    "Ask anything - the assistant will automatically route your request "
    "to the right MCP tool (math, text utilities, health checks, and more)."
)

# Top-of-page credential warning (shown before anything else if not configured)
_startup_creds = _credential_status()
if not _startup_creds["ready"]:
    st.warning(
        "⚠️ **LLM credentials not configured.** "
        "The chatbot won't work until you set valid credentials in `.env` and restart Streamlit.  "
        "See the **🔑 LLM Credentials** panel in the sidebar for details.",
        icon="⚠️",
    )

# Load MCP tools once per session
if "available_tools" not in st.session_state:
    with st.spinner("\U0001f50c Connecting to FastMCP server..."):
        try:
            raw_tools, lc_tools = fetch_tools()
            st.session_state["available_tools"] = raw_tools
            st.session_state["langchain_tools"]  = lc_tools
        except Exception as exc:
            st.error(
                f"\u274c Could not connect to MCP server at `{MCP_ENDPOINT}`.\n\n"
                f"**Error:** `{exc}`\n\n"
                "Make sure the server is running:\n"
                "```\ncd ..  &&  python -m app.server\n```"
            )
            st.session_state["available_tools"] = []
            st.session_state["langchain_tools"]  = []

# Render conversation history
for msg in st.session_state.messages:
    if msg["role"] in ("user", "assistant"):
        with st.chat_message(msg["role"]):
            st.write(msg["content"])
            if msg.get("tool_calls"):
                with st.expander(f"\U0001f527 {len(msg['tool_calls'])} tool call(s)"):
                    for tc in msg["tool_calls"]:
                        st.markdown(f"**Tool:** `{tc['tool']}`")
                        raw_out = tc.get("output", "")
                        try:
                            st.json({"input": tc["input"], "output": json.loads(raw_out)})
                        except Exception:
                            st.markdown(f"**Input:** `{tc['input']}`\n\n**Output:** {raw_out}")

# Chat input
if prompt := st.chat_input():

    if not _has_llm_credentials():
        st.error(
            "\u274c No LLM credentials found.\n\n"
            "Set **`AZURE_OPENAI_ENDPOINT`** + **`AZURE_OPENAI_API_KEY`** "
            "(Azure) or **`OPENAI_API_KEY`** (OpenAI) in your `.env` file."
        )
        st.stop()

    if not st.session_state.get("langchain_tools"):
        st.error("\u274c No MCP tools available. Check that the MCP server is running.")
        st.stop()

    # Display user message
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.chat_message("user").write(prompt)

    # Summarise if history too long (mirrors reference main1.py)
    if len(st.session_state.messages) > MAX_HISTORY:
        old_messages = st.session_state.messages[:-MAX_HISTORY]
        if "summary" not in st.session_state:
            st.session_state.summary = ""
        st.session_state.summary = summarize_old_messages(
            old_messages, st.session_state["sub_agents_model"]
        )

    # Build context (summary + recent messages)
    system_prompt = (
        "You are a helpful assistant with access to a set of MCP tools. "
        "Use the tools when they help answer the user's question. "
        "Always present tool results in a clear, readable format."
    )
    if st.session_state.summary:
        system_prompt += f"\n\nConversation summary so far:\n{st.session_state.summary}"

    context: list[dict[str, Any]] = [
        {"role": m["role"], "content": m["content"]}
        for m in st.session_state.messages[-MAX_HISTORY:]
        if isinstance(m.get("content"), str)
    ]

    # Run HEAD agent
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            try:
                response_content, tool_calls_log = run_agent(
                    chat_history=context,
                    lc_tools=st.session_state["langchain_tools"],
                    head_model=st.session_state["head_model"],
                    system_prompt=system_prompt,
                )
            except Exception as exc:
                exc_str = str(exc)
                # ── Connection / DNS failure → credentials or endpoint wrong ──
                if "getaddrinfo failed" in exc_str or "ConnectError" in exc_str or "Connection error" in exc_str:
                    creds = _credential_status()
                    st.error(
                        "❌ **Cannot reach the LLM endpoint.**\n\n"
                        + ("\n".join(f"- {i}" for i in creds["issues"]) if creds["issues"] else
                           "The endpoint URL may be wrong or unreachable from this machine.")
                        + "\n\nEdit your `.env` file, save it, then **restart Streamlit**."
                    )
                # ── Auth failure ────────────────────────────────────────────
                elif "AuthenticationError" in exc_str or "401" in exc_str or "invalid_api_key" in exc_str:
                    st.error(
                        "❌ **Authentication failed.**\n\n"
                        "Your API key was rejected.\n"
                        "- Check `AZURE_OPENAI_API_KEY` (or `OPENAI_API_KEY`) in `.env`\n"
                        "- Make sure there are no leading/trailing spaces\n"
                        "- Restart Streamlit after editing `.env`"
                    )
                # ── Deployment not found ─────────────────────────────────────
                elif "DeploymentNotFound" in exc_str or "404" in exc_str:
                    st.error(
                        "❌ **Deployment not found.**\n\n"
                        f"The model deployment name in your `.env` doesn't exist in Azure.\n"
                        f"Check `AZURE_DEPLOYMENT_GPT4O` / `AZURE_DEPLOYMENT_GPT4O_MINI` / "
                        f"`AZURE_DEPLOYMENT_GPT4O_ACT` match exactly what's in your Azure portal."
                    )
                # ── Quota / rate limit ───────────────────────────────────────
                elif "RateLimitError" in exc_str or "429" in exc_str:
                    st.error("❌ **Rate limit hit.** Wait a moment and try again.")
                # ── Fallback ─────────────────────────────────────────────────
                else:
                    st.error(f"❌ Agent error: {exc}")
                logger.exception("Agent error | session=%s", session_id)
                st.stop()

        st.write(response_content)

        if tool_calls_log:
            with st.expander(f"\U0001f527 {len(tool_calls_log)} tool call(s)"):
                for tc in tool_calls_log:
                    st.markdown(f"**Tool:** `{tc['tool']}`")
                    raw_out = tc.get("output", "")
                    try:
                        st.json({"input": tc["input"], "output": json.loads(raw_out)})
                    except Exception:
                        st.markdown(f"**Input:** `{tc['input']}`\n\n**Output:** {raw_out}")

    # Persist
    st.session_state.messages.append({
        "role":       "assistant",
        "content":    response_content,
        "tool_calls": tool_calls_log,
    })