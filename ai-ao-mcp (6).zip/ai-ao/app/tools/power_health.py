import logging
from pydantic import BaseModel
from langchain_core.tools import StructuredTool
from app.tools.tsop_db import query_mysql_database

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PowerHealthCheckArgsSchema(BaseModel):
    node_code: str
    summarize_if_large: bool = True


def power_health_check(node_code: str, summarize_if_large: bool = True):
    """
    Query the TSOP database to check the power source and estimated reserve of a node.
    """
    power_query = f"""
    SELECT
        CONCAT(
            CASE
                WHEN GROUP_CONCAT(e.TYPE) LIKE '%C%' THEN 'Continuous Run Diesel with Battery Backup'
                WHEN GROUP_CONCAT(e.TYPE) LIKE '%F%' THEN 'Mains Power with Hydrogen Fuel Cell and Battery Backup'
                WHEN GROUP_CONCAT(pc.DISSHORT) LIKE '%H%' THEN 'Solar and Diesel engine with Battery Backup'
                WHEN GROUP_CONCAT(pc.DISSHORT) LIKE '%5%' THEN 'Solar with Battery Backup'
                WHEN GROUP_CONCAT(e.TYPE) LIKE '%EX%' THEN 'Mains Power with Diesel engine and Battery Backup'
                ELSE 'Mains Power with Battery Backup'
            END,
            ', Total estimated reserve power of ', ROUND(r.totalReserve, 1), ' hrs.'
        ) AS `Power Source`
    FROM ninja3.puma_solar_nodes p
    LEFT JOIN inventory.NF_NP_SITESUMMARY s ON s.node_address_id = p.address_id
    LEFT JOIN netpower.BATTERY b ON s.KEYID = b.KEYID
    LEFT JOIN netpower.EPP e ON s.KEYID = e.KEYID
    LEFT JOIN netpower.PC pc ON s.KEYID = pc.KEYID AND pc.disshort = 'V'
    LEFT JOIN alpha_prod.1rd_reserve_details r ON s.node_address_id = r.addressid
    WHERE s.NOU = '0'
      AND p.node_code = '{node_code}'
    GROUP BY s.node_site_id
    ORDER BY pc.DISSHORT DESC;
    """

    location_query = f"""
    SELECT lat, lon, site_name, site_description
    FROM inventory.site_ranking
    WHERE address_and_pwrid_list LIKE '%{node_code}%'
    LIMIT 1;
    """

    try:
        power_result = query_mysql_database("tsop", power_query, summarize_if_large=summarize_if_large)
    except Exception as e:
        logger.error(f"Error querying power info for node {node_code}: {e}")
        power_result = {"error": f"Failed to retrieve power info for node {node_code}"}

    try:
        location_result = query_mysql_database("tsop", location_query, summarize_if_large=summarize_if_large)
    except Exception as e:
        logger.error(f"Error querying location info for node {node_code}: {e}")
        location_result = {"error": f"Failed to retrieve location info for node {node_code}"}

    return {"power_info": power_result, "location_info": location_result}


power_health_check_tool = StructuredTool.from_function(
    name="power_health_check",
    description="Check the power source, estimated reserve, and location of a given node in the TSOP database.",
    func=power_health_check,
    args_schema=PowerHealthCheckArgsSchema,
)
