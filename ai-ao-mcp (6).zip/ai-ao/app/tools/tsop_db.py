import json
import logging
import mysql.connector
from pydantic import BaseModel
from langchain_core.tools import StructuredTool
from app.config.settings import settings
from app.utils.llm import initialize_llm
from app.utils.summarization_utils import summarize_large_payload

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class IncidentQueryArgsSchema(BaseModel):
    incident_number: str
    summarize_if_large: bool = True


class ConenQueryArgsSchema(BaseModel):
    conen_id: str
    summarize_if_large: bool = True


def query_mysql_database(db_name: str, query: str, summarize_if_large: bool = True):
    """
    Connects to a MySQL database, executes a SQL query, and returns results as a list of dicts.
    Optionally summarizes results if the payload is large.
    """
    try:
        logger.info(f"Connecting to MySQL database: {db_name}")
        conn = mysql.connector.connect(
            host=settings.TSOP_HOST,
            port=settings.TSOP_PORT,
            user=settings.ROBOT_USER_NAME,
            password=settings.TSOP_DB_PASSWORD,
            database=db_name,
        )
        cursor = conn.cursor()
        logger.info(f"Executing query: {query}")
        cursor.execute(query)

        columns = [desc[0] for desc in cursor.description]
        results = cursor.fetchall()
        logger.info(f"Query returned {len(results)} rows.")

        cursor.close()
        conn.close()

        data = [
            {col: val for col, val in zip(columns, row) if val is not None}
            for row in results
        ]
        text_payload = json.dumps(data, indent=2, default=str)

        if summarize_if_large:
            llm = initialize_llm(settings.SUMMARIZE_LLM)
            summary = summarize_large_payload(text_payload, llm)
            return summary if summary else data
        return data

    except mysql.connector.Error as err:
        logger.error(f"MySQL error: {err}")
        return {"error": f"Database error: {err}"}
    except Exception as e:
        logger.exception("Unexpected error during database query.")
        return {"error": f"Unexpected error: {str(e)}"}


def query_incident_details(incident_number: str, summarize_if_large: bool = True):
    """
    Retrieves incident details, linked tasks, work logs, and related requests
    for a given incident number from the ninja3 database.
    """
    queries = {
        "incident_details": f"""
            SELECT
                from_unixtime(FLOOR(time_stamp/1000)) AS time_stamp_readable,
                from_unixtime(FLOOR(last_modified_date/1000)) AS last_modified_date_readable,
                from_unixtime(FLOOR(last_resolved_date/1000)) AS last_resolved_date_readable,
                from_unixtime(FLOOR(next_target_date/1000)) AS next_target_date_readable,
                from_unixtime(FLOOR(reported_date/1000)) AS reported_date_readable,
                from_unixtime(FLOOR(required_resolution_datetime/1000)) AS required_resolution_datetime_readable,
                from_unixtime(FLOOR(responded_date/1000)) AS responded_date_readable,
                from_unixtime(FLOOR(status_history_assigned_time/1000)) AS status_history_assigned_time_readable,
                from_unixtime(FLOOR(status_history_cancelled_time/1000)) AS status_history_cancelled_time_readable,
                from_unixtime(FLOOR(status_history_closed_time/1000)) AS status_history_closed_time_readable,
                from_unixtime(FLOOR(status_history_in_progress_time/1000)) AS status_history_in_progress_time_readable,
                from_unixtime(FLOOR(status_history_new_time/1000)) AS status_history_new_time_readable,
                from_unixtime(FLOOR(status_history_pending_time/1000)) AS status_history_pending_time_readable,
                from_unixtime(FLOOR(status_history_resolved_time/1000)) AS status_history_resolved_time_readable,
                from_unixtime(FLOOR(submit_date/1000)) AS submit_date_readable,
                from_unixtime(FLOOR(vendor_resolved_date/1000)) AS vendor_resolved_date_readable
            FROM ninja3.itan_inc
            WHERE incident_number = '{incident_number}';
        """,
        "linked_tasks": f"""
            SELECT
                from_unixtime(FLOOR(time_stamp/1000)) AS time_stamp_readable,
                from_unixtime(FLOOR(actual_end_date/1000)) AS actual_end_date_readable,
                from_unixtime(FLOOR(actual_start_date/1000)) AS actual_start_date_readable,
                from_unixtime(FLOOR(create_date/1000)) AS create_date_readable,
                from_unixtime(FLOOR(modified_date/1000)) AS modified_date_readable,
                from_unixtime(FLOOR(reported_date/1000)) AS reported_date_readable,
                from_unixtime(FLOOR(scheduled_end_date/1000)) AS scheduled_end_date_readable,
                from_unixtime(FLOOR(scheduled_start_date/1000)) AS scheduled_start_date_readable
            FROM ninja3.itan_tas
            WHERE root_request_id = '{incident_number}';
        """,
        "work_logs": f"""
            SELECT
                from_unixtime(FLOOR(time_stamp/1000)) AS time_stamp_readable,
                from_unixtime(FLOOR(last_modified_date/1000)) AS last_modified_date_readable,
                from_unixtime(FLOOR(work_log_submit_date/1000)) AS work_log_submit_date_readable
            FROM ninja3.itam_inc_work_log
            WHERE incident_number = '{incident_number}'
            ORDER BY work_log_submit_date;
        """,
        "related_requests": f"""
            SELECT
                from_unixtime(FLOOR(time_stamp/1000)) AS time_stamp_readable,
                from_unixtime(FLOOR(last_modified_date/1000)) AS last_modified_date_readable
            FROM ninja3.itam_inc_assoc
            WHERE request_id_2 = '{incident_number}';
        """,
    }

    results = {}
    for key, query in queries.items():
        results[key] = query_mysql_database("ninja3", query, summarize_if_large=summarize_if_large)
    return results


query_incident_details_tool = StructuredTool.from_function(
    name="query_incident_details",
    description=(
        "Retrieves incident details, linked tasks, work logs, and related requests "
        "for a given incident number from the ninja3 database."
    ),
    func=query_incident_details,
    args_schema=IncidentQueryArgsSchema,
)


def query_conen_details(conen_id: str, summarize_if_large: bool = True):
    """
    Queries the 'conen' database for a specific record by conen ID.
    Strips a leading 'C' if present.
    """
    if isinstance(conen_id, str) and conen_id.upper().startswith("C"):
        conen_id = conen_id[1:]
    query = f"SELECT * FROM conen WHERE id = {int(conen_id)};"
    return query_mysql_database("conen", query, summarize_if_large=summarize_if_large)


query_conen_details_tool = StructuredTool.from_function(
    name="query_conen_details",
    description="Retrieves details for a given conen ID from the conen database.",
    func=query_conen_details,
    args_schema=ConenQueryArgsSchema,
)
