import json
import logging
import requests
from requests.auth import HTTPBasicAuth
from pydantic import BaseModel
from langchain_core.tools import StructuredTool
from app.config.settings import settings
from app.utils.llm import initialize_llm
from app.utils.summarization_utils import summarize_large_payload

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class CallAnomalyAPIArgsSchema(BaseModel):
    start_time: str
    duration: int
    metric_name: str


def call_anomaly_api(start_time: str, duration: int, metric_name: str, summarize_if_large: bool = True):
    """
    Calls the Vital12 anomaly API and optionally summarizes the response if the payload is large.
    """
    params = {
        "start_time": start_time,
        "duration": duration,
        "metric_name": metric_name,
    }
    response = requests.get(
        settings.VITAL12_ANOMALIES,
        auth=HTTPBasicAuth(settings.ROBOT_USER_NAME, settings.ROBOT_USER_PASSWORD),
        params=params,
        verify=False,
        timeout=20,
    )

    if response.status_code == 200:
        data = response.json()
        text_payload = json.dumps(data, indent=2)
        if summarize_if_large:
            llm = initialize_llm(settings.SUMMARIZE_LLM)
            summary = summarize_large_payload(text_payload, llm)
            return summary if summary else data
        return data
    return {"error": f"Error: {response.status_code} {response.text}"}


call_anomaly_API_tool = StructuredTool.from_function(
    name="call_anomaly_api",
    description="Query the Vital12 anomaly API to retrieve anomalies.",
    func=call_anomaly_api,
    args_schema=CallAnomalyAPIArgsSchema,
)
