import json
import logging
import requests
from requests.auth import HTTPBasicAuth
from pydantic import BaseModel
from langchain_core.tools import StructuredTool
from app.config.settings import settings
from app.utils.llm import initialize_llm
from app.utils.summarization_utils import summarize_large_payload

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class RagSearchArgsSchema(BaseModel):
    query: str
    workspace: str


def call_rag_search_api(query: str, workspace: str, summarize_if_large: bool = True):
    """
    Calls the IBIS RAG Search API for Confluence and optionally summarizes the response.
    """
    endpoint = f"{settings.IBIS_RAG_SEARCH_HOST}{settings.RAG_SEARCH_CONFLUENCE_ENDPOINT}"
    params = {"query": query, "workspace": workspace}
    headers = {"accept": "application/json"}

    response = requests.get(
        endpoint,
        auth=HTTPBasicAuth(settings.IBIS_API_USER, settings.IBIS_API_PWD),
        params=params,
        headers=headers,
        verify=False,
        timeout=60,
    )

    if response.status_code == 200:
        data = response.json()
        if summarize_if_large:
            llm = initialize_llm(settings.SUMMARIZE_LLM)
            summary = summarize_large_payload(json.dumps(data, indent=2), llm)
            return summary if summary else data
        return data
    return {"error": f"Error: {response.status_code} {response.text}"}


confluence_rag_search_tool = StructuredTool.from_function(
    name="call_rag_search_api",
    description="Query the IBIS RAG Search API for Confluence pages.",
    func=call_rag_search_api,
    args_schema=RagSearchArgsSchema,
)


class AutoRagSearchArgsSchema(BaseModel):
    user_question: str


def call_auto_rag_search_api(user_question: str):
    """
    Automatically searches Confluence pages using a natural language question.
    """
    endpoint = f"{settings.IBIS_RAG_SEARCH_HOST}/confluence_auto_rag"
    params = {"user_question": user_question}
    headers = {"accept": "application/json"}

    response = requests.get(
        endpoint,
        auth=HTTPBasicAuth(settings.IBIS_API_USER, settings.IBIS_API_PWD),
        params=params,
        headers=headers,
        verify=False,
        timeout=60,
    )

    if response.status_code == 200:
        return response.json()
    return {"error": f"Error: {response.status_code} - {response.text}"}


auto_confluence_rag_search_tool = StructuredTool.from_function(
    name="call_auto_rag_search_api",
    description="Automatically search Confluence pages using a natural language question.",
    func=call_auto_rag_search_api,
    args_schema=AutoRagSearchArgsSchema,
)
