import json
import logging
import requests
from threading import Lock
from pydantic import BaseModel
from langchain_core.tools import StructuredTool
from app.config.settings import settings
from app.utils.llm import initialize_llm
from app.utils.summarization_utils import summarize_large_payload

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

api_call_lock = Lock()


class CallRanChatArgsSchema(BaseModel):
    cmd: str
    ird_or_node: str


def call_RAN_chat_api(cmd: str, ird_or_node: str, summarize_if_large: bool = True):
    """
    Makes a call to the RAN chat API for health checks or status updates.

    Args:
        cmd: Command to send (e.g. 'health-check-all', 'health-check-single-node').
        ird_or_node: Either an IRD identifier or node code depending on the command.
        summarize_if_large: Whether to summarize large results.
    """
    params = {"cmd": cmd, "user": "askops", "json": "true"}
    if cmd == "health-check-all":
        params["ird"] = ird_or_node
    elif cmd == "health-check-single-node":
        params["node"] = ird_or_node

    headers = {"Authorization": f"Bearer {settings.TOKEN}"}

    try:
        with api_call_lock:
            response = requests.get(
                settings.CELL_MANAGEMENT,
                params=params,
                headers=headers,
                verify=False,
                timeout=600,
            )
            response.raise_for_status()

        data = response.json()
        if summarize_if_large:
            llm = initialize_llm(settings.SUMMARIZE_LLM)
            summary = summarize_large_payload(json.dumps(data, indent=2), llm)
            return summary if summary else data
        return data

    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to retrieve data from RAN chat API: {e}")
        return {"error": f"Failed to retrieve data: {e}"}


call_RAN_chat_tool = StructuredTool.from_function(
    name="call_RAN_chat_api",
    description=(
        "A tool designed to facilitate health checks and provide real-time status updates for mobile sites."
    ),
    func=call_RAN_chat_api,
    args_schema=CallRanChatArgsSchema,
)
