import logging
import requests
from requests.auth import HTTPBasicAuth
from pydantic import BaseModel
from langchain_core.tools import StructuredTool
from app.config.settings import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class VannaAIArgsSchema(BaseModel):
    question: str


def vanna_ai_query(question: str):
    """
    Generates and runs a SQL query via Vanna AI for TSOP data analysis.
    """
    try:
        # Step 1: Generate SQL
        sql_response = requests.post(
            settings.VANNA_GENERATE_SQL,
            json={"question": question},
            auth=HTTPBasicAuth(settings.VANNA_API_USER, settings.VANNA_API_PWD),
            verify=False,
            timeout=60,
        )
        if sql_response.status_code != 200:
            return {"error": f"SQL generation failed: {sql_response.status_code} {sql_response.text}"}

        sql = sql_response.json().get("sql", "")
        if not sql:
            return {"error": "No SQL generated."}

        # Step 2: Run SQL
        run_response = requests.post(
            settings.VANNA_RUN_SQL,
            json={"sql": sql},
            auth=HTTPBasicAuth(settings.VANNA_API_USER, settings.VANNA_API_PWD),
            verify=False,
            timeout=60,
        )
        if run_response.status_code != 200:
            return {"error": f"SQL execution failed: {run_response.status_code} {run_response.text}"}

        return run_response.json()

    except Exception as e:
        logger.error(f"Vanna AI query failed: {e}")
        return {"error": str(e)}


vanna_ai_tool = StructuredTool.from_function(
    name="vanna_ai_query",
    description="Generate and run SQL queries against TSOP database using Vanna AI natural language interface.",
    func=vanna_ai_query,
    args_schema=VannaAIArgsSchema,
)
