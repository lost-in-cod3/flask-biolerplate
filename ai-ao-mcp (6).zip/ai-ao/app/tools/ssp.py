import logging
import requests
from pydantic import BaseModel
from langchain_core.tools import StructuredTool
from app.config.settings import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SSPSearchArgsSchema(BaseModel):
    street_address: str


def ssp_search_street_address(street_address: str):
    """
    Searches for a street address via the SSP service.
    """
    try:
        response = requests.get(
            settings.SSP_SEARCH_STREET,
            params={"address": street_address},
            verify=False,
            timeout=30,
        )
        if response.status_code == 200:
            return response.json()
        return {"error": f"Error: {response.status_code} {response.text}"}
    except Exception as e:
        logger.error(f"SSP search failed: {e}")
        return {"error": str(e)}


SSP_search_street_address_tool = StructuredTool.from_function(
    name="ssp_search_street_address",
    description="Search for a street address using the SSP service to find nearby sites.",
    func=ssp_search_street_address,
    args_schema=SSPSearchArgsSchema,
)
