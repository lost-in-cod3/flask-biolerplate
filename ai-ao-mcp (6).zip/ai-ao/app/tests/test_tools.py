"""
Unit tests for tool layer.
Run with:  pytest app/tests/ -v
"""
import pytest
from unittest.mock import MagicMock, patch


class TestSummarizationUtils:
    def test_count_tokens_basic(self):
        from app.utils.summarization_utils import count_tokens
        count = count_tokens("Hello, world!")
        assert isinstance(count, int)
        assert count > 0

    def test_summarize_old_messages(self):
        from app.utils.summarization_utils import summarize_old_messages
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(content="Summary text")
        messages = [
            {"role": "user", "content": "What is 2+2?"},
            {"role": "assistant", "content": "It is 4."},
        ]
        result = summarize_old_messages(messages, mock_llm)
        assert result == "Summary text"

    def test_summarize_large_payload_below_threshold(self):
        from app.utils.summarization_utils import summarize_large_payload
        mock_llm = MagicMock()
        short_text = "Short payload"
        result = summarize_large_payload(short_text, mock_llm, token_threshold=999_999)
        assert result is None
        mock_llm.invoke.assert_not_called()


class TestSettings:
    def test_settings_defaults(self):
        from app.config.settings import settings
        assert settings.MCP_PORT == 8000
        assert settings.MAX_MESSAGE_HISTORY == 20
        assert settings.CHUNK_TOKENS == 20000
        assert settings.CHUNK_OVERLAP == 500


class TestAgentManager:
    def test_handoff_tool_name(self):
        from app.core.agent_manager import create_task_description_handoff_tool
        tool = create_task_description_handoff_tool(agent_name="test_agent")
        assert tool.name == "transfer_to_test_agent"

    def test_get_current_utc_datetime(self):
        from app.core.agent_manager import get_current_UTC_datetime
        result = get_current_UTC_datetime.invoke({})
        assert isinstance(result, str)
        assert len(result) == 19  # "YYYY-MM-DD HH:MM:SS"
