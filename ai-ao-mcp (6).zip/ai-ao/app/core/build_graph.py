import logging
import pprint
from langchain_core.messages import AIMessage, SystemMessage, ToolMessage
from langgraph.graph import END, START, MessagesState, StateGraph

from app.core.agent_manager import AgentManager, get_current_UTC_datetime
from app.core.sub_agents_config import SUB_AGENTS_CONFIG, load_selected_agents
from app.tools.tsop_db import query_incident_details_tool, query_conen_details_tool
from app.tools.power_health import power_health_check_tool

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

SUB_AGENTS_NAME = [
    "confluence_rag_search_agent",
    "RAN_chat_agent",
    "SSP_agent",
    "vanna_TSOP_agent",
    "anomaly_agent",
]


def wrap_sub_agent_response(agent_name: str, messages: list) -> list:
    """
    Wraps sub-agent response messages, preserving tool calls and converting
    final AI text to SystemMessages attributed to the sub-agent.
    """
    wrapped = []
    last_tool_call_ids = set()

    for msg in messages:
        if isinstance(msg, AIMessage) and hasattr(msg, "tool_calls") and msg.tool_calls:
            for call in msg.tool_calls:
                last_tool_call_ids.add(call["id"])

    for msg in messages:
        if isinstance(msg, ToolMessage):
            if msg.tool_call_id in last_tool_call_ids:
                wrapped.append(msg)
        elif isinstance(msg, AIMessage):
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                wrapped.append(msg)
            elif msg.content:
                wrapped.append(
                    SystemMessage(
                        content=f"Sub-agent ({agent_name}) response:\n{msg.content}"
                    )
                )
        else:
            wrapped.append(msg)

    return wrapped


def create_wrapped_node(agent_name: str, agent_executor):
    """Returns a LangGraph node function that wraps sub-agent output."""
    def node_fn(state: MessagesState) -> MessagesState:
        result = agent_executor.invoke(state)
        wrapped_messages = wrap_sub_agent_response(agent_name, result["messages"])
        return {"messages": wrapped_messages}

    return node_fn


def create_head_compile_graph(
    sub_agents_name: list[str],
    langfuse,
    langfuse_handler,
    session_id: str | None = None,
    user_name: str | None = None,
    memory=None,
    deployment_model: str | None = None,
    sub_agents_model: str | None = None,
):
    """
    Builds and compiles the LangGraph multi-agent graph with HEAD agent and sub-agents.

    Returns:
        tuple: (HEAD_agent AgentManager, compiled graph)
    """
    graph = StateGraph(MessagesState)

    sub_agents, sub_agents_assignment = load_selected_agents(
        sub_agents_name,
        SUB_AGENTS_CONFIG,
        langfuse,
        user_name=user_name,
        session_id=session_id,
        deployment_model=sub_agents_model,
    )

    HEAD_agent = AgentManager(
        user_name=user_name,
        id=session_id,
        agent_name="HEAD_agent",
        prompt_name="HEAD_agent_prompt",
        deployment_model=deployment_model,
        tools=sub_agents_assignment + [
            get_current_UTC_datetime,
            query_incident_details_tool,
            query_conen_details_tool,
            power_health_check_tool,
        ],
        langfuse=langfuse,
    )

    graph.add_node(
        "HEAD_agent",
        HEAD_agent.create_agent_and_executor(),
    )

    for name, agent in sub_agents.items():
        graph.add_node(name, create_wrapped_node(name, agent))
        graph.add_edge(name, "HEAD_agent")

    graph.add_edge(START, "HEAD_agent")

    compiled = graph.compile(checkpointer=memory).with_config({
        "callbacks": [langfuse_handler],
        "metadata": {
            "langfuse_session_id": session_id,
            "langfuse_user_id": user_name,
        },
    })

    return HEAD_agent, compiled


def get_response(
    session_id: str,
    graph,
    messages: list,
    langfuse_handler,
    head_agent=None,
) -> str:
    """
    Invokes the compiled agent graph with the provided messages and returns the last AI response.
    """
    config = {
        "configurable": {
            "thread_id": session_id,
            "callbacks": langfuse_handler,
        }
    }
    inputs = {"messages": messages}

    try:
        if graph:
            logger.info("Invoking compiled graph.")
            pprint.pprint(config)
            response = graph.invoke(inputs, config=config, debug=True)
        else:
            logger.info("Invoking head agent directly.")
            response = head_agent.invoke(inputs, config=config, debug=True)

        logger.info("Response received successfully.")

        last_ai_msg = next(
            (msg for msg in reversed(response["messages"]) if msg.type == "ai"),
            None,
        )
        return last_ai_msg.content if last_ai_msg else "No assistant response found."

    except Exception as e:
        logger.error(f"An error occurred during get_response: {e}")
        return "No valid response received."
