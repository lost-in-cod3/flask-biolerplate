import logging
from datetime import datetime, timezone
from typing import Annotated

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import tool
from langgraph.graph import MessagesState
from langgraph.prebuilt import InjectedState, create_react_agent
from langgraph.types import Command, Send

from app.services.langfuse_service import nested_prompt_generation
from app.utils.llm import initialize_llm

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@tool
def get_current_UTC_datetime() -> str:
    """Returns the current UTC date and time as a string."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def create_task_description_handoff_tool(*, agent_name: str, description: str | None = None):
    """Creates a handoff tool that transfers control to a named sub-agent."""
    name = f"transfer_to_{agent_name}"
    description = description or f"Ask {agent_name} for help."

    @tool(name, description=description)
    def handoff_tool(
        task_description: Annotated[
            str, "Description of what the next agent should do, including all relevant context."
        ],
        state: Annotated[MessagesState, InjectedState],
    ) -> Command:
        task_description_message = {"role": "user", "content": task_description}
        agent_input = {**state, "messages": [task_description_message]}
        return Command(goto=[Send(agent_name, agent_input)], graph=Command.PARENT)

    return handoff_tool


class AgentManager:
    def __init__(
        self,
        agent_name: str,
        prompt_name: str,
        id: str | None = None,
        user_name: str | None = None,
        deployment_model: str | None = None,
        tools: list | None = None,
        memory=None,
        langfuse=None,
    ):
        self.id = id
        self.user_name = user_name
        self.agent_name = agent_name
        self.prompt_name = prompt_name
        self.deployment_model = deployment_model
        self.tools = tools or []
        self.langfuse = langfuse
        self.memory = memory

    def get_prompt_from_langfuse(self) -> ChatPromptTemplate:
        try:
            prompt = nested_prompt_generation(
                self.langfuse, self.user_name, self.id, self.prompt_name
            )
            return ChatPromptTemplate.from_messages([
                ("system", prompt),
                ("placeholder", "{messages}"),
            ])
        except Exception as e:
            logger.error(f"Failed to fetch prompt for {self.prompt_name}: {e}")
            return ChatPromptTemplate.from_messages([
                ("system", "Default system message."),
                ("placeholder", "{messages}"),
            ])

    def create_agent_and_executor(self):
        return create_react_agent(
            model=initialize_llm(self.deployment_model),
            prompt=self.get_prompt_from_langfuse(),
            tools=self.tools,
            checkpointer=self.memory,
            name=self.agent_name,
        )

    def assign_to_agent(self):
        return create_task_description_handoff_tool(
            agent_name=self.agent_name,
            description=f"Assign task to a {self.agent_name}.",
        )
