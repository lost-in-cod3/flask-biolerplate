import logging
from app.config.settings import settings
from app.tools.confluence_rag_search import confluence_rag_search_tool, auto_confluence_rag_search_tool
from app.tools.ran_chat import call_RAN_chat_tool
from app.tools.ssp import SSP_search_street_address_tool
from app.tools.vanna_ai import vanna_ai_tool
from app.tools.anomaly import call_anomaly_API_tool
from app.core.agent_manager import AgentManager, get_current_UTC_datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Agent configuration map
SUB_AGENTS_CONFIG = {
    "confluence_rag_search_agent": {
        "tools": [confluence_rag_search_tool, auto_confluence_rag_search_tool],
        "prompt": "confluence_rag_search_mini_agent_prompt",
        "deployment_model": settings.LITE_LLM_4O,
    },
    "RAN_chat_agent": {
        "tools": [call_RAN_chat_tool],
        "prompt": "RAN_chat_mini_agent_prompt",
        "deployment_model": settings.LITE_LLM_4O,
    },
    "SSP_agent": {
        "tools": [SSP_search_street_address_tool],
        "prompt": "SSP_mini_agent_prompt",
        "deployment_model": settings.LITE_LLM_4O,
    },
    "vanna_TSOP_agent": {
        "tools": [vanna_ai_tool],
        "prompt": "vanna_TSOP_mini_agent_prompt",
        "deployment_model": settings.LITE_LLM_4O,
    },
    "anomaly_agent": {
        "tools": [call_anomaly_API_tool, get_current_UTC_datetime],
        "prompt": "vital12_anomaly_mini_agent_prompt",
        "deployment_model": settings.LITE_LLM_4O,
    },
}


def load_selected_agents(
    sub_agents_name: list[str],
    config_map: dict,
    langfuse,
    user_name: str | None = None,
    session_id: str | None = None,
    memory=None,
    deployment_model: str | None = None,
) -> tuple[dict, list]:
    """
    Instantiates and returns selected sub-agents and their handoff assignment tools.
    """
    sub_agents = {}
    sub_agents_assignment = []

    for agent_name in sub_agents_name:
        config = config_map.get(agent_name)
        if not config:
            logger.warning(f"Agent '{agent_name}' is not defined in SUB_AGENTS_CONFIG.")
            continue

        config_model = deployment_model or config["deployment_model"]

        sub_agent_mgr = AgentManager(
            tools=config["tools"],
            agent_name=agent_name,
            deployment_model=config_model,
            prompt_name=config["prompt"],
            user_name=user_name,
            id=session_id,
            memory=memory,
            langfuse=langfuse,
        )

        sub_agent_mgr.agent_executor = sub_agent_mgr.create_agent_and_executor()
        sub_agents[agent_name] = sub_agent_mgr.agent_executor
        sub_agents_assignment.append(sub_agent_mgr.assign_to_agent())

    return sub_agents, sub_agents_assignment
