# Intentionally empty - import app and mcp from app.api.server directly when needed.
# Eager imports here cause a sys.modules conflict when running 'python -m app.api.server'.
