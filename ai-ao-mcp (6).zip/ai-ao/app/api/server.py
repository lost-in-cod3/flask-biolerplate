"""
FastMCP Backend Server
Transport: streamable-http
Mount path: /mcp

Exposes two MCP tools to the Streamlit frontend:
  - chat(session_id, user_name, message, head_model, sub_agents_model)
  - submit_feedback(session_id, user_name, prompt, response, value, feedback_text)
"""

import logging
from typing import Annotated

from fastmcp import FastMCP
from pydantic import Field

from app.config.settings import settings
from app.core.build_graph import (
    SUB_AGENTS_NAME,
    create_head_compile_graph,
    get_response,
)
from app.services.langfuse_service import (
    handle_user_feedback,
    langfuse,
    langfuse_handler,
)
from app.utils.llm import initialize_llm
from app.utils.summarization_utils import summarize_old_messages

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# In-memory session store
# key: session_id  →  {"HEAD_agent": ..., "agents_graph": ..., "messages": [...], "summary": ""}
# ---------------------------------------------------------------------------
_sessions: dict[str, dict] = {}


def _get_or_create_session(
    session_id: str,
    user_name: str,
    head_model: str,
    sub_agents_model: str,
) -> dict:
    """Return existing session or create a new compiled graph for the session."""
    if session_id not in _sessions:
        logger.info(f"Creating new agent graph for session: {session_id}")
        HEAD_agent, agents_graph = create_head_compile_graph(
            SUB_AGENTS_NAME,
            langfuse,
            langfuse_handler,
            session_id=session_id + user_name,
            user_name=user_name,
            deployment_model=head_model,
            sub_agents_model=sub_agents_model,
        )
        _sessions[session_id] = {
            "HEAD_agent": HEAD_agent,
            "agents_graph": agents_graph,
            "messages": [{"role": "assistant", "content": "How can I help you?"}],
            "summary": "",
        }
    return _sessions[session_id]


# ---------------------------------------------------------------------------
# FastMCP app
# ---------------------------------------------------------------------------
mcp = FastMCP(
    name="ia-analysis-mcp",
    instructions=(
        "This MCP server provides AI-powered IA analysis tools. "
        "Use the `chat` tool to converse with the multi-agent system, "
        "and `submit_feedback` to record user satisfaction."
    ),
)


@mcp.tool()
def chat(
    session_id: Annotated[str, Field(description="Unique session identifier for the conversation")],
    user_name: Annotated[str, Field(description="Username of the person chatting")],
    message: Annotated[str, Field(description="User's chat message")],
    head_model: Annotated[str, Field(description="LLM model name for the HEAD agent")] = settings.DEFAULT_HEAD_MODEL,
    sub_agents_model: Annotated[str, Field(description="LLM model name for sub-agents")] = settings.DEFAULT_SUB_AGENTS_MODEL,
) -> str:
    """
    Send a message to the IA Analysis multi-agent system and receive a response.
    The session state (conversation history and compiled agent graph) is preserved
    server-side keyed by session_id.
    """
    session = _get_or_create_session(session_id, user_name, head_model, sub_agents_model)
    graph_session_id = session_id + user_name

    # Append user message to history
    session["messages"].append({"role": "user", "content": message})

    # Summarize old messages if history exceeds threshold
    if len(session["messages"]) > settings.MAX_MESSAGE_HISTORY:
        old_messages = session["messages"][: -settings.MAX_MESSAGE_HISTORY]
        summarizer_llm = initialize_llm(settings.SUMMARIZE_LLM)
        session["summary"] = summarize_old_messages(old_messages, summarizer_llm)

    # Build context: optional summary + recent messages
    context = []
    if session["summary"]:
        context.append({"role": "system", "content": session["summary"]})
    context.extend(session["messages"][-settings.MAX_MESSAGE_HISTORY :])

    # Invoke graph
    response_content = get_response(
        graph_session_id,
        session["agents_graph"],
        context,
        langfuse_handler,
        session["HEAD_agent"],
    )

    # Append assistant reply to history
    session["messages"].append({"role": "assistant", "content": response_content})

    return response_content


@mcp.tool()
def submit_feedback(
    session_id: Annotated[str, Field(description="Session ID for the conversation")],
    user_name: Annotated[str, Field(description="Username of the person giving feedback")],
    prompt: Annotated[str, Field(description="The user's original prompt that generated the response")],
    response: Annotated[str, Field(description="The assistant's response being rated")],
    value: Annotated[int, Field(description="Feedback score: 1 for thumbs up, 0 for thumbs down")],
    feedback_text: Annotated[str, Field(description="Optional free-text comment from the user")] = "",
) -> str:
    """
    Submit user feedback (thumbs up/down) for a given assistant response to Langfuse.
    """
    graph_session_id = session_id + user_name
    try:
        handle_user_feedback(
            langfuse,
            user_name,
            graph_session_id,
            prompt,
            response,
            value,
            feedback_text,
        )
        return "Feedback submitted successfully."
    except Exception as e:
        logger.error(f"Failed to submit feedback: {e}")
        return f"Failed to submit feedback: {e}"


# ---------------------------------------------------------------------------
# ASGI entry point — used by uvicorn / docker
# ---------------------------------------------------------------------------
# Mount using streamable-http transport at /mcp
app = mcp.http_app(transport="streamable-http")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.api.server:app",
        host=settings.MCP_HOST,
        port=settings.MCP_PORT,
        reload=False,
    )
