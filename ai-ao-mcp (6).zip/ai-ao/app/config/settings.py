import os
from dotenv import load_dotenv

load_dotenv(override=True)

# If SSL_CERT_FILE is set in the environment but the file doesn't actually exist,
# remove it from os.environ entirely so Python's SSL stack never tries to load it.
_ssl_cert = os.environ.get("SSL_CERT_FILE", "")
if _ssl_cert and not os.path.isfile(_ssl_cert):
    os.environ.pop("SSL_CERT_FILE", None)
    _ssl_cert = ""


class Settings:
    # LiteLLM
    LITE_LLM_URL: str = os.getenv("LITE_LLM_URL", "")
    LITE_LLM_KEY: str = os.getenv("LITE_LLM_KEY", "")
    LITE_LLM_4O: str = os.getenv("LITE_LLM_4o", "azure-gpt-4o")
    SUMMARIZE_LLM: str = os.getenv("SUMMARIZE_LLM", "gpt-4o-mini")

    # Langfuse
    LANGFUSE_PUBLIC_KEY: str = os.getenv("LANGFUSE_PUBLIC_KEY", "")
    LANGFUSE_SECRET_KEY: str = os.getenv("LANGFUSE_SECRET_KEY", "")
    LANGFUSE_HOST: str = os.getenv("LANGFUSE_HOST", "")

    # SSL -- empty string means "use system default / no custom cert"
    SSL_CERT_FILE: str = _ssl_cert

    # Auth
    IBIS_API_USER: str = os.getenv("IBIS_API_USER", "")
    IBIS_API_PWD: str = os.getenv("IBIS_API_PWD", "")
    ROBOT_USER_NAME: str = os.getenv("robot_user_name", "")
    ROBOT_USER_PASSWORD: str = os.getenv("robot_user_password", "")
    SENTINEL_ROBOT_USER_PASSWORD: str = os.getenv("sentinel_robot_user_password", "")
    TOKEN: str = os.getenv("TOKEN", "")
    VANNA_API_USER: str = os.getenv("VANNA_API_USER", "")
    VANNA_API_PWD: str = os.getenv("VANNA_API_PWD", "")
    ACCOUNT_01_PASSWORD: str = os.getenv("account_01_password", "")

    # Endpoints
    IBIS_RAG_SEARCH_HOST: str = os.getenv("IBIS_RAG_SEARCH_HOST", "")
    RAG_SEARCH_ENDPOINT: str = os.getenv("RAG_SEARCH_ENDPOINT", "/rag_search")
    RAG_SEARCH_CONFLUENCE_ENDPOINT: str = os.getenv("RAG_SEARCH_CONFLUENCE_ENDPOINT", "/rag_search_confluence")
    RAG_SEARCH: str = os.getenv("RAG_SEARCH", "")
    RAG_SEARCH_CONFLUENCE: str = os.getenv("RAG_SEARCH_CONFLUENCE", "")
    VITAL12_ANOMALIES: str = os.getenv("VITAL12_ANOMALIES", "")
    CELL_MANAGEMENT: str = os.getenv("CELL_MANAGEMENT", "")
    SSP_SEARCH_STREET: str = os.getenv("SSP_search_street", "")

    # TSOP DB
    TSOP_HOST: str = os.getenv("TSOP_HOST", "")
    TSOP_PORT: int = int(os.getenv("TSOP_PORT", "3306"))
    TSOP_DB_PASSWORD: str = os.getenv("TSOP_DB_PASSWORD", "")

    # Genie / Vanna
    GENIE_HOST: str = os.getenv("GENIE_HOST", "")
    GENIE_LOGIN_ENDPOINT: str = os.getenv("GENIE_LOGIN_ENDPOINT", "login")
    GENIE_GENERATE_SQL_ENDPOINT: str = os.getenv("GENIE_GENERATE_SQL_ENDPOINT", "generate_sql")
    VANNA_HOST: str = os.getenv("VANNA_HOST", "")
    VANNA_GENERATE_SQL_ENDPOINT: str = os.getenv("VANNA_GENERATE_SQL_ENDPOINT", "/api/ve/generate_sql")
    VANNA_GENERATE_SUMMARY_ENDPOINT: str = os.getenv("VANNA_GENERATE_SUMMARY_ENDPOINT", "/api/v0/generate_summary")
    VANNA_GENERATE_SQL: str = os.getenv("VANNA_GENERATE_SQL", "")
    VANNA_RUN_SQL: str = os.getenv("VANNA_RUN_SQL", "")
    VANNA_GENERATE_SUMMARY: str = os.getenv("VANNA_GENERATE_SUMMARY", "")

    # Enterprise Services
    ENTERPRISE_SERVICES_BASE_URL: str = os.getenv("ENTERPRISE_SERVICES_BASE_URL", "")
    ENTERPRISE_SERVICES_ENDPOINT: str = os.getenv("ENTERPRISE_SERVICES_ENDPOINT", "/information/xdi/")

    # Tiktoken
    TIKTOKEN_CACHE_DIR: str = os.getenv("TIKTOKEN_CACHE_DIR", "./app/tiktoken_cache")

    # Chunking / history
    CHUNK_TOKENS: int = int(os.getenv("CHUNK_TOKENS", "20000"))
    CHUNK_OVERLAP: int = int(os.getenv("CHUNK_OVERLAP", "500"))
    TOKEN_THRESHOLD: int = int(os.getenv("TOKEN_THRESHOLD", "20000"))
    MAX_MESSAGE_HISTORY: int = int(os.getenv("MAX_MESSAGE_HISTORY", "20"))

    # MCP server
    MCP_HOST: str = os.getenv("MCP_HOST", "0.0.0.0")
    MCP_PORT: int = int(os.getenv("MCP_PORT", "8000"))

    # Available models
    AVAILABLE_MODELS: list = ["azure-gpt-4o", "gpt-4o-mini", "azure-gpt-4o-act"]
    DEFAULT_HEAD_MODEL: str = "azure-gpt-4o-act"
    DEFAULT_SUB_AGENTS_MODEL: str = "azure-gpt-4o-act"


settings = Settings()
