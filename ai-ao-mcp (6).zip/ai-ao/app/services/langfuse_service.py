"""
Langfuse service -- compatible with langfuse v2, v3, and v4.

Uses only the stable Langfuse() client directly.
The observe/langfuse_context decorator API is intentionally avoided
as it changed location in every major version.
"""
import logging
import os
from typing import Optional

from langfuse import Langfuse

# CallbackHandler location changed across versions -- try each in order.
_CallbackHandler = None
for _mod in ("langfuse.langchain", "langfuse.callback", "langfuse.integrations.langchain"):
    try:
        import importlib as _il
        _m = _il.import_module(_mod)
        _CallbackHandler = getattr(_m, "CallbackHandler", None)
        if _CallbackHandler is not None:
            break
    except ImportError:
        continue

from app.config.settings import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def initialize_langfuse():
    """
    Initializes the Langfuse client and LangChain CallbackHandler.
    Returns (langfuse, langfuse_handler) on success, (None, None) otherwise.
    Server starts cleanly even when Langfuse is not configured.
    """
    if not settings.LANGFUSE_PUBLIC_KEY or not settings.LANGFUSE_SECRET_KEY:
        logger.warning(
            "Langfuse credentials not set -- observability disabled. "
            "Set LANGFUSE_PUBLIC_KEY, LANGFUSE_SECRET_KEY, LANGFUSE_HOST in .env to enable."
        )
        return None, None

    try:
        init_kwargs = dict(
            public_key=settings.LANGFUSE_PUBLIC_KEY,
            secret_key=settings.LANGFUSE_SECRET_KEY,
        )
        if settings.LANGFUSE_HOST:
            init_kwargs["host"] = settings.LANGFUSE_HOST

        lf = Langfuse(**init_kwargs)
        if not lf.auth_check():
            logger.warning("Langfuse auth check failed -- observability disabled.")
            return None, None

        lf_handler = None
        if _CallbackHandler is not None:
            try:
                lf_handler = _CallbackHandler(**init_kwargs)
            except Exception as e:
                logger.warning(f"Langfuse CallbackHandler init failed (tracing disabled): {e}")

        logger.info("Langfuse initialized successfully.")
        return lf, lf_handler

    except Exception as e:
        logger.error(f"Failed to initialize Langfuse: {e}")
        return None, None


def nested_prompt_generation(
    langfuse: Optional[Langfuse],
    user_name: str,
    session_id: str,
    prompt_name: str,
) -> str:
    """
    Fetch a prompt template from Langfuse by name.
    Falls back to a generic system prompt when Langfuse is unavailable.
    """
    if langfuse is None:
        logger.warning(f"Langfuse unavailable -- using default prompt for '{prompt_name}'.")
        return "You are a helpful AI assistant."
    try:
        lf_prompt = langfuse.get_prompt(prompt_name, label="latest")
        return lf_prompt.get_langchain_prompt()
    except Exception as e:
        logger.error(f"Failed to fetch prompt '{prompt_name}' from Langfuse: {e}")
        return "You are a helpful AI assistant."


def handle_user_feedback(
    langfuse: Optional[Langfuse],
    user_name: str,
    session_id: str,
    prompt: str,
    response_content: str,
    value: int,
    feedback_text: str,
):
    """
    Record user feedback in Langfuse. No-ops if Langfuse is unavailable.
    """
    if langfuse is None:
        logger.warning("Langfuse unavailable -- feedback not recorded.")
        return
    try:
        trace = langfuse.trace(
            name="assistant_response",
            input={"user_input": prompt},
            output={"assistant_response": response_content},
            user_id=user_name,
            session_id=session_id,
        )
        langfuse.score(
            trace_id=trace.id,
            name="user_feedback",
            value=value,
            comment=feedback_text,
        )
    except Exception as e:
        logger.error(f"Failed to record feedback in Langfuse: {e}")


# Module-level singletons -- never crash on import
langfuse, langfuse_handler = initialize_langfuse()
