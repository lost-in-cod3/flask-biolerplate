import tiktoken
import logging
import os
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.language_models import BaseLanguageModel
from langchain_text_splitters import TokenTextSplitter
from app.config.settings import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

CHUNK_TOKENS = settings.CHUNK_TOKENS
CHUNK_OVERLAP = settings.CHUNK_OVERLAP
TOKEN_THRESHOLD = settings.TOKEN_THRESHOLD


def _ensure_tiktoken_cache():
    """Ensure tiktoken cache directory exists with correct permissions."""
    cache_dir = settings.TIKTOKEN_CACHE_DIR
    if cache_dir:
        os.makedirs(cache_dir, exist_ok=True)
        try:
            os.chmod(cache_dir, 0o777)
        except Exception:
            pass


_ensure_tiktoken_cache()


def count_tokens(text: str) -> int:
    """Count the number of tokens using tiktoken CL100K encoding."""
    try:
        encoding = tiktoken.get_encoding("cl100k_base")
    except Exception as e:
        logger.error(f"Failed to load tokenizer encoding: {e}")
        raise
    token_count = len(encoding.encode(text))
    logger.info(f"Token count for input text: {token_count}")
    return token_count


def summarize_large_payload(
    payload_text: str,
    llm: BaseLanguageModel,
    max_tokens_per_chunk: int = CHUNK_TOKENS,
    chunk_overlap: int = CHUNK_OVERLAP,
    summary_prompt: str = "Summarize the following content:",
    final_prompt: str = "Based on the following summaries, combine them into a complete message:",
    token_threshold: int = TOKEN_THRESHOLD,
) -> str | None:
    """
    Summarizes a large payload using an LLM, splitting into chunks if necessary.
    Returns the final summary or None if summarization is not needed.
    """
    logger.info("Starting summarization process.")
    token_count = count_tokens(payload_text)

    if token_count <= token_threshold:
        logger.info(f"Token count within threshold ({token_threshold}). Skipping summarization.")
        return None

    logger.info(f"Token count exceeds threshold. Splitting into chunks of {max_tokens_per_chunk}.")
    splitter = TokenTextSplitter(
        chunk_size=max_tokens_per_chunk,
        chunk_overlap=chunk_overlap,
        encoding_name="cl100k_base",
    )
    chunks = splitter.split_text(payload_text)
    logger.info(f"Total chunks created: {len(chunks)}")

    chunk_summaries = []
    for i, chunk in enumerate(chunks):
        logger.info(f"Summarizing chunk {i + 1}/{len(chunks)}")
        prompt = ChatPromptTemplate.from_messages([
            ("system", summary_prompt),
            ("user", chunk),
        ])
        summary = llm.invoke(prompt.format_messages())
        chunk_summaries.append(summary.content)

    logger.info("Combining chunk summaries.")
    final_input = "\n\n".join(chunk_summaries)
    final_prompt_template = ChatPromptTemplate.from_messages([
        ("system", final_prompt),
        ("user", final_input),
    ])
    final_summary = llm.invoke(final_prompt_template.format_messages())
    logger.info("Final summary complete.")
    return final_summary.content


def summarize_old_messages(messages: list[dict], llm: BaseLanguageModel) -> str:
    """
    Summarizes a list of chat messages using the provided language model.
    """
    text = "\n".join([f"{m['role']}: {m['content']}" for m in messages])
    prompt = f"Summarize the following conversation:\n{text}"
    response = llm.invoke(prompt)
    return response.content if hasattr(response, "content") else response
