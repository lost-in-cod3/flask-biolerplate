import logging
from langchain_openai import ChatOpenAI
from app.config.settings import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def initialize_llm(deployment_model: str) -> ChatOpenAI:
    """
    Initialize the ChatOpenAI client using LiteLLM endpoint.
    """
    if not settings.LITE_LLM_KEY:
        raise ValueError("API key not found. Please set the LITE_LLM_KEY environment variable.")
    if not settings.LITE_LLM_URL:
        raise ValueError("LiteLLM URL not found. Please set the LITE_LLM_URL environment variable.")

    return ChatOpenAI(
        api_key=settings.LITE_LLM_KEY,
        base_url=settings.LITE_LLM_URL,
        model=deployment_model,
    )
