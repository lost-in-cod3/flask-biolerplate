"""
Streamlit Frontend for IA Analysis
Connects to the FastMCP backend via the MCP streamable-http transport.
"""

import asyncio
import logging
import os
import threading
import uuid

import streamlit as st
from dotenv import load_dotenv
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
load_dotenv(override=True)

MCP_SERVER_URL = os.getenv("MCP_SERVER_URL", "http://localhost:8000/mcp")
AVAILABLE_MODELS = ["azure-gpt-4o", "gpt-4o-mini", "azure-gpt-4o-act"]
DEFAULT_MODEL = "azure-gpt-4o-act"

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Event-loop helper — Python 3.14 compatible
# ---------------------------------------------------------------------------
def _run_async(coro):
    """
    Run an async coroutine safely from any context — including inside
    Streamlit which owns its own running event loop in Python 3.14+.

    Spawns a daemon thread with a brand-new event loop so we never
    try to nest `asyncio.run()` inside an already-running loop.
    """
    result_holder: list = []
    exc_holder: list = []

    def _thread_target():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result_holder.append(loop.run_until_complete(coro))
        except Exception as exc:
            exc_holder.append(exc)
        finally:
            loop.close()

    thread = threading.Thread(target=_thread_target, daemon=True)
    thread.start()
    thread.join()

    if exc_holder:
        raise exc_holder[0]
    return result_holder[0]


# ---------------------------------------------------------------------------
# MCP helper functions
# ---------------------------------------------------------------------------
async def _call_mcp_tool(tool_name: str, arguments: dict) -> str:
    """Connect to the MCP server and invoke a single tool, returning its text result."""
    async with streamablehttp_client(MCP_SERVER_URL) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(tool_name, arguments=arguments)
            if result.content:
                first = result.content[0]
                return first.text if hasattr(first, "text") else str(first)
            return "No response received."


def call_chat(
    session_id: str,
    user_name: str,
    message: str,
    head_model: str,
    sub_agents_model: str,
) -> str:
    """Call the MCP `chat` tool synchronously from Streamlit."""
    return _run_async(
        _call_mcp_tool(
            "chat",
            {
                "session_id": session_id,
                "user_name": user_name,
                "message": message,
                "head_model": head_model,
                "sub_agents_model": sub_agents_model,
            },
        )
    )


def call_submit_feedback(
    session_id: str,
    user_name: str,
    prompt: str,
    response: str,
    value: int,
    feedback_text: str,
) -> str:
    """Call the MCP `submit_feedback` tool synchronously from Streamlit."""
    return _run_async(
        _call_mcp_tool(
            "submit_feedback",
            {
                "session_id": session_id,
                "user_name": user_name,
                "prompt": prompt,
                "response": response,
                "value": value,
                "feedback_text": feedback_text,
            },
        )
    )


# ---------------------------------------------------------------------------
# Feedback handler
# ---------------------------------------------------------------------------
def handle_feedback(value: int):
    """Called when the user clicks 👍 or 👎."""
    fb = st.session_state.get("feedback_input", "")
    last_user_msg = next(
        (m["content"] for m in reversed(st.session_state.messages) if m["role"] == "user"),
        "",
    )
    last_ai_msg = next(
        (m["content"] for m in reversed(st.session_state.messages) if m["role"] == "assistant"),
        "",
    )
    result = call_submit_feedback(
        st.session_state.conversation_id,
        st.session_state.get("user", "local_user"),
        last_user_msg,
        last_ai_msg,
        value,
        fb,
    )
    st.toast(f"Feedback submitted — thank you! ({result})")


# ---------------------------------------------------------------------------
# Main Streamlit app
# ---------------------------------------------------------------------------
def main():
    # ---- Resolve username from auth proxy header or default ----
    user_name = "local_user"
    if st.context.headers:
        headers_dict = st.context.headers.to_dict()
        proxy_user = headers_dict.get("X-Auth-Request-Preferred-Username")
        if proxy_user:
            st.session_state.user = proxy_user
            user_name = proxy_user

    # ---- Session ID ----
    if "conversation_id" not in st.session_state:
        st.session_state.conversation_id = str(uuid.uuid4())

    # ---- Page config ----
    st.set_page_config(page_title="IA Analysis", page_icon="🔍", layout="wide")

    # ---- Title & description ----
    st.title("IA Analysis V2.0")
    st.write("Welcome to the interactive chat app!")
    st.write(
        "The app is designed to help analyzing IAs, answering questions about related IAs, "
        "previous IAs, previous causes, common causes etc."
    )

    # ---- Sidebar ----
    with st.sidebar:
        st.markdown("##### User Guide")
        st.markdown('<a href="https://google.com" target="_blank">📖 User Guide</a>', unsafe_allow_html=True)

        st.markdown("##### Changelogs")
        st.markdown('<a href="https://google.com" target="_blank">📋 Changelogs</a>', unsafe_allow_html=True)

        st.markdown("##### Issue Register")
        st.markdown('<a href="https://google.com" target="_blank">🐞 Issue Register</a>', unsafe_allow_html=True)

        st.divider()

        st.markdown("### Model Configuration")
        st.info("Please refresh the page before switching models to ensure changes take effect.")

        head_model = st.selectbox(
            "HEAD Agent LLM",
            AVAILABLE_MODELS,
            index=AVAILABLE_MODELS.index(DEFAULT_MODEL),
            key="head_model",
        )
        sub_agents_model = st.selectbox(
            "Sub-Agents LLM",
            AVAILABLE_MODELS,
            index=AVAILABLE_MODELS.index(DEFAULT_MODEL),
            key="sub_agents_model",
        )

        st.divider()
        st.caption(f"Session ID: `{st.session_state.conversation_id[:8]}...`")
        st.caption(f"User: `{user_name}`")

        if st.button("🗑️ Clear Conversation", use_container_width=True):
            st.session_state.messages = [{"role": "assistant", "content": "How can I help you?"}]
            st.session_state.conversation_id = str(uuid.uuid4())
            st.rerun()

    # ---- Message history ----
    if "messages" not in st.session_state:
        st.session_state.messages = [{"role": "assistant", "content": "How can I help you?"}]

    for msg in st.session_state.messages:
        if msg["role"] in ("user", "assistant"):
            st.chat_message(msg["role"]).write(msg["content"])

    # ---- Chat input ----
    if prompt := st.chat_input("Ask something about your IAs..."):
        # Show user message immediately
        st.session_state.messages.append({"role": "user", "content": prompt})
        st.chat_message("user").write(prompt)

        # Call MCP backend
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    response_content = call_chat(
                        session_id=st.session_state.conversation_id,
                        user_name=user_name,
                        message=prompt,
                        head_model=st.session_state.get("head_model", DEFAULT_MODEL),
                        sub_agents_model=st.session_state.get("sub_agents_model", DEFAULT_MODEL),
                    )
                except Exception as e:
                    logger.error(f"MCP call failed: {e}")
                    response_content = f"⚠️ Error communicating with the backend: {e}"

            st.write(response_content)

        st.session_state.messages.append({"role": "assistant", "content": response_content})

        # ---- Feedback section ----
        st.divider()
        st.text_input(
            "Please provide your feedback on the above response:",
            key="feedback_input",
            placeholder="Optional comment...",
        )
        col1, col2, _ = st.columns([1, 1, 8])
        with col1:
            st.button("👍", on_click=handle_feedback, args=(1,), key="thumbs_up")
        with col2:
            st.button("👎", on_click=handle_feedback, args=(0,), key="thumbs_down")


main()
