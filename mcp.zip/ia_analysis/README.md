# IA Analysis – FastMCP Backend

Multi-agent IA analysis chatbot backed by a **FastMCP Streamable-HTTP** server
and a Streamlit frontend.

```
ia_analysis/
├── app/
│   ├── api/
│   │   ├── __init__.py
│   │   ├── server.py          ← FastMCP entry point (Streamable-HTTP)
│   │   └── tools.py           ← All 7 MCP tool definitions
│   ├── config/
│   │   ├── __init__.py
│   │   ├── langfuse_config.py ← Langfuse client & user_feedback helper
│   │   └── settings.py        ← Pydantic-settings (reads .env)
│   ├── core/
│   │   ├── __init__.py
│   │   ├── graph.py           ← LangGraph agent graph wrapper + cache
│   │   └── llm.py             ← AzureChatOpenAI factory (cached)
│   ├── services/
│   │   ├── __init__.py
│   │   ├── chat_service.py    ← Top-level orchestrator
│   │   ├── session_service.py ← In-memory session store
│   │   └── summarization_service.py
│   ├── tests/
│   │   ├── __init__.py
│   │   └── test_chat.py
│   ├── tiktoken_cache/        ← Pre-populated at Docker build time
│   ├── tools/
│   │   ├── __init__.py
│   │   └── summarization_utils.py
│   └── utils/
│       ├── __init__.py
│       ├── helpers.py
│       └── mcp_client.py      ← Synchronous HTTP client used by Streamlit
├── infrastructure/
│   └── template/
│       ├── Dockerfile
│       └── docker-compose.yml
├── frontend/
│   └── streamlit.py           ← Thin UI; delegates all AI work to MCP server
├── .env.example
├── requirements.txt
└── requirements-frontend.txt
```

## Quick start

```bash
# 1. Copy and fill in environment variables
cp .env.example .env

# 2. Install backend dependencies
pip install -r requirements.txt

# 3. Run the MCP server (development mode with auto-reload)
python -m app.api.server

# 4. In a second terminal, run the Streamlit frontend
pip install -r requirements-frontend.txt
MCP_SERVER_URL=http://localhost:8000 streamlit run frontend/streamlit.py
```

## Docker (full stack)

```bash
cd infrastructure/template
docker compose up --build
# Backend  → http://localhost:8000/mcp
# Frontend → http://localhost:8501
```

## MCP tools exposed

| Tool | Description |
|---|---|
| `create_session` | Create a new conversation session |
| `chat` | Send a message; receive the multi-agent response |
| `get_conversation_history` | Retrieve full message history |
| `delete_session` | Remove a session and its history |
| `submit_feedback` | Record thumbs-up / thumbs-down in Langfuse |
| `get_available_models` | List available LLM deployments |
| `list_sessions` | Admin: list active sessions |

## Running tests

```bash
pytest app/tests/ -v
```
