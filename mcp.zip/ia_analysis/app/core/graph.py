"""
Agent graph wiring – thin wrapper around ``build_graph`` so the MCP layer
never imports directly from the legacy module.

Keeps compiled graphs cached per (session_id, head_model, sub_agents_model)
to avoid rebuilding the LangGraph on every request.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

# ── Langfuse imports are lazy (deferred to function bodies) to avoid the
#    pydantic-v1 / Python 3.14 crash that occurs on top-level import.
if TYPE_CHECKING:
    from langfuse import Langfuse
    from langfuse.callback import CallbackHandler

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# HOW TO WIRE YOUR build_graph MODULE
# ---------------------------------------------------------------------------
# Place your existing build_graph.py (or package) anywhere that is on
# sys.path, for example:
#
#   ia_analysis/
#   ├── app/
#   └── build_graph.py   ← drop it here and it is importable from anywhere
#
# The import is intentionally deferred (inside each function) so that:
#   1. The server starts even before build_graph is present (useful for
#      running tests, health-checks, or the --help flag).
#   2. Any heavy LangChain / LangGraph imports inside build_graph do not
#      run at module load time, avoiding the pydantic-v1 Python 3.14 crash.
# ---------------------------------------------------------------------------

# Cache: key → (HEAD_agent, compiled_graph)
_graph_cache: dict[str, tuple[Any, Any]] = {}


def get_or_create_graph(
    session_id: str,
    user_name: str,
    head_model: str,
    sub_agents_model: str,
    lf: "Langfuse",
    lf_handler: "CallbackHandler",
) -> tuple[Any, Any]:
    """
    Return a cached (HEAD_agent, agents_graph) pair or build a fresh one.

    The cache key is the combination of session_id + model names so that
    switching models in the UI always triggers a rebuild.
    """
    # Deferred import – keeps build_graph (and all its LangChain deps) out
    # of the module-level import chain.
    from build_graph import (  # type: ignore[import]
        sub_agents_name,
        create_head_compile_graph,
    )

    cache_key = f"{session_id}::{head_model}::{sub_agents_model}"
    if cache_key not in _graph_cache:
        logger.info(
            "Building agent graph – session=%s head=%s sub=%s",
            session_id, head_model, sub_agents_model,
        )
        head_agent, graph = create_head_compile_graph(
            sub_agents_name,
            lf,
            lf_handler,
            session_id,
            user_name,
            deployment_model=head_model,
            sub_agents_model=sub_agents_model,
        )
        _graph_cache[cache_key] = (head_agent, graph)

    return _graph_cache[cache_key]


def invoke_graph(
    session_id: str,
    agents_graph: Any,
    context: list[dict[str, str]],
    lf_handler: "CallbackHandler",
    head_agent: Any,
) -> str:
    """
    Invoke the compiled graph and return the assistant response string.

    Parameters
    ----------
    session_id:   Active conversation session.
    agents_graph: Compiled LangGraph object.
    context:      Full message context including optional system summary.
    lf_handler:   Per-request Langfuse callback handler.
    head_agent:   HEAD agent node.
    """
    from build_graph import get_response  # type: ignore[import]  # deferred

    response = get_response(
        session_id, agents_graph, context, lf_handler, head_agent
    )
    return response or ""
