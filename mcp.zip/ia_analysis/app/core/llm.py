"""
LLM factory – mirrors the original ``llm.initialize_llm`` contract.

Keeps all Azure OpenAI / LiteLLM wiring in one place so the rest of the
app stays model-agnostic.

``langchain_openai`` is imported lazily (inside the function body) to avoid
the pydantic-v1 / Python 3.14 crash that occurs on top-level import.
"""
from __future__ import annotations

import logging
from functools import lru_cache
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from langchain_openai import AzureChatOpenAI

logger = logging.getLogger(__name__)

_DEPLOYMENT_MAP: dict[str, str] = {
    "azure-gpt-4o": "gpt-4o",
    "azure-gpt-4o-mini": "gpt-4o-mini",
    "azure-gpt-4o-act": "gpt-4o",
}


@lru_cache(maxsize=8)
def initialize_llm(model_name: str, temperature: float = 0.0) -> Any:
    """
    Return a cached ``AzureChatOpenAI`` instance for *model_name*.

    Parameters
    ----------
    model_name:  Logical model identifier (key in ``_DEPLOYMENT_MAP``).
    temperature: Sampling temperature (default 0 for deterministic output).
    """
    from langchain_openai import AzureChatOpenAI  # deferred – avoids pydantic-v1 crash

    deployment = _DEPLOYMENT_MAP.get(model_name, model_name)
    logger.info("Initialising LLM: %s → deployment=%s", model_name, deployment)

    return AzureChatOpenAI(
        azure_deployment=deployment,
        temperature=temperature,
        streaming=True,
    )
