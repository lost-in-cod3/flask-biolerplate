"""
FastMCP tool definitions.

Each tool is a thin adapter that validates inputs, delegates to a service,
and returns a clean result dict that the Streamlit (or any MCP) client can
consume directly.

Transport: Streamable-HTTP  (see app/api/server.py)
"""
from __future__ import annotations

import logging
from typing import Annotated

from fastmcp import FastMCP
from pydantic import Field

from app.config.settings import get_settings
from app.services.chat_service import chat, get_history, submit_explicit_feedback
from app.services.session_service import (
    create_session,
    delete_session,
    list_sessions,
)

logger = logging.getLogger(__name__)
settings = get_settings()

# ── FastMCP instance ──────────────────────────────────────────────────────────
mcp = FastMCP(
    name="IA Analysis Backend",
    instructions=(
        "Backend service for the IA Analysis chatbot. "
        "Provides tools for session management, multi-agent chat, "
        "conversation history retrieval, and user feedback."
    ),
)


# ─────────────────────────────────────────────────────────────────────────────
# Tool 1 – create_session
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool(
    name="create_session",
    description=(
        "Create a new conversation session. Returns the session_id and "
        "conversation_id that must be passed to subsequent tool calls."
    ),
)
def tool_create_session(
    user_name: Annotated[str, Field(description="Authenticated username")],
    head_model: Annotated[
        str,
        Field(
            default="azure-gpt-4o-act",
            description="Logical name of the HEAD agent LLM",
        ),
    ] = "azure-gpt-4o-act",
    sub_agents_model: Annotated[
        str,
        Field(
            default="azure-gpt-4o-act",
            description="Logical name of the sub-agents LLM",
        ),
    ] = "azure-gpt-4o-act",
) -> dict:
    """Create and persist a new conversation session."""
    state = create_session(
        user_name=user_name,
        head_model=head_model,
        sub_agents_model=sub_agents_model,
    )
    return {
        "session_id": state.session_id,
        "conversation_id": state.conversation_id,
        "user_name": state.user_name,
        "head_model": state.head_model,
        "sub_agents_model": state.sub_agents_model,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Tool 2 – chat
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool(
    name="chat",
    description=(
        "Send a user message to the multi-agent pipeline and receive the "
        "assistant response. Creates the session automatically on first call "
        "if conversation_id is omitted."
    ),
)
def tool_chat(
    user_message: Annotated[str, Field(description="The user's chat message")],
    user_name: Annotated[str, Field(description="Authenticated username")],
    conversation_id: Annotated[
        str | None,
        Field(
            default=None,
            description="Existing conversation UUID. Omit to start a new conversation.",
        ),
    ] = None,
    head_model: Annotated[
        str,
        Field(
            default="azure-gpt-4o-act",
            description="Logical name of the HEAD agent LLM",
        ),
    ] = "azure-gpt-4o-act",
    sub_agents_model: Annotated[
        str,
        Field(
            default="azure-gpt-4o-act",
            description="Logical name of the sub-agents LLM",
        ),
    ] = "azure-gpt-4o-act",
) -> dict:
    """
    Process one user turn through the full agent pipeline.

    Returns
    -------
    {
        "response":        str  – assistant reply,
        "session_id":      str  – full session key,
        "conversation_id": str  – UUID,
        "message_count":   int  – total messages so far,
    }
    """
    return chat(
        user_message=user_message,
        user_name=user_name,
        conversation_id=conversation_id,
        head_model=head_model,
        sub_agents_model=sub_agents_model,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Tool 3 – get_conversation_history
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool(
    name="get_conversation_history",
    description="Retrieve the full message history for an existing session.",
)
def tool_get_history(
    session_id: Annotated[str, Field(description="Full session_id (conversation_id + user_name)")],
) -> dict:
    """Return all messages for the given session."""
    messages = get_history(session_id)
    return {"session_id": session_id, "messages": messages, "count": len(messages)}


# ─────────────────────────────────────────────────────────────────────────────
# Tool 4 – delete_session
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool(
    name="delete_session",
    description="Delete a session and all associated conversation history.",
)
def tool_delete_session(
    session_id: Annotated[str, Field(description="Session ID to delete")],
) -> dict:
    """Remove a session from the in-memory store."""
    deleted = delete_session(session_id)
    return {"deleted": deleted, "session_id": session_id}


# ─────────────────────────────────────────────────────────────────────────────
# Tool 5 – submit_feedback
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool(
    name="submit_feedback",
    description=(
        "Record explicit user feedback (thumbs-up / thumbs-down) for a "
        "specific assistant response in Langfuse."
    ),
)
def tool_submit_feedback(
    session_id: Annotated[str, Field(description="Full session_id")],
    user_name: Annotated[str, Field(description="Authenticated username")],
    prompt: Annotated[str, Field(description="The user message being rated")],
    response: Annotated[str, Field(description="The assistant response being rated")],
    score: Annotated[
        float,
        Field(
            ge=0.0,
            le=1.0,
            description="Rating score: 1.0 = positive, 0.0 = negative",
        ),
    ],
    comment: Annotated[str, Field(default="", description="Optional free-text comment")] = "",
) -> dict:
    """Submit thumbs-up / thumbs-down feedback to Langfuse."""
    success = submit_explicit_feedback(
        session_id=session_id,
        user_name=user_name,
        prompt=prompt,
        response=response,
        score=score,
        comment=comment,
    )
    return {"success": success, "session_id": session_id}


# ─────────────────────────────────────────────────────────────────────────────
# Tool 6 – get_available_models
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool(
    name="get_available_models",
    description="Return the list of LLM model identifiers available for selection.",
)
def tool_get_models() -> dict:
    """Return available model names and defaults."""
    return {
        "available_models": settings.available_models,
        "default_head_model": settings.default_head_model,
        "default_sub_agents_model": settings.default_sub_agents_model,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Tool 7 – list_sessions  (admin / debug)
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool(
    name="list_sessions",
    description="List all active session IDs, optionally filtered by user_name.",
)
def tool_list_sessions(
    user_name: Annotated[
        str | None,
        Field(default=None, description="Filter by user. Omit to return all sessions."),
    ] = None,
) -> dict:
    """Return active session IDs from the in-memory store."""
    sessions = list_sessions(user_name)
    return {"sessions": sessions, "count": len(sessions)}
