# FastMCP instance is imported lazily via app.api.server, not here,
# to avoid triggering langchain/langfuse imports at package load time.
