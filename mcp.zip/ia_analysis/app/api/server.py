"""
FastMCP server entry point.

Runs the MCP backend over **Streamable-HTTP** transport, which exposes a
single HTTP endpoint (default: POST /mcp) that accepts JSON-RPC 2.0
messages and can stream SSE responses for long-running tools.

Usage
-----
Direct (development)::

    python -m app.api.server

Via uvicorn (production)::

    uvicorn app.api.server:asgi_app --host 0.0.0.0 --port 8000 --workers 4

Docker::

    docker compose up   (see infrastructure/template/docker-compose.yml)
"""
from __future__ import annotations

import logging
import os

# ── Tiktoken cache must be set before any OpenAI / tiktoken import ────────────
from app.config.settings import get_settings

_settings = get_settings()
os.environ.setdefault("TIKTOKEN_CACHE_DIR", _settings.tiktoken_cache_dir)

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=_settings.mcp_log_level.upper(),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ── Import the FastMCP instance (tools are registered as side-effects) ────────
from app.api.tools import mcp  # noqa: E402  (import after env setup)


# ── ASGI app ──────────────────────────────────────────────────────────────────
# FastMCP's streamable-HTTP ASGI app accessor changed across versions.
# We try each known attribute name in order so the code works regardless
# of which FastMCP release is installed.
def _get_asgi_app():
    """
    Return a Starlette/ASGI app for the streamable-HTTP transport.

    FastMCP's API has shifted across releases — we probe all known factory
    method names so the code works without pinning an exact version.
    """
    for method_name in (
        "streamable_http_app",   # FastMCP ≤ 2.2
        "http_app",              # FastMCP 2.3+
        "asgi_app",              # some pre-release builds
        "get_asgi_app",          # alternate naming
    ):
        method = getattr(mcp, method_name, None)
        if callable(method):
            logger.info("Using FastMCP ASGI factory: %s()", method_name)
            return method()

    # Last resort: try to get the underlying Starlette app from the server
    for attr in ("_asgi_app", "app", "starlette_app"):
        obj = getattr(mcp, attr, None)
        if obj is not None and callable(getattr(obj, "__call__", None)):
            logger.info("Using FastMCP app attribute: %s", attr)
            return obj

    raise RuntimeError(
        "\n\nCannot find a streamable-HTTP ASGI factory on this FastMCP build.\n"
        "Run:  pip show fastmcp\n"
        "Then check the FastMCP changelog for the correct transport method,\n"
        "or use:  python -m app.api.server --run  to start via mcp.run() instead.\n"
    )


# Build the ASGI app at import time so uvicorn can reference it as
# 'app.api.server:asgi_app'.  Falls back gracefully if no factory found.
try:
    asgi_app = _get_asgi_app()
except RuntimeError as _asgi_err:
    asgi_app = None  # type: ignore[assignment]
    logger.warning("ASGI factory unavailable: %s", _asgi_err)


def run_dev() -> None:
    """
    Start the server in development mode.

    Prefers uvicorn + ASGI app for hot-reload support.
    Falls back to ``mcp.run()`` (FastMCP's built-in server loop) if no
    ASGI factory is available.
    """
    if asgi_app is not None:
        import uvicorn

        logger.info(
            "Starting IA Analysis MCP server (uvicorn) on %s:%d",
            _settings.mcp_host,
            _settings.mcp_port,
        )
        uvicorn.run(
            "app.api.server:asgi_app",
            host=_settings.mcp_host,
            port=_settings.mcp_port,
            reload=True,
            log_level=_settings.mcp_log_level.lower(),
        )
    else:
        # FastMCP built-in runner — works on all versions
        logger.info(
            "Starting IA Analysis MCP server (mcp.run) on %s:%d",
            _settings.mcp_host,
            _settings.mcp_port,
        )
        mcp.run(
            transport="streamable-http",
            host=_settings.mcp_host,
            port=_settings.mcp_port,
        )


if __name__ == "__main__":
    run_dev()
