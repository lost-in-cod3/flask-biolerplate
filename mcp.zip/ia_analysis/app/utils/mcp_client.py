"""
Thin async MCP client wrapper for the Streamlit frontend.

Uses ``httpx`` to call the FastMCP Streamable-HTTP endpoint so the frontend
has no direct dependency on LangChain, LangGraph, or Langfuse.

All public functions are **synchronous** wrappers around async calls so they
integrate cleanly with Streamlit's single-threaded execution model.
"""
from __future__ import annotations

import json
import logging
import uuid
from typing import Any

import httpx

logger = logging.getLogger(__name__)

# ── Server location (override via MCP_SERVER_URL env var) ────────────────────
import os

_BASE_URL = os.environ.get("MCP_SERVER_URL", "http://localhost:8000")
_MCP_ENDPOINT = f"{_BASE_URL}/mcp"
_TIMEOUT = 120.0  # seconds – long enough for slow LLM calls


# ─────────────────────────────────────────────────────────────────────────────
# Low-level JSON-RPC helper
# ─────────────────────────────────────────────────────────────────────────────

def _call_tool(tool_name: str, arguments: dict[str, Any]) -> Any:
    """
    Send a JSON-RPC ``tools/call`` request to the MCP server and return the
    parsed result content.

    Raises ``RuntimeError`` on server errors.
    """
    payload = {
        "jsonrpc": "2.0",
        "id": str(uuid.uuid4()),
        "method": "tools/call",
        "params": {
            "name": tool_name,
            "arguments": arguments,
        },
    }
    try:
        with httpx.Client(timeout=_TIMEOUT) as client:
            resp = client.post(
                _MCP_ENDPOINT,
                json=payload,
                headers={"Content-Type": "application/json"},
            )
            resp.raise_for_status()
    except httpx.HTTPStatusError as exc:
        raise RuntimeError(
            f"MCP server returned HTTP {exc.response.status_code}: {exc.response.text}"
        ) from exc
    except httpx.RequestError as exc:
        raise RuntimeError(f"MCP connection error: {exc}") from exc

    data = resp.json()

    if "error" in data:
        raise RuntimeError(f"MCP tool error [{tool_name}]: {data['error']}")

    # FastMCP wraps results in data.result.content[0].text (JSON string)
    try:
        raw_text = data["result"]["content"][0]["text"]
        return json.loads(raw_text)
    except (KeyError, IndexError, json.JSONDecodeError) as exc:
        logger.warning("Unexpected MCP response shape: %s", data)
        raise RuntimeError(f"Could not parse MCP response: {exc}") from exc


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def get_available_models() -> dict[str, Any]:
    """Return available model names and defaults from the server."""
    return _call_tool("get_available_models", {})


def create_session(
    user_name: str,
    head_model: str,
    sub_agents_model: str,
) -> dict[str, Any]:
    """Create a new server-side conversation session."""
    return _call_tool(
        "create_session",
        {
            "user_name": user_name,
            "head_model": head_model,
            "sub_agents_model": sub_agents_model,
        },
    )


def chat(
    user_message: str,
    user_name: str,
    conversation_id: str | None,
    head_model: str,
    sub_agents_model: str,
) -> dict[str, Any]:
    """
    Send a user message and receive the assistant response.

    Returns a dict::

        {
            "response": str,
            "session_id": str,
            "conversation_id": str,
            "message_count": int,
        }
    """
    return _call_tool(
        "chat",
        {
            "user_message": user_message,
            "user_name": user_name,
            "conversation_id": conversation_id,
            "head_model": head_model,
            "sub_agents_model": sub_agents_model,
        },
    )


def get_conversation_history(session_id: str) -> list[dict[str, str]]:
    """Retrieve full message history for *session_id*."""
    result = _call_tool("get_conversation_history", {"session_id": session_id})
    return result.get("messages", [])


def delete_session(session_id: str) -> bool:
    """Delete a session from the server."""
    result = _call_tool("delete_session", {"session_id": session_id})
    return result.get("deleted", False)


def submit_feedback(
    session_id: str,
    user_name: str,
    prompt: str,
    response: str,
    score: float,
    comment: str = "",
) -> bool:
    """Submit explicit user feedback to Langfuse via the server."""
    result = _call_tool(
        "submit_feedback",
        {
            "session_id": session_id,
            "user_name": user_name,
            "prompt": prompt,
            "response": response,
            "score": score,
            "comment": comment,
        },
    )
    return result.get("success", False)
