"""
General-purpose utility helpers.
"""
from __future__ import annotations

import hashlib
import re
import unicodedata
from datetime import datetime, timezone


def utcnow_iso() -> str:
    """Return the current UTC timestamp as an ISO-8601 string."""
    return datetime.now(tz=timezone.utc).isoformat()


def sanitize_username(raw: str) -> str:
    """
    Normalise a username coming from an auth proxy header.

    - Strip leading/trailing whitespace.
    - Replace non-alphanumeric characters (except ``-`` and ``_``) with ``_``.
    - Truncate to 64 characters.
    """
    normalized = unicodedata.normalize("NFKD", raw.strip())
    cleaned = re.sub(r"[^\w\-]", "_", normalized)
    return cleaned[:64]


def short_id(session_id: str, length: int = 8) -> str:
    """Return a short deterministic identifier derived from *session_id*."""
    return hashlib.sha256(session_id.encode()).hexdigest()[:length]


def truncate(text: str, max_chars: int = 200, ellipsis: str = "…") -> str:
    """Truncate *text* to *max_chars* and append *ellipsis* if truncated."""
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + ellipsis


def role_label(role: str) -> str:
    """Map internal role strings to display labels."""
    return {"user": "You", "assistant": "IA Assistant", "system": "System"}.get(
        role, role.capitalize()
    )
