"""
Langfuse observability setup.

All Langfuse imports are intentionally **lazy** (deferred to first use) to
avoid the pydantic-v1 / Python 3.14 incompatibility that crashes at import
time when Langfuse is loaded too early.

Provides:
  • ``get_langfuse()``         – singleton Langfuse client
  • ``build_langfuse_handler`` – per-request LangChain callback handler
  • ``user_feedback``          – records a feedback trace in Langfuse
  • ``langfuse``               – module-level property alias (lazy)
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from app.config.settings import get_settings

if TYPE_CHECKING:
    # Only used for type hints – never imported at runtime from here
    from langfuse import Langfuse
    from langfuse.callback import CallbackHandler

logger = logging.getLogger(__name__)
settings = get_settings()

# ── Lazy singleton ────────────────────────────────────────────────────────────
_langfuse_instance: Any = None


def get_langfuse() -> "Langfuse":
    """Return the cached Langfuse client, creating it on first call."""
    global _langfuse_instance
    if _langfuse_instance is None:
        from langfuse import Langfuse  # deferred import

        _langfuse_instance = Langfuse(
            public_key=settings.langfuse_public_key,
            secret_key=settings.langfuse_secret_key,
            host=settings.langfuse_host,
        )
    return _langfuse_instance


# Module-level alias so existing ``from app.config.langfuse_config import langfuse``
# calls still work – the object is resolved lazily on first attribute access.
class _LazyLangfuse:
    """Proxy that forwards every attribute access to the real Langfuse client."""

    def __getattr__(self, name: str) -> Any:
        return getattr(get_langfuse(), name)

    def __repr__(self) -> str:  # pragma: no cover
        return repr(get_langfuse())


langfuse: "Langfuse" = _LazyLangfuse()  # type: ignore[assignment]


def build_langfuse_handler(session_id: str, user_id: str) -> "CallbackHandler":
    """Return a per-request LangChain callback handler tied to *session_id*."""
    from langfuse.callback import CallbackHandler  # deferred import

    return CallbackHandler(
        public_key=settings.langfuse_public_key,
        secret_key=settings.langfuse_secret_key,
        host=settings.langfuse_host,
        session_id=session_id,
        user_id=user_id,
    )


def user_feedback(
    lf: Any,
    user_name: str,
    session_id: str,
    prompt: str,
    response: str,
    score: float = 1.0,
    comment: str = "",
) -> None:
    """
    Record a feedback trace in Langfuse.

    Parameters
    ----------
    lf:          Langfuse client instance (or the lazy proxy).
    user_name:   The authenticated user.
    session_id:  Conversation session identifier.
    prompt:      The user message that triggered the response.
    response:    The assistant response to score.
    score:       Numeric score (default 1.0 = positive).
    comment:     Optional free-text comment.
    """
    try:
        trace = lf.trace(
            name="user_feedback",
            session_id=session_id,
            user_id=user_name,
            input=prompt,
            output=response,
        )
        trace.score(name="user_rating", value=score, comment=comment)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Langfuse feedback failed: %s", exc)
