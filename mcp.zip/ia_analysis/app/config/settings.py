"""
Application settings loaded from environment variables via pydantic-settings.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── LLM Models ──────────────────────────────────────────────────────────
    summarize_llm: str = "azure-gpt-4o-mini"
    lite_llm_40: str = "azure-gpt-4o"
    default_head_model: str = "azure-gpt-4o-act"
    default_sub_agents_model: str = "azure-gpt-4o-act"

    available_models: list[str] = [
        "azure-gpt-4o",
        "azure-gpt-4o-mini",
        "azure-gpt-4o-act",
    ]

    # ── Session / History ────────────────────────────────────────────────────
    max_message_history: int = 20

    # ── Langfuse ─────────────────────────────────────────────────────────────
    langfuse_public_key: str = ""
    langfuse_secret_key: str = ""
    langfuse_host: str = "https://cloud.langfuse.com"

    # ── FastMCP Server ────────────────────────────────────────────────────────
    mcp_host: str = "0.0.0.0"
    mcp_port: int = 8000
    mcp_path: str = "/mcp"
    mcp_log_level: str = "INFO"

    # ── Tiktoken cache ────────────────────────────────────────────────────────
    tiktoken_cache_dir: str = "app/tiktoken_cache"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return a cached singleton Settings instance."""
    return Settings()
