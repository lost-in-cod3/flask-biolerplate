"""
Summarization service – decides *when* to summarise and updates the session.
"""
from __future__ import annotations

import logging

from app.config.settings import get_settings
from app.core.llm import initialize_llm
from app.services.session_service import SessionState, update_session
from app.tools.summarization_utils import summarize_old_messages

logger = logging.getLogger(__name__)
settings = get_settings()


def maybe_summarize(state: SessionState) -> None:
    """
    If ``state.messages`` exceeds MAX_MESSAGE_HISTORY, summarise the oldest
    turns and store the result in ``state.summary``.

    Mutates *state* in-place and persists via ``update_session``.
    """
    if len(state.messages) <= settings.max_message_history:
        return

    old_messages = state.messages[: -settings.max_message_history]
    llm = initialize_llm(settings.summarize_llm)

    logger.info(
        "Summarising %d old messages for session %s",
        len(old_messages),
        state.session_id,
    )

    state.summary = summarize_old_messages(
        old_messages, llm, previous_summary=state.summary
    )
    update_session(state)


def build_context(state: SessionState) -> list[dict[str, str]]:
    """
    Assemble the message context to pass to the agent graph.

    Prepends the rolling summary (if any) as a system message, then appends
    the most recent ``MAX_MESSAGE_HISTORY`` turns.
    """
    context: list[dict[str, str]] = []

    if state.summary:
        context.append({"role": "system", "content": state.summary})

    context.extend(state.messages[-settings.max_message_history :])
    return context
