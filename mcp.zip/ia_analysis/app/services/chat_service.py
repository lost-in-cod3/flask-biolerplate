"""
Chat service – top-level orchestrator that ties together:
  • session management
  • agent graph creation / caching
  • message summarization
  • Langfuse observability
"""
from __future__ import annotations

import logging
from typing import Any

from app.config.langfuse_config import (
    langfuse,
    build_langfuse_handler,
    user_feedback,
)
from app.config.settings import get_settings
from app.core.graph import get_or_create_graph, invoke_graph
from app.services.session_service import (
    SessionState,
    get_or_create_session,
    update_session,
)
from app.services.summarization_service import maybe_summarize, build_context

logger = logging.getLogger(__name__)
settings = get_settings()


def chat(
    user_message: str,
    user_name: str,
    conversation_id: str | None = None,
    head_model: str | None = None,
    sub_agents_model: str | None = None,
) -> dict[str, Any]:
    """
    Process one user turn and return the assistant response plus session metadata.

    Parameters
    ----------
    user_message:      The raw user prompt.
    user_name:         Authenticated username (used as part of session key).
    conversation_id:   Existing conversation UUID; a new one is minted if None.
    head_model:        Logical name of the HEAD agent model.
    sub_agents_model:  Logical name of the sub-agent model.

    Returns
    -------
    dict with keys:
      • response      – assistant reply string
      • session_id    – full session key
      • conversation_id – UUID portion of the session key
      • message_count – total messages in history
    """
    head_model = head_model or settings.default_head_model
    sub_agents_model = sub_agents_model or settings.default_sub_agents_model

    # ── 1. Resolve session ────────────────────────────────────────────────────
    state: SessionState = get_or_create_session(
        user_name=user_name,
        head_model=head_model,
        sub_agents_model=sub_agents_model,
        conversation_id=conversation_id,
    )

    # ── 2. Append user message ────────────────────────────────────────────────
    state.messages.append({"role": "user", "content": user_message})

    # ── 3. Summarise if history is too long ───────────────────────────────────
    maybe_summarize(state)

    # ── 4. Build context (summary + recent messages) ──────────────────────────
    context = build_context(state)

    # ── 5. Build / reuse agent graph ──────────────────────────────────────────
    lf_handler = build_langfuse_handler(state.session_id, user_name)

    head_agent, agents_graph = get_or_create_graph(
        session_id=state.session_id,
        user_name=user_name,
        head_model=state.head_model,
        sub_agents_model=state.sub_agents_model,
        lf=langfuse,
        lf_handler=lf_handler,
    )
    state.head_agent = head_agent
    state.agents_graph = agents_graph

    # ── 6. Invoke the graph ───────────────────────────────────────────────────
    response_content = invoke_graph(
        session_id=state.session_id,
        agents_graph=agents_graph,
        context=context,
        lf_handler=lf_handler,
        head_agent=head_agent,
    )

    # ── 7. Persist assistant message ──────────────────────────────────────────
    state.messages.append({"role": "assistant", "content": response_content})
    update_session(state)

    # ── 8. Record Langfuse feedback ────────────────────────────────────────────
    user_feedback(
        langfuse,
        user_name,
        state.session_id,
        user_message,
        response_content,
    )

    return {
        "response": response_content,
        "session_id": state.session_id,
        "conversation_id": state.conversation_id,
        "message_count": len(state.messages),
    }


def get_history(session_id: str) -> list[dict[str, str]]:
    """Return the full message history for *session_id*."""
    from app.services.session_service import get_session

    state = get_session(session_id)
    if state is None:
        return []
    return state.messages


def submit_explicit_feedback(
    session_id: str,
    user_name: str,
    prompt: str,
    response: str,
    score: float,
    comment: str = "",
) -> bool:
    """
    Record explicit user feedback (e.g. thumbs-up / thumbs-down).

    Returns True on success.
    """
    try:
        user_feedback(
            langfuse,
            user_name,
            session_id,
            prompt,
            response,
            score=score,
            comment=comment,
        )
        return True
    except Exception as exc:  # noqa: BLE001
        logger.warning("Explicit feedback failed: %s", exc)
        return False
