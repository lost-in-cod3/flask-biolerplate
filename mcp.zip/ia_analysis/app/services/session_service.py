"""
Session service – manages per-conversation state on the server side.

Uses a simple in-memory store (dict) suitable for single-process deployments.
For multi-instance / distributed setups replace ``_store`` with a Redis backend.
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SessionState:
    """Holds all mutable state for a single conversation session."""

    conversation_id: str
    user_name: str
    head_model: str
    sub_agents_model: str
    messages: list[dict[str, str]] = field(default_factory=list)
    summary: str = ""
    head_agent: Any = None
    agents_graph: Any = None

    @property
    def session_id(self) -> str:
        return self.conversation_id + self.user_name


# ── In-memory store ──────────────────────────────────────────────────────────
_store: dict[str, SessionState] = {}


def create_session(
    user_name: str,
    head_model: str,
    sub_agents_model: str,
    conversation_id: str | None = None,
) -> SessionState:
    """Create a new session and persist it in the store."""
    cid = conversation_id or str(uuid.uuid4())
    state = SessionState(
        conversation_id=cid,
        user_name=user_name,
        head_model=head_model,
        sub_agents_model=sub_agents_model,
        messages=[{"role": "assistant", "content": "How can I help you?"}],
    )
    _store[state.session_id] = state
    logger.info("Created session %s for user %s", state.session_id, user_name)
    return state


def get_session(session_id: str) -> SessionState | None:
    """Return the session for *session_id* or ``None`` if not found."""
    return _store.get(session_id)


def get_or_create_session(
    user_name: str,
    head_model: str,
    sub_agents_model: str,
    conversation_id: str | None = None,
) -> SessionState:
    """Fetch existing session or create a fresh one."""
    if conversation_id:
        sid = conversation_id + user_name
        existing = _store.get(sid)
        if existing:
            return existing
    return create_session(user_name, head_model, sub_agents_model, conversation_id)


def update_session(state: SessionState) -> None:
    """Persist a mutated session back to the store."""
    _store[state.session_id] = state


def delete_session(session_id: str) -> bool:
    """Remove a session from the store. Returns True if it existed."""
    if session_id in _store:
        del _store[session_id]
        logger.info("Deleted session %s", session_id)
        return True
    return False


def list_sessions(user_name: str | None = None) -> list[str]:
    """Return all session IDs, optionally filtered by *user_name*."""
    if user_name:
        return [sid for sid, s in _store.items() if s.user_name == user_name]
    return list(_store.keys())
