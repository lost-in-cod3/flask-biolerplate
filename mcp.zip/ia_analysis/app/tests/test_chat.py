"""
Unit and integration tests for the IA Analysis MCP backend.

Run with::

    pytest app/tests/ -v
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

# ─────────────────────────────────────────────────────────────────────────────
# Session service tests
# ─────────────────────────────────────────────────────────────────────────────

class TestSessionService:
    def test_create_session_returns_state(self):
        from app.services.session_service import create_session, delete_session

        state = create_session(
            user_name="test_user",
            head_model="azure-gpt-4o-act",
            sub_agents_model="azure-gpt-4o-act",
        )
        assert state.user_name == "test_user"
        assert state.conversation_id
        assert state.session_id == state.conversation_id + "test_user"
        assert len(state.messages) == 1  # initial assistant greeting
        delete_session(state.session_id)

    def test_get_session_returns_none_for_missing(self):
        from app.services.session_service import get_session

        assert get_session("nonexistent_session_id") is None

    def test_delete_session_returns_true_when_exists(self):
        from app.services.session_service import create_session, delete_session

        state = create_session("u1", "azure-gpt-4o-act", "azure-gpt-4o-act")
        assert delete_session(state.session_id) is True
        assert delete_session(state.session_id) is False

    def test_list_sessions_filtered_by_user(self):
        from app.services.session_service import (
            create_session,
            delete_session,
            list_sessions,
        )

        s1 = create_session("alice", "azure-gpt-4o-act", "azure-gpt-4o-act")
        s2 = create_session("bob", "azure-gpt-4o-act", "azure-gpt-4o-act")

        alice_sessions = list_sessions("alice")
        assert s1.session_id in alice_sessions
        assert s2.session_id not in alice_sessions

        delete_session(s1.session_id)
        delete_session(s2.session_id)


# ─────────────────────────────────────────────────────────────────────────────
# Summarization service tests
# ─────────────────────────────────────────────────────────────────────────────

class TestSummarizationService:
    def test_build_context_no_summary(self):
        from app.services.session_service import SessionState
        from app.services.summarization_service import build_context

        state = SessionState(
            conversation_id="abc",
            user_name="u",
            head_model="m",
            sub_agents_model="m",
            messages=[
                {"role": "assistant", "content": "Hello"},
                {"role": "user", "content": "Hi"},
            ],
        )
        ctx = build_context(state)
        assert ctx[0]["role"] == "assistant"
        assert len(ctx) == 2

    def test_build_context_with_summary(self):
        from app.services.session_service import SessionState
        from app.services.summarization_service import build_context

        state = SessionState(
            conversation_id="abc",
            user_name="u",
            head_model="m",
            sub_agents_model="m",
            messages=[{"role": "user", "content": "ping"}],
            summary="Prior conversation summary.",
        )
        ctx = build_context(state)
        assert ctx[0]["role"] == "system"
        assert "Prior" in ctx[0]["content"]


# ─────────────────────────────────────────────────────────────────────────────
# Utility helpers tests
# ─────────────────────────────────────────────────────────────────────────────

class TestHelpers:
    def test_sanitize_username(self):
        from app.utils.helpers import sanitize_username

        assert sanitize_username("  john.doe@company.com  ") == "john_doe_company_com"

    def test_truncate(self):
        from app.utils.helpers import truncate

        assert truncate("hello world", max_chars=5) == "hello…"
        assert truncate("hi", max_chars=10) == "hi"

    def test_short_id_deterministic(self):
        from app.utils.helpers import short_id

        assert short_id("same") == short_id("same")
        assert short_id("a") != short_id("b")


# ─────────────────────────────────────────────────────────────────────────────
# Chat service tests (mocked graph)
# ─────────────────────────────────────────────────────────────────────────────

class TestChatService:
    @patch("app.services.chat_service.get_or_create_graph")
    @patch("app.services.chat_service.invoke_graph")
    @patch("app.services.chat_service.user_feedback")
    def test_chat_returns_response(self, mock_fb, mock_invoke, mock_graph):
        from app.services.chat_service import chat
        from app.services.session_service import delete_session

        mock_graph.return_value = (MagicMock(), MagicMock())
        mock_invoke.return_value = "Mocked assistant reply"

        result = chat(
            user_message="Hello",
            user_name="tester",
            head_model="azure-gpt-4o-act",
            sub_agents_model="azure-gpt-4o-act",
        )

        assert result["response"] == "Mocked assistant reply"
        assert "session_id" in result
        assert result["message_count"] >= 2  # greeting + user + assistant

        delete_session(result["session_id"])


# ─────────────────────────────────────────────────────────────────────────────
# MCP tool schema smoke tests
# ─────────────────────────────────────────────────────────────────────────────

class TestMCPToolSchemas:
    def test_all_tools_registered(self):
        from app.api.tools import mcp

        tool_names = {t.name for t in mcp._tool_manager.list_tools()}
        expected = {
            "create_session",
            "chat",
            "get_conversation_history",
            "delete_session",
            "submit_feedback",
            "get_available_models",
            "list_sessions",
        }
        assert expected.issubset(tool_names), (
            f"Missing tools: {expected - tool_names}"
        )
