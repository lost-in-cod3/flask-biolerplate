"""
Summarization utilities for compressing old conversation turns.

All langchain imports are deferred (lazy) to avoid pydantic-v1 / Python 3.14
startup crashes.
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

_SUMMARY_PROMPT = (
    "You are a concise summarization assistant. "
    "Summarize the following conversation history into a compact paragraph "
    "that preserves all important facts, decisions, and context. "
    "Write in the third person. Do NOT include any greetings or meta-commentary.\n\n"
    "Conversation:\n{history}"
)


def summarize_old_messages(
    old_messages: list[dict[str, str]],
    llm: Any,
    previous_summary: str = "",
) -> str:
    """
    Summarize *old_messages* using *llm* and return the summary string.

    Parameters
    ----------
    old_messages:     List of role/content dicts to compress.
    llm:              An initialised LangChain LLM instance.
    previous_summary: Existing summary to merge with (incremental updates).
    """
    from langchain_core.messages import HumanMessage  # deferred – avoids pydantic-v1 crash

    if not old_messages:
        return previous_summary

    history_text = "\n".join(
        f"{m['role'].upper()}: {m['content']}" for m in old_messages
    )

    if previous_summary:
        history_text = (
            f"[Previous summary]\n{previous_summary}\n\n"
            f"[New messages]\n{history_text}"
        )

    prompt = _SUMMARY_PROMPT.format(history=history_text)

    try:
        result = llm.invoke([HumanMessage(content=prompt)])
        summary = result.content if hasattr(result, "content") else str(result)
        logger.debug("Generated summary (%d chars)", len(summary))
        return summary
    except Exception as exc:  # noqa: BLE001
        logger.warning("Summarization failed: %s", exc)
        return previous_summary
