"""
IA Analysis V1.06 – Streamlit frontend.

All heavy lifting (LLM calls, LangGraph, Langfuse) is delegated to the
FastMCP backend via the mcp_client helper.  The frontend is now a thin UI
layer with no direct AI dependencies.
"""
from __future__ import annotations

import logging
import uuid

import streamlit as st

# MCP client (calls the FastMCP Streamable-HTTP server)
from app.utils.mcp_client import (
    chat as mcp_chat,
    create_session as mcp_create_session,
    delete_session as mcp_delete_session,
    get_available_models,
    submit_feedback,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _resolve_username() -> str:
    """Resolve the authenticated username from the auth-proxy header."""
    if st.context.headers:
        headers = st.context.headers.to_dict()
        username = headers.get("X-Auth-Request-Preferred-Username")
        if username:
            return username
    return "local_KT"


@st.cache_data(show_spinner=False)
def _fetch_models() -> dict:
    """Fetch available model names from the MCP server (cached per session)."""
    try:
        return get_available_models()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not fetch models from MCP server: %s", exc)
        return {
            "available_models": ["azure-gpt-4o", "azure-gpt-4o-mini", "azure-gpt-4o-act"],
            "default_head_model": "azure-gpt-4o-act",
            "default_sub_agents_model": "azure-gpt-4o-act",
        }


# ─────────────────────────────────────────────────────────────────────────────
# Main app
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    user_name = _resolve_username()

    # ── Session initialisation ────────────────────────────────────────────────
    if "conversation_id" not in st.session_state:
        st.session_state.conversation_id = str(uuid.uuid4())

    if "messages" not in st.session_state:
        st.session_state.messages = [
            {"role": "assistant", "content": "How can I help you?"}
        ]

    if "last_user_msg" not in st.session_state:
        st.session_state.last_user_msg = ""
    if "last_assistant_msg" not in st.session_state:
        st.session_state.last_assistant_msg = ""

    # ── Title & description ───────────────────────────────────────────────────
    st.title("IA Analysis V1.06")
    st.write("Welcome to the interactive chat app!")
    st.write(
        "The app is designed to help analyzing IAs, answering questions about "
        "related IAs, previous IAs, previous causes, common causes etc."
    )

    # ── Sidebar links ─────────────────────────────────────────────────────────
    st.sidebar.markdown("##### User Guide")
    st.sidebar.markdown(
        '<a href="https://google.com" target="_blank">User Guide</a>',
        unsafe_allow_html=True,
    )
    st.sidebar.markdown("##### Changelogs")
    st.sidebar.markdown(
        '<a href="https://google.com" target="_blank">Changelogs</a>',
        unsafe_allow_html=True,
    )
    st.sidebar.markdown("##### Issue Register")
    st.sidebar.markdown(
        '<a href="https://google.com" target="_blank">Issue Register</a>',
        unsafe_allow_html=True,
    )

    # ── Model configuration ───────────────────────────────────────────────────
    st.sidebar.markdown("### Model Configuration")
    st.sidebar.info(
        "Please refresh the page before switching models to ensure changes take effect"
    )

    model_info = _fetch_models()
    available_models: list[str] = model_info["available_models"]
    default_head = model_info["default_head_model"]
    default_sub = model_info["default_sub_agents_model"]

    head_model = st.sidebar.selectbox(
        "HEAD Agent LLM",
        available_models,
        index=available_models.index(default_head) if default_head in available_models else 0,
    )
    sub_agents_model = st.sidebar.selectbox(
        "Sub-Agents LLM",
        available_models,
        index=available_models.index(default_sub) if default_sub in available_models else 0,
    )

    # ── Clear conversation button ─────────────────────────────────────────────
    st.sidebar.markdown("---")
    if st.sidebar.button("🗑️ Clear Conversation"):
        if "session_id" in st.session_state:
            try:
                mcp_delete_session(st.session_state.session_id)
            except Exception:  # noqa: BLE001
                pass
        st.session_state.conversation_id = str(uuid.uuid4())
        st.session_state.messages = [
            {"role": "assistant", "content": "How can I help you?"}
        ]
        st.session_state.pop("session_id", None)
        st.rerun()

    # ── Display conversation history ──────────────────────────────────────────
    for msg in st.session_state.messages:
        if msg["role"] in ("user", "assistant"):
            st.chat_message(msg["role"]).write(msg["content"])

    # ── Thumbs feedback row (shown after each assistant reply) ────────────────
    if st.session_state.last_assistant_msg and "session_id" in st.session_state:
        col1, col2, _ = st.columns([1, 1, 10])
        with col1:
            if st.button("👍", key="thumb_up"):
                submit_feedback(
                    session_id=st.session_state.session_id,
                    user_name=user_name,
                    prompt=st.session_state.last_user_msg,
                    response=st.session_state.last_assistant_msg,
                    score=1.0,
                )
                st.toast("Thanks for the feedback! 👍")
        with col2:
            if st.button("👎", key="thumb_down"):
                submit_feedback(
                    session_id=st.session_state.session_id,
                    user_name=user_name,
                    prompt=st.session_state.last_user_msg,
                    response=st.session_state.last_assistant_msg,
                    score=0.0,
                )
                st.toast("Thanks for the feedback! 👎")

    # ── Chat input ────────────────────────────────────────────────────────────
    if prompt := st.chat_input("Ask a question about your IAs…"):
        st.session_state.messages.append({"role": "user", "content": prompt})
        st.chat_message("user").write(prompt)

        with st.chat_message("assistant"):
            with st.spinner("Thinking…"):
                try:
                    result = mcp_chat(
                        user_message=prompt,
                        user_name=user_name,
                        conversation_id=st.session_state.conversation_id,
                        head_model=head_model,
                        sub_agents_model=sub_agents_model,
                    )
                    response_content: str = result["response"]
                    # Persist server-assigned session_id for feedback calls
                    st.session_state.session_id = result["session_id"]
                except Exception as exc:  # noqa: BLE001
                    response_content = f"⚠️ Error communicating with the backend: {exc}"
                    logger.error("MCP chat error: %s", exc)

            st.write(response_content)

        st.session_state.messages.append(
            {"role": "assistant", "content": response_content}
        )
        st.session_state.last_user_msg = prompt
        st.session_state.last_assistant_msg = response_content
        st.rerun()


main()
